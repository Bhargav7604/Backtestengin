import time, json, engine, traceback
L=lambda **k: {"side":"SELL","type":"CE","lots":1,"expiry":"weekly","strikeMode":"atm","strikeValue":0, **k}
base={"exch":"NFO","und":"NIFTY","start":"2025-02-01","end":"2026-06-30","capital":1000000,"entryTime":"09:20","exitTime":"15:15","costs":{"enabled":True,"brokerage":20,"slippagePct":0.1}}
tests={
 "full_straddle": {**base,"legs":[L(sl=25),L(type="PE",sl=25)]},
 "sensex_delta_reentry": {**base,"exch":"BFO","und":"SENSEX","legs":[L(strikeMode="delta",strikeValue=20,sl=40,reentries=2),L(type="PE",strikeMode="delta",strikeValue=20,sl=40,reentries=2,reentryMode="cost")],"overall":{"sl":8000,"lockAt":3000,"lockProfit":1000,"trailEvery":1000,"trailBy":500}},
 "bnf_ema_call": {**base,"und":"BANKNIFTY","timeframe":5,"maxTradesPerDay":3,"lastEntryTime":"14:30","legs":[L(side="BUY",expiry="monthly",sl=25,tgt=50,trailX=10,trailY=5)],
   "entryConds":{"logic":"AND","rules":[{"lhs":{"kind":"ind","name":"EMA","n":9},"op":"crosses_above","rhs":{"kind":"ind","name":"EMA","n":21}},{"lhs":{"kind":"ind","name":"RSI","n":14},"op":">","rhs":{"kind":"const","value":55}}]},
   "exitConds":{"logic":"OR","rules":[{"lhs":{"kind":"ind","name":"Supertrend","n":10,"n2":3},"op":">","rhs":{"kind":"ind","name":"Close"}},{"lhs":{"kind":"pos","field":"MinsInTrade"},"op":">","rhs":{"kind":"const","value":90}}]}},
 "nifty_positional_ic": {**base,"mode":"positional","exitTime":"15:00","weekdays":[2],"legs":[L(strikeValue=3),L(type="PE",strikeValue=3),L(side="BUY",strikeValue=8),L(side="BUY",type="PE",strikeValue=8)]},
 "reliance_fut": {**base,"und":"RELIANCE","legs":[L(side="BUY",type="FUT",expiry="monthly")],"entryConds":{"logic":"AND","rules":[{"lhs":{"kind":"ind","name":"Close"},"op":"crosses_above","rhs":{"kind":"ind","name":"VWAP"}}]},"timeframe":15},
 "midcp_premium": {**base,"und":"MIDCPNIFTY","dteMin":0,"dteMax":1,"legs":[L(strikeMode="premium",strikeValue=20,sl=50),L(type="PE",strikeMode="premium",strikeValue=20,sl=50)],"exitAllOnLegSl":True},
}
for k,c in tests.items():
    t=time.time()
    try:
        r=engine.run_backtest(c); s=r['stats']
        print(f"{k:24s} {time.time()-t:5.1f}s trades={s['trades']} net={s['netPnl']} win={s['winRate']} pf={s['profitFactor']} dd={s['maxDD']} spot={r['spotSource']} skip={r['skipped']} reasons={r['exitReasons']}")
    except Exception: traceback.print_exc()
