import duckdb, time
con = duckdb.connect()
con.execute("SET threads=8")
t=time.time()
f='/Users/bhargavmoparthi/Downloads/quantlab-s3-data/all_bfo_data_2025/BFO_CHART_INTRADAY_2025_12.csv.gz'
con.execute(f"""
CREATE TABLE r AS SELECT * FROM read_csv('{f}', delim='\t', header=true, compression='gzip',
 columns={{'SYMBOL':'VARCHAR','TIME':'TIMESTAMP','OPEN':'DOUBLE','HIGH':'DOUBLE','LOW':'DOUBLE','CLOSE':'DOUBLE','VOLUME':'DOUBLE','VWAP':'DOUBLE','OPEN_INTEREST':'DOUBLE','TOTAL_VOLUME':'DOUBLE','TOTAL_OPEN_INTEREST':'DOUBLE'}})
""")
print('load', time.time()-t, con.execute("select count(*), min(TIME), max(TIME) from r").fetchall())
print(con.execute("select strftime(TIME,'%H:%M') h, count(*) from r group by 1 order by 1 limit 5").fetchall())
print(con.execute("select strftime(TIME,'%H:%M') h, count(*) from r group by 1 order by 1 desc limit 5").fetchall())
print(con.execute("select count(*) from r where CLOSE=0").fetchall())
print(con.execute("select SYMBOL, count(*) from r where SYMBOL like 'OPTIDX_SENSEX_BFO_2025-12-04_85%' group by 1 order by 2 desc limit 5").fetchall())
