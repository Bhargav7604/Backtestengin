import time, json, engine
cfg = {"exch":"NFO","und":"NIFTY","start":"2025-12-01","end":"2025-12-31","capital":1000000,
 "entryTime":"09:20","exitTime":"15:15","legs":[{"side":"SELL","type":"CE","lots":1,"expiry":"weekly","strikeMode":"atm","strikeValue":0,"sl":25},
 {"side":"SELL","type":"PE","lots":1,"expiry":"weekly","strikeMode":"atm","strikeValue":0,"sl":25}],
 "costs":{"enabled":True,"brokerage":20,"slippagePct":0.1}}
t=time.time(); r=engine.run_backtest(cfg); print('t',time.time()-t)
print(json.dumps(r['stats'])); print(r['skipped'], r['spotSource'])
for tr in r['trades'][:3]: print(json.dumps(tr)[:900])
