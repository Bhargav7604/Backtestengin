import duckdb, json, time, os
D='/Users/bhargavmoparthi/quantlab-backtester/data'
c=duckdb.connect(); c.execute("SET threads=8")
t=time.time()
c.execute(f"""CREATE TABLE dsess AS SELECT exch, und, ts::DATE d, typ, count(*) n, count(DISTINCT ts) mins,
  count(DISTINCT expiry) nexp, count(DISTINCT strike) nstrikes, min(strike) kmin, max(strike) kmax
  FROM read_parquet('{D}/deriv/**/*.parquet', hive_partitioning=true, union_by_name=true) GROUP BY ALL""")
print('deriv', time.time()-t, flush=True)
c.execute(f"""CREATE TABLE csess AS SELECT exch, sym, kind, ts::DATE d, count(*) mins
  FROM read_parquet('{D}/cash/**/*.parquet', hive_partitioning=true, union_by_name=true) GROUP BY ALL""")
print('cash', time.time()-t, flush=True)
c.execute(f"""CREATE TABLE exps AS SELECT exch, und, typ='FUT' fut, expiry, min(ts)::DATE first_seen, max(ts)::DATE last_seen, count(DISTINCT strike) nstrikes
  FROM read_parquet('{D}/deriv/**/*.parquet', hive_partitioning=true, union_by_name=true) GROUP BY ALL""")
print('exps', time.time()-t, flush=True)
for tb in ('dsess','csess','exps'):
    c.execute(f"COPY {tb} TO '/Users/bhargavmoparthi/quantlab-backtester/scratch/audit/{tb}.parquet' (FORMAT parquet)")
print('done', time.time()-t)
