import { useEffect } from 'react';
import { GitCompareArrows, Moon, Sun } from 'lucide-react';
import { useStore } from './lib/store';
import Home from './components/home/Home';
import BuilderPage from './components/BuilderPage';
import ResultsDashboard from './components/results/ResultsDashboard';
import ComparePage from './components/results/ComparePage';
import { Alert } from './components/ui';

function Logo() {
  return (
    <svg viewBox="0 0 32 32" className="h-8 w-8" aria-hidden="true">
      <rect width="32" height="32" rx="9" fill="#16a34a" />
      <path d="M7 21l5-6 4 3 7-9" fill="none" stroke="#fff" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
      <circle cx="23" cy="9" r="2.2" fill="#bbf7d0" />
    </svg>
  );
}

export default function App() {
  const view = useStore(s => s.view);
  const theme = useStore(s => s.theme);
  const toggleTheme = useStore(s => s.toggleTheme);
  const loadMeta = useStore(s => s.loadMeta);
  const meta = useStore(s => s.meta);
  const metaError = useStore(s => s.metaError);
  const go = useStore(s => s.go);
  const compareN = useStore(s => s.compare.length);
  const hasResult = useStore(s => !!s.result);

  useEffect(() => { document.documentElement.classList.toggle('dark', theme === 'dark'); }, [theme]);
  useEffect(() => { loadMeta(); }, [loadMeta]);

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-30 border-b border-slate-200/70 bg-white/80 backdrop-blur dark:border-slate-800 dark:bg-slate-950/80">
        <div className="mx-auto flex h-14 max-w-7xl items-center gap-3 px-4 sm:px-6">
          <button className="flex items-center gap-2.5" onClick={() => go('home')}>
            <Logo />
            <div className="text-left leading-tight">
              <div className="text-[15px] font-bold tracking-tight">QuantLab</div>
              <div className="hidden text-[11px] text-slate-500 sm:block">F&O strategy backtester</div>
            </div>
          </button>
          <nav className="ml-4 hidden gap-1 md:flex">
            <button className={`btn-ghost btn-sm ${view === 'home' || view === 'builder' ? '!text-brand-700 dark:!text-brand-400' : ''}`} onClick={() => go('home')}>Create</button>
            {hasResult && <button className={`btn-ghost btn-sm ${view === 'results' ? '!text-brand-700 dark:!text-brand-400' : ''}`} onClick={() => go('results')}>Results</button>}
          </nav>
          <div className="ml-auto flex items-center gap-2">
            {meta?.calendar?.length === 2 && <span className="hidden text-xs text-slate-400 lg:inline">data {meta.calendar[0]} → {meta.calendar[1]}</span>}
            {compareN > 0 && (
              <button className="btn btn-sm" onClick={() => go('compare')}><GitCompareArrows size={14} /> <span className="hidden sm:inline">Compare</span> {compareN}</button>
            )}
            <button className="btn btn-sm !p-2" onClick={toggleTheme} aria-label="Toggle dark mode" title="Toggle dark mode">
              {theme === 'dark' ? <Sun size={15} /> : <Moon size={15} />}
            </button>
          </div>
        </div>
      </header>
      <main className="mx-auto max-w-7xl px-4 pb-16 pt-6 sm:px-6">
        {metaError && <div className="mb-4"><Alert kind="warn">Backend: {metaError} — you can still build strategies; running needs the server.</Alert></div>}
        {view === 'home' && <Home />}
        {view === 'builder' && <BuilderPage />}
        {view === 'results' && <ResultsDashboard />}
        {view === 'compare' && <ComparePage />}
      </main>
    </div>
  );
}
