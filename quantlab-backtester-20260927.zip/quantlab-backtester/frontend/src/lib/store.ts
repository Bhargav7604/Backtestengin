import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { api, ApiError, pollJob } from './api';
import { cleanConfig, defaultConfig } from './strategy';
import { clone, uid } from './format';
import type { BacktestResult, Instrument, Job, Meta, RunRecord, StrategyConfig } from './types';

export type BuilderKind = 'prompt' | 'option' | 'indicator' | 'pine' | 'python' | 'marketplace';
export type View = 'home' | 'builder' | 'results' | 'compare';

export interface CompileInfo { notes: string[]; warnings: string[]; at: number }

interface JobState { id: string | null; status: Job['status'] | 'starting'; progress: number; message?: string }

interface State {
  theme: 'light' | 'dark';
  toggleTheme: () => void;

  meta: Meta | null;
  metaError: string | null;
  loadMeta: () => Promise<void>;

  view: View;
  builder: BuilderKind;
  go: (view: View, builder?: BuilderKind) => void;

  config: StrategyConfig;
  setConfig: (patch: Partial<StrategyConfig>) => void;
  replaceConfig: (c: StrategyConfig) => void;

  codes: { prompt: string; pine: string; python: string };
  setCode: (k: 'prompt' | 'pine' | 'python', v: string) => void;
  instrument: Instrument;
  setInstrument: (i: Instrument) => void;
  compileInfo: Partial<Record<'prompt' | 'pine' | 'python', CompileInfo>>;
  setCompileInfo: (k: 'prompt' | 'pine' | 'python', info: CompileInfo | undefined) => void;

  job: JobState | null;
  runError: string | null;
  result: BacktestResult | null;
  resultConfig: StrategyConfig | null;
  runs: RunRecord[];
  compare: string[];
  run: (cfg?: StrategyConfig) => Promise<void>;
  cancel: () => Promise<void>;
  openRun: (id: string) => void;
  toggleCompare: (id: string) => void;
  clearRunError: () => void;
}

let cancelled = false;

export const useStore = create<State>()(
  persist(
    (set, get) => ({
      theme: 'light',
      toggleTheme: () => {
        const t = get().theme === 'dark' ? 'light' : 'dark';
        document.documentElement.classList.toggle('dark', t === 'dark');
        try { localStorage.setItem('ql-theme', t); } catch { /* ignore */ }
        set({ theme: t });
      },

      meta: null,
      metaError: null,
      loadMeta: async () => {
        try {
          const meta = await api.meta();
          set({ meta, metaError: null });
          // clamp dates to the selected underlying
          const c = get().config;
          const u = meta.underlyings.find(x => x.exch === c.exch && x.und === c.und) ?? meta.underlyings.find(x => x.index) ?? meta.underlyings[0];
          if (u) {
            const start = !c.start || c.start < u.from || c.start > u.to ? u.from : c.start;
            const end = !c.end || c.end > u.to || c.end < u.from ? u.to : c.end;
            set({ config: { ...c, exch: u.exch, und: u.und, start, end } });
          }
        } catch (e) {
          set({ metaError: (e as Error).message });
        }
      },

      view: 'home',
      builder: 'option',
      go: (view, builder) => {
        set(builder ? { view, builder } : { view });
        window.scrollTo({ top: 0, behavior: 'smooth' });
      },

      config: defaultConfig(),
      setConfig: patch => set({ config: { ...get().config, ...patch } }),
      replaceConfig: c => {
        const cur = get().config;
        // keep instrument/period from the common panel when the incoming config lacks them
        set({ config: { ...defaultConfig(), ...c, start: c.start || cur.start, end: c.end || cur.end, exch: c.exch || cur.exch, und: c.und || cur.und } });
      },

      codes: { prompt: '', pine: '', python: '' },
      setCode: (k, v) => set({ codes: { ...get().codes, [k]: v } }),
      instrument: 'atm_options',
      setInstrument: i => set({ instrument: i }),
      compileInfo: {},
      setCompileInfo: (k, info) => set({ compileInfo: { ...get().compileInfo, [k]: info } }),

      job: null,
      runError: null,
      result: null,
      resultConfig: null,
      runs: [],
      compare: [],
      clearRunError: () => set({ runError: null }),

      run: async cfgIn => {
        if (get().job) return;
        const cfg = cleanConfig(cfgIn ?? get().config);
        cancelled = false;
        set({ job: { id: null, status: 'starting', progress: 0 }, runError: null });
        let result: BacktestResult | null = null;
        try {
          let id: string | null = null;
          try {
            id = (await api.startJob(cfg)).id;
          } catch (e) {
            // Older backend without the job queue: fall back to the synchronous endpoint.
            if (e instanceof ApiError && (e.status === 404 || e.status === 405)) {
              set({ job: { id: null, status: 'running', progress: 0.5, message: 'Running (sync mode)…' } });
              result = await api.backtestSync(cfg);
            } else throw e;
          }
          if (id) {
            set({ job: { id, status: 'queued', progress: 0 } });
            const j = await pollJob<BacktestResult>(id, s => set({ job: { id, status: s.status, progress: s.progress ?? 0, message: s.message } }), () => cancelled);
            if (j.status === 'error') throw new Error(j.error || j.message || 'Backtest failed');
            if (j.status === 'cancelled') { set({ job: null }); return; }
            result = j.result ?? null;
          }
          if (!result) throw new Error('Job finished without a result');
          const rec: RunRecord = {
            id: uid(),
            label: `${cfg.name || 'Strategy'} · ${cfg.und}`,
            at: Date.now(),
            config: cfg,
            result,
          };
          set({
            result, resultConfig: cfg, job: null,
            runs: [rec, ...get().runs].slice(0, 12),
            view: 'results',
          });
          window.scrollTo({ top: 0, behavior: 'smooth' });
        } catch (e) {
          set({ job: null, runError: (e as Error).message });
        }
      },

      cancel: async () => {
        cancelled = true;
        const id = get().job?.id;
        if (id) { try { await api.cancelJob(id); } catch { /* ignore */ } }
        set({ job: null });
      },

      openRun: id => {
        const r = get().runs.find(x => x.id === id);
        if (r) set({ result: r.result, resultConfig: r.config, view: 'results' });
      },

      toggleCompare: id => {
        const c = get().compare;
        if (c.includes(id)) set({ compare: c.filter(x => x !== id) });
        else set({ compare: [...c, id].slice(-4) });
      },
    }),
    {
      name: 'ql-builder',
      version: 1,
      partialize: s => ({ theme: s.theme, config: s.config, codes: s.codes, instrument: s.instrument, builder: s.builder, compileInfo: s.compileInfo }),
    },
  ),
);

export const cloneConfig = () => clone(useStore.getState().config);
