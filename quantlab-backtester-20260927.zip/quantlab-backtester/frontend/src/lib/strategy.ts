import type { Block, CmpOp, Leg, NotNode, Operand, Rule, RuleNode, StrategyConfig } from './types';

// ---------------------------------------------------------------- legs

export const makeLeg = (o: Partial<Leg> = {}): Leg => ({
  side: 'SELL', type: 'CE', lots: 1, expiry: 'weekly', strikeMode: 'atm', strikeValue: 0,
  sl: 0, slType: 'pct', tgt: 0, tgtType: 'pct', trailX: 0, trailY: 0, trailType: 'pct',
  reentries: 0, reentryMode: 'immediate', ...o,
});

export interface LegTemplate { key: string; name: string; hint: string; legs: () => Leg[] }

export const LEG_TEMPLATES: LegTemplate[] = [
  { key: 'short_straddle', name: 'Short Straddle', hint: 'Sell ATM CE + PE', legs: () => [makeLeg({ type: 'CE', sl: 25 }), makeLeg({ type: 'PE', sl: 25 })] },
  { key: 'short_strangle', name: 'Short Strangle', hint: 'Sell 2-step OTM CE + PE', legs: () => [makeLeg({ type: 'CE', strikeValue: 2, sl: 30 }), makeLeg({ type: 'PE', strikeValue: 2, sl: 30 })] },
  { key: 'iron_condor', name: 'Iron Condor', hint: 'Short strangle + wings', legs: () => [
    makeLeg({ type: 'CE', strikeValue: 3 }), makeLeg({ type: 'PE', strikeValue: 3 }),
    makeLeg({ side: 'BUY', type: 'CE', strikeValue: 8 }), makeLeg({ side: 'BUY', type: 'PE', strikeValue: 8 })] },
  { key: 'iron_butterfly', name: 'Iron Butterfly', hint: 'Short straddle + wings', legs: () => [
    makeLeg({ type: 'CE' }), makeLeg({ type: 'PE' }),
    makeLeg({ side: 'BUY', type: 'CE', strikeValue: 5 }), makeLeg({ side: 'BUY', type: 'PE', strikeValue: 5 })] },
  { key: 'bull_call_spread', name: 'Bull Call Spread', hint: 'Buy ATM CE, sell OTM CE', legs: () => [makeLeg({ side: 'BUY', type: 'CE' }), makeLeg({ type: 'CE', strikeValue: 4 })] },
  { key: 'bear_put_spread', name: 'Bear Put Spread', hint: 'Buy ATM PE, sell OTM PE', legs: () => [makeLeg({ side: 'BUY', type: 'PE' }), makeLeg({ type: 'PE', strikeValue: 4 })] },
  { key: 'long_straddle', name: 'Long Straddle', hint: 'Buy ATM CE + PE', legs: () => [makeLeg({ side: 'BUY', type: 'CE', sl: 30 }), makeLeg({ side: 'BUY', type: 'PE', sl: 30 })] },
  { key: 'calendar', name: 'Calendar', hint: 'Sell near, buy next expiry', legs: () => [
    makeLeg({ type: 'CE', expiry: 'weekly' }), makeLeg({ side: 'BUY', type: 'CE', expiry: 'next_weekly' })] },
];

export const EXPIRIES: [string, string][] = [
  ['weekly', 'Nearest weekly'], ['next_weekly', 'Next weekly'], ['far_weekly', '3rd weekly'],
  ['monthly', 'Monthly'], ['next_monthly', 'Next monthly'], ['far_monthly', 'Far monthly'],
];
export const FUT_EXPIRIES: [string, string][] = [['monthly', 'Current month'], ['next_monthly', 'Next month'], ['far_monthly', 'Far month']];

export const STRIKE_MODES: [string, string, string][] = [
  ['atm', 'ATM ± steps', 'Steps (+OTM / −ITM)'],
  ['pct', '% from spot', '% OTM'],
  ['premium', 'Closest premium', 'Premium ≈ ₹'],
  ['premium_gte', 'Premium ≥', 'Premium ≥ ₹'],
  ['premium_lte', 'Premium ≤', 'Premium ≤ ₹'],
  ['delta', 'Delta', 'Delta (0-100)'],
];

export const TIMEFRAMES = [1, 3, 5, 10, 15, 30, 60];

// ---------------------------------------------------------------- default config

export const defaultConfig = (): StrategyConfig => ({
  name: 'Untitled strategy',
  exch: 'NFO', und: 'NIFTY', start: '', end: '', capital: 1_000_000,
  mode: 'intraday', timeframe: 5, entryTime: '09:20', exitTime: '15:15', lastEntryTime: '14:30',
  weekdays: [1, 2, 3, 4, 5], dteMin: null, dteMax: null, maxTradesPerDay: 1,
  reenterAfterExit: false, exitDaysBeforeExpiry: 0, exitAllOnLegSl: false, exitOnOpposite: false,
  legs: LEG_TEMPLATES[0].legs(),
  overall: {},
  costs: { enabled: true, brokerage: 20, slippagePct: 0.1 },
  meta: { source: 'option' },
});

// ---------------------------------------------------------------- indicators

export interface ParamDef { key: 'n' | 'n2' | 'n3'; label: string; def: number }
export interface IndDef { name: string; label: string; group: string; params: ParamDef[]; src?: boolean }

const P = (key: ParamDef['key'], label: string, def: number): ParamDef => ({ key, label, def });
const len = (d: number) => [P('n', 'length', d)];

export const INDICATORS: IndDef[] = [
  ...['Open', 'High', 'Low', 'Close', 'Volume', 'HL2', 'HLC3', 'OHLC4'].map(n => ({ name: n, label: n, group: 'Price', params: [] })),
  ...['SMA', 'EMA', 'RMA', 'WMA', 'HMA', 'DEMA', 'TEMA', 'VWMA'].map(n => ({ name: n, label: n, group: 'Moving averages', params: len(n === 'EMA' ? 9 : 20), src: true })),
  { name: 'RSI', label: 'RSI', group: 'Oscillators', params: len(14), src: true },
  { name: 'MACD', label: 'MACD', group: 'Oscillators', params: [P('n', 'fast', 12), P('n2', 'slow', 26), P('n3', 'signal', 9)], src: true },
  { name: 'MACDSignal', label: 'MACD signal', group: 'Oscillators', params: [P('n', 'fast', 12), P('n2', 'slow', 26), P('n3', 'signal', 9)], src: true },
  { name: 'MACDHist', label: 'MACD hist', group: 'Oscillators', params: [P('n', 'fast', 12), P('n2', 'slow', 26), P('n3', 'signal', 9)], src: true },
  { name: 'CCI', label: 'CCI', group: 'Oscillators', params: len(20), src: true },
  { name: 'StochK', label: 'Stoch %K', group: 'Oscillators', params: [P('n', 'length', 14), P('n2', 'smooth K', 3)] },
  { name: 'StochD', label: 'Stoch %D', group: 'Oscillators', params: [P('n', 'length', 14), P('n2', 'smooth K', 3), P('n3', 'smooth D', 3)] },
  { name: 'WilliamsR', label: 'Williams %R', group: 'Oscillators', params: len(14) },
  { name: 'ROC', label: 'ROC %', group: 'Oscillators', params: len(10), src: true },
  { name: 'Momentum', label: 'Momentum', group: 'Oscillators', params: len(10), src: true },
  { name: 'UpperBB', label: 'Upper BB', group: 'Bands & volatility', params: [P('n', 'length', 20), P('n2', 'mult', 2)], src: true },
  { name: 'MidBB', label: 'Mid BB', group: 'Bands & volatility', params: [P('n', 'length', 20), P('n2', 'mult', 2)], src: true },
  { name: 'LowerBB', label: 'Lower BB', group: 'Bands & volatility', params: [P('n', 'length', 20), P('n2', 'mult', 2)], src: true },
  { name: 'ATR', label: 'ATR', group: 'Bands & volatility', params: len(14) },
  { name: 'Stdev', label: 'Std dev', group: 'Bands & volatility', params: len(20), src: true },
  { name: 'Zscore', label: 'Z-score', group: 'Bands & volatility', params: len(20), src: true },
  { name: 'Supertrend', label: 'Supertrend', group: 'Trend', params: [P('n', 'length', 10), P('n2', 'mult', 3)] },
  { name: 'SupertrendDir', label: 'Supertrend dir (±1)', group: 'Trend', params: [P('n', 'length', 10), P('n2', 'mult', 3)] },
  { name: 'ADX', label: 'ADX', group: 'Trend', params: [P('n', 'length', 14), P('n2', 'smoothing', 14)] },
  { name: 'PlusDI', label: '+DI', group: 'Trend', params: [P('n', 'length', 14), P('n2', 'smoothing', 14)] },
  { name: 'MinusDI', label: '−DI', group: 'Trend', params: [P('n', 'length', 14), P('n2', 'smoothing', 14)] },
  { name: 'VWAP', label: 'VWAP (session)', group: 'Trend', params: [] },
  { name: 'OBV', label: 'OBV', group: 'Trend', params: [] },
  { name: 'VIX', label: 'India VIX', group: 'Bands & volatility', params: [] },
  { name: 'Highest', label: 'Highest', group: 'Levels', params: len(20), src: true },
  { name: 'Lowest', label: 'Lowest', group: 'Levels', params: len(20), src: true },
  { name: 'HighestHigh', label: 'Highest high', group: 'Levels', params: len(20) },
  { name: 'LowestLow', label: 'Lowest low', group: 'Levels', params: len(20) },
  { name: 'Change', label: 'Change', group: 'Levels', params: [], src: true },
  { name: 'ChangePct', label: 'Change %', group: 'Levels', params: [], src: true },
  ...['DayOpen', 'DayHigh', 'DayLow', 'PrevDayHigh', 'PrevDayLow', 'PrevDayClose'].map(n => ({ name: n, label: n.replace(/([a-z])([A-Z])/g, '$1 $2'), group: 'Levels', params: [] })),
  { name: 'ORHigh', label: 'Opening-range high', group: 'Levels', params: [P('n', 'candles', 3)] },
  { name: 'ORLow', label: 'Opening-range low', group: 'Levels', params: [P('n', 'candles', 3)] },
];
export const IND_BY_NAME: Record<string, IndDef> = Object.fromEntries(INDICATORS.map(i => [i.name, i]));
export const SRC_FIELDS = ['Close', 'Open', 'High', 'Low', 'HL2', 'HLC3', 'OHLC4', 'Volume'];

export const OPS: [CmpOp, string][] = [
  ['>', '>'], ['>=', '≥'], ['<', '<'], ['<=', '≤'], ['==', '='], ['!=', '≠'],
  ['crosses_above', 'crosses above'], ['crosses_below', 'crosses below'], ['crosses', 'crosses'],
  ['is_true', 'is true'], ['is_false', 'is false'],
];

export const makeInd = (name: string): Operand => {
  const d = IND_BY_NAME[name];
  const o: Operand = { kind: 'ind', name };
  if (d) for (const p of d.params) (o as Record<string, unknown>)[p.key] = p.def;
  return o;
};

export const makeRule = (): Rule => ({ lhs: makeInd('EMA'), op: 'crosses_above', rhs: { kind: 'ind', name: 'EMA', n: 21 } });
export const emptyBlock = (logic: 'AND' | 'OR' = 'AND'): Block => ({ logic, rules: [] });

export const isNot = (n: RuleNode): n is NotNode => typeof n === 'object' && n !== null && 'not' in n;
export const isBlock = (n: RuleNode): n is Block => typeof n === 'object' && n !== null && 'logic' in n && 'rules' in n;
export const isRule = (n: RuleNode): n is Rule => typeof n === 'object' && n !== null && 'op' in n && 'lhs' in n;

// ---------------------------------------------------------------- describe (human readable)

const OPSYM: Record<string, string> = { '+': '+', '-': '−', '*': '×', '/': '÷' };

export function describeOperand(o: Operand | undefined): string {
  if (!o) return '?';
  const off = 'offset' in o && o.offset ? `[${o.offset}]` : '';
  switch (o.kind) {
    case 'const': return String(o.value);
    case 'dt': return o.field;
    case 'pos': return { PnL: 'Position P&L ₹', PnLpct: 'Position P&L %', MinsInTrade: 'Minutes in trade' }[o.field];
    case 'ind': {
      const d = IND_BY_NAME[o.name];
      const ps = (d?.params ?? []).map(p => o[p.key]).filter(v => v != null && v !== 0);
      const src = o.of ? describeOperand(o.of) : o.src && o.src !== 'Close' ? o.src : '';
      const args = [src, ...ps].filter(x => x !== '' && x != null);
      return `${o.name}${args.length ? `(${args.join(', ')})` : ''}${off}`;
    }
    case 'expr': {
      if (OPSYM[o.op] && o.args.length === 2) return `(${describeOperand(o.args[0])} ${OPSYM[o.op]} ${describeOperand(o.args[1])})${off}`;
      return `${o.op}(${o.args.map(describeOperand).join(', ')})${off}`;
    }
  }
}

export function describeNode(n: RuleNode, depth = 0): string {
  if (isNot(n)) return `NOT ${describeNode(n.not, depth + 1)}`;
  if (isBlock(n)) {
    const inner = n.rules.map(r => describeNode(r, depth + 1)).join(` ${n.logic} `);
    return depth > 0 && n.rules.length > 1 ? `(${inner})` : inner;
  }
  if (isRule(n)) {
    const op = OPS.find(x => x[0] === n.op)?.[1] ?? n.op;
    if (n.op === 'is_true' || n.op === 'is_false') return `${describeOperand(n.lhs)} ${op}`;
    return `${describeOperand(n.lhs)} ${op} ${describeOperand(n.rhs)}`;
  }
  return '?';
}

export const describeBlock = (b?: Block | null) => (b && b.rules.length ? describeNode(b) : '');

export function describeLeg(l: Leg): string {
  const strike = l.type === 'FUT' ? '' :
    l.strikeMode === 'atm' ? (l.strikeValue ? `ATM${l.strikeValue > 0 ? '+' : ''}${l.strikeValue}` : 'ATM') :
    l.strikeMode === 'pct' ? `${l.strikeValue}% OTM` :
    l.strikeMode === 'delta' ? `Δ${l.strikeValue}` :
    l.strikeMode === 'premium' ? `≈₹${l.strikeValue}` :
    l.strikeMode === 'premium_gte' ? `≥₹${l.strikeValue}` : `≤₹${l.strikeValue}`;
  const risk = [l.sl ? `SL ${l.sl}${l.slType === 'pct' ? '%' : 'pt'}` : '', l.tgt ? `TP ${l.tgt}${l.tgtType === 'pct' ? '%' : 'pt'}` : ''].filter(Boolean).join(' · ');
  return `${l.side} ${l.lots}× ${l.type}${strike ? ' ' + strike : ''} · ${l.expiry.replace('_', ' ')}${risk ? ' · ' + risk : ''}`;
}

export const hasSignals = (c: StrategyConfig) =>
  !!(c.entryConds && c.entryConds.rules.length) || !!(c.short && c.short.entryConds && c.short.entryConds.rules.length);

/** Normalise config before sending to the engine (drop empty overall fields, empty short side). */
export function cleanConfig(c: StrategyConfig): StrategyConfig {
  const out: StrategyConfig = JSON.parse(JSON.stringify(c));
  const ov: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(out.overall || {})) if (v !== '' && v != null && !Number.isNaN(v)) ov[k] = v;
  out.overall = ov;
  if (out.short && !out.short.legs.length && !(out.short.entryConds && out.short.entryConds.rules.length)) out.short = null;
  if (out.entryConds && !out.entryConds.rules.length) delete out.entryConds;
  if (out.exitConds && !out.exitConds.rules.length) delete out.exitConds;
  if (out.dteMin === undefined) out.dteMin = null;
  if (out.dteMax === undefined) out.dteMax = null;
  return out;
}

/** Set a value at a dotted path like "legs.0.sl" (used by optimizer apply). */
export function setPath<T extends object>(obj: T, path: string, value: unknown): T {
  const out = JSON.parse(JSON.stringify(obj));
  const ks = path.split('.');
  let cur: Record<string, unknown> = out;
  for (let i = 0; i < ks.length - 1; i++) {
    const k = ks[i];
    if (cur[k] == null || typeof cur[k] !== 'object') cur[k] = /^\d+$/.test(ks[i + 1]) ? [] : {};
    cur = cur[k] as Record<string, unknown>;
  }
  cur[ks[ks.length - 1]] = value;
  return out;
}

export function getPath(obj: unknown, path: string): unknown {
  return path.split('.').reduce<unknown>((o, k) => (o && typeof o === 'object' ? (o as Record<string, unknown>)[k] : undefined), obj);
}
