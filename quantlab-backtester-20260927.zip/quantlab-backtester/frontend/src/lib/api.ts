import type {
  BacktestResult, CompileDefaults, CompileResponse, Job, MarketplaceItem, Meta, OptimizeParam,
  SavedStrategy, StrategyConfig,
} from './types';

export class ApiError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

function detailToString(d: unknown): string {
  if (typeof d === 'string') return d;
  if (Array.isArray(d)) {
    return d.map(x => (x && typeof x === 'object' && 'msg' in x ? String((x as { msg: unknown }).msg) : JSON.stringify(x))).join('; ');
  }
  return JSON.stringify(d);
}

async function req<T>(method: string, path: string, body?: unknown, signal?: AbortSignal): Promise<T> {
  let r: Response;
  try {
    r = await fetch(path, {
      method,
      headers: body !== undefined ? { 'Content-Type': 'application/json' } : undefined,
      body: body !== undefined ? JSON.stringify(body) : undefined,
      signal,
    });
  } catch (e) {
    if ((e as Error).name === 'AbortError') throw e;
    throw new ApiError(0, 'Backend not reachable — is the server running on :8765?');
  }
  const text = await r.text();
  let data: unknown = null;
  try { data = text ? JSON.parse(text) : null; } catch { data = text; }
  if (!r.ok) {
    const detail = data && typeof data === 'object' && 'detail' in data ? detailToString((data as { detail: unknown }).detail) : r.statusText;
    const msg = r.status === 404 ? `${method} ${path} is not available on this server (404)` : detail || `HTTP ${r.status}`;
    throw new ApiError(r.status, msg);
  }
  return data as T;
}

export const api = {
  meta: () => req<Meta>('GET', '/api/meta'),
  compile: (source: 'prompt' | 'pine' | 'python', code: string, defaults: CompileDefaults) =>
    req<CompileResponse>('POST', '/api/strategy/compile', { source, code, defaults }),
  marketplace: () => req<MarketplaceItem[]>('GET', '/api/marketplace'),
  startJob: (config: StrategyConfig) => req<{ id: string }>('POST', '/api/jobs', { config }),
  startOptimize: (config: StrategyConfig, params: OptimizeParam[], metric: string) =>
    req<{ id: string }>('POST', '/api/jobs/optimize', { config, params, metric }),
  job: <R = BacktestResult>(id: string) => req<Job<R>>('GET', `/api/jobs/${encodeURIComponent(id)}`),
  cancelJob: (id: string) => req<unknown>('DELETE', `/api/jobs/${encodeURIComponent(id)}`),
  backtestSync: (config: StrategyConfig) => req<BacktestResult>('POST', '/api/backtest', config),
  strategies: () => req<SavedStrategy[]>('GET', '/api/strategies'),
  saveStrategy: (name: string, config: StrategyConfig) => req<SavedStrategy>('POST', '/api/strategies', { name, config }),
  deleteStrategy: (id: string) => req<unknown>('DELETE', `/api/strategies/${encodeURIComponent(id)}`),
};

export const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));

/** Poll a job until it finishes. `onTick` receives every snapshot. */
export async function pollJob<R>(id: string, onTick: (j: Job<R>) => void, isCancelled: () => boolean, every = 700): Promise<Job<R>> {
  for (;;) {
    const j = await api.job<R>(id);
    onTick(j);
    if (j.status === 'done' || j.status === 'error' || j.status === 'cancelled') return j;
    if (isCancelled()) return { ...j, status: 'cancelled' };
    await sleep(every);
  }
}
