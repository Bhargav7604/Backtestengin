// Types mirroring docs/STRATEGY_SCHEMA.md

export type Side = 'BUY' | 'SELL';
export type OptType = 'CE' | 'PE' | 'FUT';
export type Expiry = 'weekly' | 'next_weekly' | 'far_weekly' | 'monthly' | 'next_monthly' | 'far_monthly';
export type StrikeMode = 'atm' | 'pct' | 'premium' | 'premium_gte' | 'premium_lte' | 'delta';
export type Unit = 'pct' | 'pts';
export type ReentryMode = 'immediate' | 'same_strike' | 'cost';

export interface Leg {
  side: Side;
  type: OptType;
  lots: number;
  expiry: Expiry;
  strikeMode: StrikeMode;
  strikeValue: number;
  sl: number;
  slType: Unit;
  tgt: number;
  tgtType: Unit;
  trailX: number;
  trailY: number;
  trailType: Unit;
  reentries: number;
  reentryMode: ReentryMode;
}

export type Operand =
  | { kind: 'const'; value: number }
  | { kind: 'ind'; name: string; n?: number; src?: string; n2?: number; n3?: number; offset?: number; of?: Operand }
  | { kind: 'dt'; field: 'Time' | 'Hour' | 'Minute' | 'WeekDay' }
  | { kind: 'expr'; op: string; args: Operand[]; offset?: number }
  | { kind: 'pos'; field: 'PnL' | 'PnLpct' | 'MinsInTrade' };

export type CmpOp = '>' | '>=' | '<' | '<=' | '==' | '!=' | 'crosses_above' | 'crosses_below' | 'crosses' | 'is_true' | 'is_false';

export interface Rule { lhs: Operand; op: CmpOp; rhs: Operand }
export interface NotNode { not: Rule | Block }
export type RuleNode = Rule | Block | NotNode;
export interface Block { logic: 'AND' | 'OR'; rules: RuleNode[] }

export interface Overall {
  sl?: number | null; tgt?: number | null; lockAt?: number | null; lockProfit?: number | null;
  trailEvery?: number | null; trailBy?: number | null; slPctCapital?: number | null;
}

export type Source = 'prompt' | 'option' | 'indicator' | 'pine' | 'python' | 'marketplace';

export interface StrategyConfig {
  name?: string;
  exch: string;
  und: string;
  start: string;
  end: string;
  capital: number;
  mode: 'intraday' | 'positional';
  timeframe: number;
  entryTime: string;
  exitTime: string;
  lastEntryTime?: string;
  weekdays: number[];
  dteMin?: number | null;
  dteMax?: number | null;
  maxTradesPerDay: number;
  reenterAfterExit?: boolean;
  exitDaysBeforeExpiry?: number;
  exitAllOnLegSl?: boolean;
  exitOnOpposite?: boolean;
  legs: Leg[];
  entryConds?: Block;
  exitConds?: Block;
  short?: { legs: Leg[]; entryConds?: Block; exitConds?: Block } | null;
  overall: Overall;
  costs: { enabled: boolean; brokerage: number; slippagePct: number };
  meta?: { source?: Source | string; code?: string; [k: string]: unknown };
}

// ---- API shapes

export interface Underlying { exch: string; und: string; from: string; to: string; index: boolean; futures?: boolean; options?: boolean }
export interface Meta { underlyings: Underlying[]; calendar: string[]; index_map?: Record<string, unknown> }

export type Instrument = 'atm_options' | 'sell_options' | 'futures';
export interface CompileDefaults {
  exch: string; und: string; start: string; end: string; capital: number; timeframe: number;
  instrument: Instrument; lots: number; expiry: Expiry;
}
export interface CompileResponse { config: StrategyConfig; notes: string[]; warnings: string[] }

export interface MarketplaceItem {
  id: string; name: string; category: string; description: string; tags: string[];
  risk: 'Low' | 'Medium' | 'High'; style?: string; config: StrategyConfig;
  stats?: Partial<Stats> & Record<string, unknown>;
}

export interface SavedStrategy { id: string; name: string; source?: string; und?: string; updated?: string; config: StrategyConfig }

export type JobStatus = 'queued' | 'running' | 'done' | 'error' | 'cancelled';
export interface Job<R = unknown> {
  id: string; kind?: string; status: JobStatus; progress: number; message?: string; result?: R; error?: string;
}

export interface Stats {
  netPnl: number; grossPnl: number; charges: number; returnPct: number; cagr: number; trades: number;
  winRate: number; avgWin: number; avgLoss: number; avgTrade: number; bestTrade: number; worstTrade: number;
  profitFactor: number | null; expectancy: number; payoffRatio: number | null;
  maxDD: number; maxDDPct: number; maxDDDays: number; calmar: number | null; sharpe: number; sortino: number;
  maxWinStreak: number; maxLossStreak: number; tradedDays: number; sessions: number;
  winDays: number; lossDays: number; finalEquity: number;
}

export interface TradeLeg {
  leg: number; reentry: boolean; side: Side; type: OptType; expiry: string; strike: number; qty: number;
  entryTime: string; entry: number; exitTime: string; exit: number; reason: string; pnl: number; charges: number;
  iv: number | null; delta: number | null; sl?: number | null;
}
export interface Trade {
  id: number; side?: 'long' | 'short'; entryDate: string; entryTime: string; exitDate: string; exitTime: string;
  spotIn: number; exitReason: string; gross: number; charges: number; net: number; mae: number; mfe: number;
  premium?: number; legs: TradeLeg[];
}
export interface MonteCarlo {
  runs: number;
  maxDD: { p5: number; p50: number; p95: number };
  finalEquity: { p5: number; p50: number; p95: number };
  probLoss: number;
  bands: { i: number; p5: number; p50: number; p95: number }[];
}
export interface BacktestResult {
  stats: Stats;
  equity: { date: string; equity: number; dd: number }[];
  daily: { date: string; pnl: number }[];
  monthly: Record<string, number>;
  weekday: { day: number; pnl: number; trades: number; wins: number }[];
  byDte: { dte: number; pnl: number; trades: number }[];
  exitReasons: Record<string, number>;
  trades: Trade[];
  skipped: Record<string, number>;
  warnings: string[];
  spotSource?: string;
  benchmark?: { date: string; equity: number }[];
  montecarlo?: MonteCarlo | null;
  elapsed?: number;
  config?: StrategyConfig;
}

export interface OptimizeParam { path: string; values: (number | string)[] }
export interface OptimizeResult {
  metric: string;
  params: OptimizeParam[] | string[];
  grid: { values: (number | string)[]; stats: Partial<Stats> }[];
  best: { values: (number | string)[]; stats: Partial<Stats> } | null;
}

export interface RunRecord {
  id: string;
  label: string;
  at: number;
  config: StrategyConfig;
  result: BacktestResult;
}
