import clsx from 'clsx';
import { ArrowLeft, Code2, FileCode2, Layers, LineChart, MessageSquareText, Store } from 'lucide-react';
import { useStore, type BuilderKind } from '../lib/store';
import { hasSignals } from '../lib/strategy';
import CommonSettings from './CommonSettings';
import IndicatorBuilder from './builders/IndicatorBuilder';
import Marketplace from './builders/Marketplace';
import OptionBuilder from './builders/OptionBuilder';
import PineBuilder from './builders/PineBuilder';
import PromptBuilder from './builders/PromptBuilder';
import PythonBuilder from './builders/PythonBuilder';
import RunBar, { JobProgress } from './run/RunBar';
import { Alert } from './ui';

const TABS: [BuilderKind, string, typeof Layers][] = [
  ['prompt', 'Prompt', MessageSquareText], ['option', 'Option', Layers], ['indicator', 'Indicator', LineChart],
  ['pine', 'Pine', FileCode2], ['python', 'Python', Code2], ['marketplace', 'Marketplace', Store],
];

export default function BuilderPage() {
  const builder = useStore(s => s.builder);
  const go = useStore(s => s.go);
  const c = useStore(s => s.config);
  const compiled = useStore(s => (builder === 'prompt' || builder === 'pine' || builder === 'python') ? !!s.compileInfo[builder] && s.config.meta?.source === builder : true);
  const runError = useStore(s => s.runError);
  const clearErr = useStore(s => s.clearRunError);
  const job = useStore(s => s.job);

  const body = {
    prompt: <PromptBuilder />, option: <OptionBuilder />, indicator: <IndicatorBuilder />,
    pine: <PineBuilder />, python: <PythonBuilder />, marketplace: <Marketplace />,
  }[builder];

  return (
    <div>
      <div className="mb-5 flex flex-wrap items-center gap-3">
        <button className="btn-ghost btn-sm" onClick={() => go('home')}><ArrowLeft size={15} /> Create Strategy</button>
        <nav className="scroll-thin -mx-1 flex max-w-full gap-1 overflow-x-auto px-1">
          {TABS.map(([k, label, Icon]) => (
            <button key={k} onClick={() => go('builder', k)}
              className={clsx('inline-flex shrink-0 items-center gap-1.5 rounded-lg px-3 py-1.5 text-sm font-medium transition',
                builder === k ? 'bg-brand-600 text-white shadow-sm' : 'text-slate-600 hover:bg-white hover:text-brand-700 dark:text-slate-300 dark:hover:bg-slate-800')}>
              <Icon size={15} /> {label}
            </button>
          ))}
        </nav>
      </div>

      {builder === 'marketplace' ? (
        <>
          {(job || runError) && (
            <div className="sticky top-16 z-20 mb-4 space-y-2">
              {runError && <Alert onClose={clearErr}>Backtest failed: {runError}</Alert>}
              {job && <div className="card p-3 shadow-lg"><JobProgress /></div>}
            </div>
          )}
          {body}
        </>
      ) : (
        <div className="grid items-start gap-5 lg:grid-cols-[minmax(0,1fr)_360px]">
          <div className="min-w-0">
            {body}
            <RunBar disabledReason={compiled ? undefined : builder === 'prompt' ? 'Build the strategy first' : 'Convert the code first'} />
          </div>
          <aside className="lg:sticky lg:top-20 lg:max-h-[calc(100vh-6rem)] lg:overflow-y-auto scroll-thin">
            <CommonSettings signals={hasSignals(c)} />
          </aside>
        </div>
      )}
    </div>
  );
}
