import { useCallback, useEffect, useState } from 'react';
import { ArrowRight, Bookmark, Clock, FolderOpen, RefreshCw, Trash2 } from 'lucide-react';
import { useStore, type BuilderKind } from '../../lib/store';
import { api } from '../../lib/api';
import { hasSignals } from '../../lib/strategy';
import { inrCompact, signCls, timeAgo } from '../../lib/format';
import type { SavedStrategy } from '../../lib/types';
import { Alert, Empty, Spinner } from '../ui';
import { IndicatorArt, MarketArt, OptionArt, PineArt, PromptArt, PythonArt } from './Illustrations';

const CARDS: { kind: BuilderKind; title: string; text: string; Art: () => JSX.Element }[] = [
  { kind: 'prompt', title: 'Prompt to Strategy', text: 'Describe the structure in plain English and the builder assembles the strategy', Art: PromptArt },
  { kind: 'option', title: 'Option Based', text: 'Construct multi-leg strategies by delta, strike or moneyness.', Art: OptionArt },
  { kind: 'indicator', title: 'Indicator Based', text: 'Create entry and exit logic from price and indicators.', Art: IndicatorArt },
  { kind: 'pine', title: 'Pine Based', text: 'Import supported TradingView Pine Script v4/v5 strategy logic.', Art: PineArt },
  { kind: 'python', title: 'Python Based', text: 'Import a supported Quantlab Python DSL strategy.', Art: PythonArt },
  { kind: 'marketplace', title: 'Not Sure Yet?', text: 'You can choose algos from marketplace as per your preferences', Art: MarketArt },
];

export default function Home() {
  const go = useStore(s => s.go);
  return (
    <div className="space-y-10">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900 sm:text-3xl dark:text-white">Create Strategy</h1>
        <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">Pick how you want to build. Every mode compiles to the same engine and runs on real 1-minute NFO / BFO data.</p>
      </div>
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {CARDS.map(({ kind, title, text, Art }) => (
          <button key={kind} onClick={() => go('builder', kind)} className="card-mint card-hover group flex flex-col text-left focus:outline-none focus-visible:ring-2 focus-visible:ring-brand-500">
            <div className="h-40 px-6 pt-4 sm:h-44"><Art /></div>
            <div className="flex flex-1 flex-col px-5 pb-5 pt-1">
              <div className="flex items-center gap-2">
                <h2 className="text-base font-semibold text-slate-900 dark:text-white">{title}</h2>
                <ArrowRight size={16} className="ml-auto -translate-x-1 text-brand-600 opacity-0 transition group-hover:translate-x-0 group-hover:opacity-100" />
              </div>
              <p className="mt-1 text-sm leading-relaxed text-slate-500 dark:text-slate-400">{text}</p>
            </div>
          </button>
        ))}
      </div>
      <MyStrategies />
      <RecentRuns />
    </div>
  );
}

function MyStrategies() {
  const { replaceConfig, go } = useStore.getState();
  const [items, setItems] = useState<SavedStrategy[] | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try { setItems(await api.strategies()); setErr(null); } catch (e) { setErr((e as Error).message); } finally { setLoading(false); }
  }, []);
  useEffect(() => { load(); }, [load]);

  const open = (s: SavedStrategy) => {
    replaceConfig({ ...s.config, name: s.name });
    const src = (s.source || s.config.meta?.source) as BuilderKind | undefined;
    const kind: BuilderKind = src === 'pine' || src === 'python' ? src : hasSignals(s.config) ? 'indicator' : 'option';
    if (kind === 'pine' || kind === 'python') {
      const code = s.config.meta?.code;
      if (typeof code === 'string') useStore.getState().setCode(kind, code);
    }
    go('builder', kind);
  };
  const remove = async (id: string) => {
    if (!confirm('Delete this saved strategy?')) return;
    try { await api.deleteStrategy(id); load(); } catch (e) { setErr((e as Error).message); }
  };

  return (
    <section>
      <div className="mb-3 flex items-center gap-2">
        <Bookmark size={16} className="text-brand-600" />
        <h2 className="text-base font-semibold">My strategies</h2>
        <button className="btn-ghost btn-sm ml-auto" onClick={load} disabled={loading}>{loading ? <Spinner className="h-3 w-3" /> : <RefreshCw size={13} />} Refresh</button>
      </div>
      {err ? <Alert kind="warn">Couldn't load saved strategies: {err}</Alert> :
        items == null ? <div className="flex gap-3">{[0, 1, 2].map(i => <div key={i} className="card h-24 w-64 shrink-0 animate-pulse" />)}</div> :
        !items.length ? <Empty>No saved strategies yet. Run a backtest and hit <b>Save strategy</b>.</Empty> : (
          <div className="scroll-thin -mx-1 flex gap-3 overflow-x-auto px-1 pb-2">
            {items.map(s => (
              <div key={s.id} className="card card-hover w-64 shrink-0 p-4">
                <div className="flex items-start gap-2">
                  <div className="min-w-0">
                    <div className="truncate font-semibold">{s.name}</div>
                    <div className="mt-0.5 text-xs text-slate-500">{s.und || s.config.und} · {s.source || s.config.meta?.source || 'custom'} · {timeAgo(s.updated)}</div>
                  </div>
                  <button className="btn-ghost btn-sm ml-auto text-slate-400 hover:text-rose-600" onClick={() => remove(s.id)} aria-label="Delete"><Trash2 size={14} /></button>
                </div>
                <div className="mt-3 flex gap-2">
                  <button className="btn btn-sm" onClick={() => open(s)}><FolderOpen size={13} /> Open</button>
                  <button className="btn btn-sm" onClick={() => useStore.getState().run(s.config)}>Backtest</button>
                </div>
              </div>
            ))}
          </div>
        )}
    </section>
  );
}

function RecentRuns() {
  const runs = useStore(s => s.runs);
  const openRun = useStore(s => s.openRun);
  if (!runs.length) return null;
  return (
    <section>
      <div className="mb-3 flex items-center gap-2">
        <Clock size={16} className="text-brand-600" />
        <h2 className="text-base font-semibold">Recent runs</h2>
        <span className="text-xs text-slate-400">this session</span>
      </div>
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {runs.slice(0, 8).map(r => (
          <button key={r.id} onClick={() => openRun(r.id)} className="card card-hover p-4 text-left">
            <div className="truncate text-sm font-semibold">{r.label}</div>
            <div className="text-xs text-slate-500">{r.config.start} → {r.config.end} · {timeAgo(r.at)}</div>
            <div className="mt-2 flex items-baseline gap-3">
              <span className={`text-lg font-bold ${signCls(r.result.stats.netPnl)}`}>{inrCompact(r.result.stats.netPnl)}</span>
              <span className="text-xs text-slate-500">{r.result.stats.trades} trades · {r.result.stats.winRate}% win</span>
            </div>
          </button>
        ))}
      </div>
    </section>
  );
}
