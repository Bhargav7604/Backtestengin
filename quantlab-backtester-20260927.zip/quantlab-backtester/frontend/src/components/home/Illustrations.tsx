// Hand-drawn isometric illustrations (pure SVG, no external assets).
import type { ReactNode } from 'react';

const C = 0.866;
const OX = 120, OY = 70;
const iso = (x: number, y: number, z: number): [number, number] => [OX + (x - y) * C, OY + (x + y) * 0.5 - z];
const pts = (...p: [number, number][]) => p.map(([a, b]) => `${a.toFixed(1)},${b.toFixed(1)}`).join(' ');

interface Tone { top: string; left: string; right: string }
const G: Tone = { top: '#86efac', left: '#22c55e', right: '#16a34a' };
const G2: Tone = { top: '#bbf7d0', left: '#4ade80', right: '#22c55e' };
const G3: Tone = { top: '#dcfce7', left: '#a7f3c1', right: '#86efac' };
const W: Tone = { top: '#ffffff', left: '#eef2f6', right: '#dbe3ec' };
const S: Tone = { top: '#e2e8f0', left: '#cbd5e1', right: '#94a3b8' };
const D: Tone = { top: '#475569', left: '#334155', right: '#1e293b' };

function Box({ x, y, z = 0, w, d, h, t, stroke = 'rgba(15,23,42,.06)' }: { x: number; y: number; z?: number; w: number; d: number; h: number; t: Tone; stroke?: string }) {
  const top = pts(iso(x, y, z + h), iso(x + w, y, z + h), iso(x + w, y + d, z + h), iso(x, y + d, z + h));
  const left = pts(iso(x, y + d, z), iso(x + w, y + d, z), iso(x + w, y + d, z + h), iso(x, y + d, z + h));
  const right = pts(iso(x + w, y, z), iso(x + w, y + d, z), iso(x + w, y + d, z + h), iso(x + w, y, z + h));
  return (
    <g stroke={stroke} strokeWidth={0.6} strokeLinejoin="round">
      <polygon points={left} fill={t.left} />
      <polygon points={right} fill={t.right} />
      <polygon points={top} fill={t.top} />
    </g>
  );
}

/** Line drawn on the front-left face plane (y = const). */
function FaceLine({ x1, x2, y, z, color = '#94a3b8', w = 2 }: { x1: number; x2: number; y: number; z: number; color?: string; w?: number }) {
  const [a, b] = iso(x1, y, z), [c, d] = iso(x2, y, z);
  return <line x1={a} y1={b} x2={c} y2={d} stroke={color} strokeWidth={w} strokeLinecap="round" />;
}
/** Polyline on the y-plane using (x, z) pairs. */
function FacePath({ y, p, color, w = 2 }: { y: number; p: [number, number][]; color: string; w?: number }) {
  return <polyline points={pts(...p.map(([x, z]) => iso(x, y, z)))} fill="none" stroke={color} strokeWidth={w} strokeLinecap="round" strokeLinejoin="round" />;
}

function Platform() {
  return (
    <>
      <ellipse cx={OX} cy={OY + 62} rx={96} ry={20} fill="rgba(22,163,74,.10)" />
      <Box x={-10} y={-10} w={110} d={110} h={8} z={-8} t={W} />
      <polygon points={pts(iso(-2, -2, 0), iso(92, -2, 0), iso(92, 92, 0), iso(-2, 92, 0))} fill="none" stroke="#bbf7d0" strokeWidth={1} strokeDasharray="3 3" />
    </>
  );
}

function Frame({ children }: { children: ReactNode }) {
  return (
    <svg viewBox="0 0 240 150" className="h-full w-full" aria-hidden="true">
      <Platform />
      {children}
    </svg>
  );
}

function Sparkle({ x, y, s = 6, c = '#22c55e' }: { x: number; y: number; s?: number; c?: string }) {
  return <path d={`M${x} ${y - s}Q${x} ${y} ${x + s} ${y}Q${x} ${y} ${x} ${y + s}Q${x} ${y} ${x - s} ${y}Q${x} ${y} ${x} ${y - s}Z`} fill={c} />;
}

export function PromptArt() {
  return (
    <Frame>
      {/* chat slab */}
      <Box x={10} y={52} w={62} d={6} h={58} t={W} />
      <FaceLine x1={18} x2={60} y={58} z={46} color="#22c55e" w={3} />
      <FaceLine x1={18} x2={52} y={58} z={37} />
      <FaceLine x1={18} x2={46} y={58} z={29} />
      <FaceLine x1={18} x2={56} y={58} z={21} />
      {/* bubble tail */}
      <polygon points={pts(iso(20, 58, 0), iso(30, 58, 0), iso(22, 62, -8))} fill="#eef2f6" />
      {/* gear-ish block stack = "builder" */}
      <Box x={62} y={10} w={22} d={22} h={14} t={G} />
      <Box x={66} y={14} w={14} d={14} h={12} z={14} t={G2} />
      <Box x={40} y={20} w={14} d={14} h={8} t={S} />
      <Sparkle x={196} y={30} s={7} />
      <Sparkle x={182} y={44} s={4} c="#86efac" />
      <Sparkle x={46} y={30} s={5} c="#4ade80" />
    </Frame>
  );
}

export function OptionArt() {
  return (
    <Frame>
      {/* four legs as columns */}
      <Box x={8} y={48} w={14} d={14} h={22} t={S} />
      <Box x={28} y={34} w={14} d={14} h={46} t={G} />
      <Box x={48} y={20} w={14} d={14} h={46} t={G2} />
      <Box x={68} y={6} w={14} d={14} h={22} t={S} />
      {/* payoff slab */}
      <Box x={16} y={74} w={70} d={4} h={34} t={W} />
      <FacePath y={78} color="#16a34a" w={2.4} p={[[20, 8], [34, 8], [46, 26], [56, 26], [68, 8], [82, 8]]} />
      <FaceLine x1={20} x2={82} y={78} z={14} color="#cbd5e1" w={1} />
    </Frame>
  );
}

export function IndicatorArt() {
  const candles: [number, number, number, boolean][] = [[10, 10, 18, true], [22, 20, 14, false], [34, 14, 24, true], [46, 26, 20, true], [58, 34, 16, false], [70, 30, 28, true]];
  return (
    <Frame>
      <Box x={4} y={70} w={84} d={4} h={62} t={W} />
      {candles.map(([x, z, h, up], i) => {
        const [wx, wy1] = iso(x + 3, 74, z - 4);
        const [, wy2] = iso(x + 3, 74, z + h + 4);
        return (
          <g key={i}>
            <line x1={wx} y1={wy1} x2={wx} y2={wy2} stroke={up ? '#16a34a' : '#94a3b8'} strokeWidth={1.2} />
            <polygon points={pts(iso(x, 74, z), iso(x + 6, 74, z), iso(x + 6, 74, z + h), iso(x, 74, z + h))} fill={up ? '#22c55e' : '#cbd5e1'} />
          </g>
        );
      })}
      <FacePath y={74} color="#15803d" w={2} p={[[8, 22], [20, 26], [32, 28], [44, 36], [56, 42], [68, 46], [80, 54]]} />
      <Box x={62} y={8} w={20} d={20} h={16} t={G} />
      <Box x={40} y={10} w={14} d={14} h={10} t={G3} />
    </Frame>
  );
}

export function PineArt() {
  const tree = (x: number, y: number, s: number) => {
    const [bx, by] = iso(x, y, 0);
    return (
      <g>
        <rect x={bx - 2} y={by - 8 * s} width={4} height={8 * s} fill="#92400e" opacity={0.7} />
        <polygon points={`${bx},${by - 44 * s} ${bx - 14 * s},${by - 18 * s} ${bx + 14 * s},${by - 18 * s}`} fill="#16a34a" />
        <polygon points={`${bx},${by - 54 * s} ${bx - 11 * s},${by - 32 * s} ${bx + 11 * s},${by - 32 * s}`} fill="#22c55e" />
        <polygon points={`${bx},${by - 44 * s} ${bx},${by - 18 * s} ${bx + 14 * s},${by - 18 * s}`} fill="#15803d" opacity={0.5} />
      </g>
    );
  };
  return (
    <Frame>
      <Box x={8} y={56} w={56} d={5} h={52} t={D} />
      <FaceLine x1={14} x2={30} y={61} z={42} color="#4ade80" />
      <FaceLine x1={18} x2={50} y={61} z={34} color="#e2e8f0" />
      <FaceLine x1={18} x2={42} y={61} z={26} color="#86efac" />
      <FaceLine x1={14} x2={36} y={61} z={18} color="#e2e8f0" />
      <FaceLine x1={18} x2={46} y={61} z={10} color="#94a3b8" />
      {tree(74, 22, 1)}
      {tree(56, 12, 0.72)}
      {tree(84, 48, 0.6)}
    </Frame>
  );
}

export function PythonArt() {
  return (
    <Frame>
      <Box x={6} y={46} w={70} d={5} h={56} t={W} />
      {/* window bar */}
      <polygon points={pts(iso(6, 51, 56), iso(76, 51, 56), iso(76, 51, 48), iso(6, 51, 48))} fill="#dcfce7" />
      {[10, 15, 20].map(x => { const [a, b] = iso(x, 51, 52); return <circle key={x} cx={a} cy={b} r={1.6} fill="#16a34a" />; })}
      <FaceLine x1={12} x2={26} y={51} z={38} color="#16a34a" w={2.4} />
      <FaceLine x1={30} x2={60} y={51} z={38} color="#94a3b8" />
      <FaceLine x1={18} x2={52} y={51} z={30} color="#cbd5e1" />
      <FaceLine x1={18} x2={44} y={51} z={22} color="#4ade80" />
      <FaceLine x1={12} x2={40} y={51} z={14} color="#cbd5e1" />
      {/* twin cubes */}
      <Box x={60} y={6} w={18} d={18} h={18} t={G} />
      <Box x={70} y={28} w={14} d={14} h={14} t={{ top: '#e2e8f0', left: '#94a3b8', right: '#64748b' }} />
      <Box x={63} y={9} w={12} d={12} h={10} z={18} t={G3} />
    </Frame>
  );
}

export function MarketArt() {
  return (
    <Frame>
      {/* shelves */}
      <Box x={6} y={40} w={60} d={20} h={10} t={S} />
      <Box x={10} y={44} w={14} d={12} h={12} z={10} t={G} />
      <Box x={28} y={44} w={14} d={12} h={18} z={10} t={G2} />
      <Box x={46} y={44} w={14} d={12} h={8} z={10} t={G3} />
      <Box x={60} y={6} w={24} d={24} h={10} t={W} />
      <Box x={64} y={10} w={16} d={16} h={14} z={10} t={G} />
      {/* question bubble */}
      <circle cx={186} cy={34} r={16} fill="#ffffff" stroke="#bbf7d0" strokeWidth={2} />
      <path d="M180 30a6 6 0 1 1 8 5.5c-1.6.7-2 1.4-2 3" fill="none" stroke="#16a34a" strokeWidth={2.6} strokeLinecap="round" />
      <circle cx={186} cy={43.5} r={1.8} fill="#16a34a" />
      <Sparkle x={54} y={30} s={5} />
    </Frame>
  );
}
