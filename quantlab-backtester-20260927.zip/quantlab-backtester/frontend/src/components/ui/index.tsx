import { useEffect, type ReactNode } from 'react';
import clsx from 'clsx';
import { AlertTriangle, Info, X, XCircle } from 'lucide-react';

export function Field({ label, children, className, hint }: { label: ReactNode; children: ReactNode; className?: string; hint?: ReactNode }) {
  return (
    <div className={clsx('min-w-0', className)}>
      <label className="lbl">{label}</label>
      {children}
      {hint && <div className="mt-1 text-[11px] text-slate-400">{hint}</div>}
    </div>
  );
}

interface NumProps {
  value: number | null | undefined;
  onChange: (v: number | null) => void;
  placeholder?: string;
  min?: number;
  max?: number;
  step?: number | string;
  className?: string;
  small?: boolean;
  title?: string;
}
/** Number input where an empty field means null ("off"). */
export function NumInput({ value, onChange, small, className, ...rest }: NumProps) {
  return (
    <input
      type="number"
      className={clsx('inp', small && 'inp-sm', className)}
      value={value == null || Number.isNaN(value) ? '' : value}
      onChange={e => onChange(e.target.value === '' ? null : +e.target.value)}
      {...rest}
    />
  );
}

export function TextInput({ value, onChange, className, small, ...rest }: { value: string; onChange: (v: string) => void; className?: string; small?: boolean; type?: string; placeholder?: string; min?: string; max?: string }) {
  return <input className={clsx('inp', small && 'inp-sm', className)} value={value} onChange={e => onChange(e.target.value)} {...rest} />;
}

export function Select<T extends string | number>({ value, onChange, options, className, small, title }: {
  value: T; onChange: (v: T) => void; options: readonly (readonly [T, string])[]; className?: string; small?: boolean; title?: string;
}) {
  return (
    <select
      title={title}
      className={clsx('inp pr-7', small && 'inp-sm', className)}
      value={String(value)}
      onChange={e => {
        const found = options.find(o => String(o[0]) === e.target.value);
        if (found) onChange(found[0]);
      }}
    >
      {options.map(([v, t]) => <option key={String(v)} value={String(v)}>{t}</option>)}
    </select>
  );
}

export function Segmented<T extends string>({ value, onChange, options, small }: { value: T; onChange: (v: T) => void; options: readonly (readonly [T, ReactNode])[]; small?: boolean }) {
  return (
    <div className="inline-flex rounded-lg border border-slate-200 bg-slate-100/70 p-0.5 dark:border-slate-700 dark:bg-slate-800">
      {options.map(([v, t]) => (
        <button
          key={v}
          type="button"
          onClick={() => onChange(v)}
          className={clsx(
            'rounded-md font-medium transition',
            small ? 'px-2 py-0.5 text-xs' : 'px-3 py-1 text-[13px]',
            value === v ? 'bg-white text-brand-700 shadow-sm dark:bg-slate-900 dark:text-brand-400' : 'text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200',
          )}
        >
          {t}
        </button>
      ))}
    </div>
  );
}

export function Toggle({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label?: ReactNode }) {
  return (
    <label className="inline-flex cursor-pointer select-none items-center gap-2 text-sm">
      <button
        type="button"
        role="switch"
        aria-checked={checked}
        onClick={() => onChange(!checked)}
        className={clsx('relative h-5 w-9 shrink-0 rounded-full transition', checked ? 'bg-brand-600' : 'bg-slate-300 dark:bg-slate-600')}
      >
        <span className={clsx('absolute top-0.5 h-4 w-4 rounded-full bg-white shadow transition', checked ? 'left-[18px]' : 'left-0.5')} />
      </button>
      {label && <span className="text-slate-700 dark:text-slate-300">{label}</span>}
    </label>
  );
}

export function Chip({ on, onClick, children, className }: { on?: boolean; onClick?: () => void; children: ReactNode; className?: string }) {
  return (
    <button type="button" className={clsx('chip', on && 'chip-on', className)} onClick={onClick}>
      {children}
    </button>
  );
}

export function Card({ title, icon, actions, children, className, bodyClass }: {
  title?: ReactNode; icon?: ReactNode; actions?: ReactNode; children: ReactNode; className?: string; bodyClass?: string;
}) {
  return (
    <section className={clsx('card', className)}>
      {(title || actions) && (
        <header className="flex flex-wrap items-center gap-2 border-b border-slate-100 px-4 py-3 dark:border-slate-800">
          {icon && <span className="text-brand-600 dark:text-brand-400">{icon}</span>}
          <h3 className="text-sm font-semibold text-slate-800 dark:text-slate-100">{title}</h3>
          {actions && <div className="ml-auto flex flex-wrap items-center gap-2">{actions}</div>}
        </header>
      )}
      <div className={clsx('p-4', bodyClass)}>{children}</div>
    </section>
  );
}

export function Alert({ kind = 'error', children, onClose }: { kind?: 'error' | 'warn' | 'info'; children: ReactNode; onClose?: () => void }) {
  const Icon = kind === 'error' ? XCircle : kind === 'warn' ? AlertTriangle : Info;
  return (
    <div className={clsx('flex items-start gap-2 rounded-xl border px-3 py-2.5 text-sm',
      kind === 'error' && 'border-rose-200 bg-rose-50 text-rose-800 dark:border-rose-900 dark:bg-rose-950/40 dark:text-rose-200',
      kind === 'warn' && 'border-amber-200 bg-amber-50 text-amber-800 dark:border-amber-900 dark:bg-amber-950/40 dark:text-amber-200',
      kind === 'info' && 'border-brand-200 bg-brand-50 text-brand-800 dark:border-brand-900 dark:bg-brand-950/40 dark:text-brand-200')}>
      <Icon size={16} className="mt-0.5 shrink-0" />
      <div className="min-w-0 flex-1 break-words">{children}</div>
      {onClose && <button onClick={onClose} className="opacity-60 hover:opacity-100" aria-label="Dismiss"><X size={14} /></button>}
    </div>
  );
}

export function Modal({ open, onClose, title, children, wide }: { open: boolean; onClose: () => void; title: ReactNode; children: ReactNode; wide?: boolean }) {
  useEffect(() => {
    if (!open) return;
    const h = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-slate-900/40 p-0 backdrop-blur-sm sm:items-center sm:p-4" onClick={onClose}>
      <div className={clsx('card max-h-[92vh] w-full overflow-auto rounded-b-none sm:rounded-2xl scroll-thin', wide ? 'sm:max-w-4xl' : 'sm:max-w-lg')} onClick={e => e.stopPropagation()}>
        <header className="sticky top-0 z-10 flex items-center gap-2 border-b border-slate-100 bg-white px-4 py-3 dark:border-slate-800 dark:bg-slate-900">
          <h3 className="text-sm font-semibold">{title}</h3>
          <button className="btn-ghost btn-sm ml-auto" onClick={onClose} aria-label="Close"><X size={16} /></button>
        </header>
        <div className="p-4">{children}</div>
      </div>
    </div>
  );
}

export function Spinner({ className }: { className?: string }) {
  return <span className={clsx('inline-block h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent', className)} />;
}

export function Empty({ children }: { children: ReactNode }) {
  return <div className="rounded-xl border border-dashed border-slate-200 px-4 py-6 text-center text-sm text-slate-400 dark:border-slate-700">{children}</div>;
}
