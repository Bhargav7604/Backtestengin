import clsx from 'clsx';
import { INDICATORS, IND_BY_NAME, makeInd, SRC_FIELDS } from '../../lib/strategy';
import type { Operand } from '../../lib/types';

const GROUPS = Array.from(new Set(INDICATORS.map(i => i.group)));
const EXPR_OPS: [string, string, number][] = [
  ['+', 'a + b', 2], ['-', 'a − b', 2], ['*', 'a × b', 2], ['/', 'a ÷ b', 2], ['max', 'max(a,b)', 2], ['min', 'min(a,b)', 2],
  ['pow', 'a ^ b', 2], ['abs', 'abs(a)', 1], ['neg', '−a', 1], ['sqrt', '√a', 1], ['log', 'log(a)', 1],
];

const keyOf = (o: Operand) =>
  o.kind === 'ind' ? `ind:${o.name}` : o.kind === 'const' ? 'const' : o.kind === 'expr' ? 'expr' : `${o.kind}:${o.field}`;

function fromKey(k: string, prev: Operand): Operand {
  if (k === 'const') return { kind: 'const', value: prev.kind === 'const' ? prev.value : 0 };
  if (k === 'expr') return { kind: 'expr', op: '-', args: [prev.kind === 'expr' ? prev.args[0] : prev, { kind: 'const', value: 0 }] };
  const [kind, v] = k.split(':');
  if (kind === 'ind') return makeInd(v);
  if (kind === 'dt') return { kind: 'dt', field: v as 'Time' };
  return { kind: 'pos', field: v as 'PnL' };
}

const mini = 'h-8 rounded-lg border border-slate-200 bg-white px-1.5 text-[13px] outline-none focus:border-brand-500 dark:border-slate-700 dark:bg-slate-800';

export default function OperandPicker({ value, onChange, allowPos, depth = 0 }: { value: Operand; onChange: (o: Operand) => void; allowPos?: boolean; depth?: number }) {
  const o = value;
  const def = o.kind === 'ind' ? IND_BY_NAME[o.name] : undefined;
  return (
    <div className={clsx('inline-flex flex-wrap items-center gap-1', o.kind === 'expr' && 'rounded-lg border border-dashed border-brand-300 p-1 dark:border-brand-800')}>
      <select className={clsx(mini, 'max-w-[11rem] font-medium')} value={keyOf(o)} onChange={e => onChange(fromKey(e.target.value, o))}>
        {GROUPS.map(g => (
          <optgroup key={g} label={g}>
            {INDICATORS.filter(i => i.group === g).map(i => <option key={i.name} value={`ind:${i.name}`}>{i.label}</option>)}
          </optgroup>
        ))}
        <optgroup label="Value">
          <option value="const">Number</option>
          <option value="dt:Time">Time (HHMM)</option>
          <option value="dt:Hour">Hour</option>
          <option value="dt:Minute">Minute</option>
          <option value="dt:WeekDay">Weekday (1-7)</option>
          {depth < 2 && <option value="expr">Expression…</option>}
        </optgroup>
        {allowPos && (
          <optgroup label="Position (exit only)">
            <option value="pos:PnL">Position P&L ₹</option>
            <option value="pos:PnLpct">Position P&L %</option>
            <option value="pos:MinsInTrade">Minutes in trade</option>
          </optgroup>
        )}
      </select>

      {o.kind === 'const' && (
        <input type="number" className={clsx(mini, 'w-20')} value={o.value} onChange={e => onChange({ ...o, value: +e.target.value })} />
      )}

      {o.kind === 'ind' && def?.src && (
        <select className={clsx(mini, 'w-[4.6rem]')} title="source" value={o.src ?? 'Close'} onChange={e => onChange({ ...o, src: e.target.value })}>
          {SRC_FIELDS.map(s => <option key={s}>{s}</option>)}
        </select>
      )}
      {o.kind === 'ind' && def?.params.map(p => (
        <label key={p.key} className="inline-flex items-center gap-0.5 text-[10px] uppercase text-slate-400" title={p.label}>
          {p.label.slice(0, 6)}
          <input type="number" className={clsx(mini, 'w-14')} value={o[p.key] ?? p.def} step={p.label === 'mult' ? 0.5 : 1}
            onChange={e => onChange({ ...o, [p.key]: +e.target.value })} />
        </label>
      ))}
      {(o.kind === 'ind' || o.kind === 'expr') && (
        <label className="inline-flex items-center gap-0.5 text-[10px] uppercase text-slate-400" title="Value k candles ago (Pine x[k])">
          ago
          <input type="number" min={0} className={clsx(mini, 'w-11')} value={o.offset ?? 0} onChange={e => onChange({ ...o, offset: Math.max(0, +e.target.value) })} />
        </label>
      )}

      {o.kind === 'expr' && (() => {
        const arity = EXPR_OPS.find(x => x[0] === o.op)?.[2] ?? 2;
        const setArg = (i: number, a: Operand) => onChange({ ...o, args: o.args.map((x, j) => (j === i ? a : x)) });
        return (
          <>
            <OperandPicker value={o.args[0] ?? { kind: 'const', value: 0 }} onChange={a => setArg(0, a)} depth={depth + 1} />
            <select className={clsx(mini, 'font-mono')} value={o.op} onChange={e => {
              const ar = EXPR_OPS.find(x => x[0] === e.target.value)?.[2] ?? 2;
              const args = ar === 1 ? o.args.slice(0, 1) : [o.args[0] ?? { kind: 'const', value: 0 }, o.args[1] ?? { kind: 'const', value: 0 }];
              onChange({ ...o, op: e.target.value, args: args as Operand[] });
            }}>
              {EXPR_OPS.map(([k, t]) => <option key={k} value={k}>{t}</option>)}
            </select>
            {arity === 2 && <OperandPicker value={o.args[1] ?? { kind: 'const', value: 0 }} onChange={a => setArg(1, a)} depth={depth + 1} />}
          </>
        );
      })()}
    </div>
  );
}
