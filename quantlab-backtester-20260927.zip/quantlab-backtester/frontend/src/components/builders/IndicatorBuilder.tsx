import { ArrowDownRight, ArrowUpRight, Sparkles } from 'lucide-react';
import { useStore } from '../../lib/store';
import { emptyBlock, makeLeg } from '../../lib/strategy';
import type { Block, Leg, StrategyConfig } from '../../lib/types';
import { Card, Toggle } from '../ui';
import BlockEditor from './BlockEditor';
import LegsEditor from './LegsEditor';

const ema = (n: number) => ({ kind: 'ind' as const, name: 'EMA', n });
const k = (v: number) => ({ kind: 'const' as const, value: v });

const PRESETS: { name: string; hint: string; patch: () => Partial<StrategyConfig> }[] = [
  {
    name: 'EMA 9/21 cross', hint: 'Calls on up-cross, puts on down-cross',
    patch: () => ({
      timeframe: 5, maxTradesPerDay: 3, exitOnOpposite: true,
      entryConds: { logic: 'AND', rules: [{ lhs: ema(9), op: 'crosses_above', rhs: ema(21) }] },
      exitConds: { logic: 'OR', rules: [{ lhs: ema(9), op: 'crosses_below', rhs: ema(21) }] },
      legs: [makeLeg({ side: 'BUY', type: 'CE', sl: 25, tgt: 50 })],
      short: {
        legs: [makeLeg({ side: 'BUY', type: 'PE', sl: 25, tgt: 50 })],
        entryConds: { logic: 'AND', rules: [{ lhs: ema(9), op: 'crosses_below', rhs: ema(21) }] },
        exitConds: { logic: 'OR', rules: [{ lhs: ema(9), op: 'crosses_above', rhs: ema(21) }] },
      },
    }),
  },
  {
    name: 'RSI momentum', hint: 'RSI > 60 with price above VWAP',
    patch: () => ({
      timeframe: 5, maxTradesPerDay: 2, short: null,
      entryConds: { logic: 'AND', rules: [{ lhs: { kind: 'ind', name: 'RSI', n: 14 }, op: 'crosses_above', rhs: k(60) }, { lhs: { kind: 'ind', name: 'Close' }, op: '>', rhs: { kind: 'ind', name: 'VWAP' } }] },
      exitConds: { logic: 'OR', rules: [{ lhs: { kind: 'ind', name: 'RSI', n: 14 }, op: '<', rhs: k(45) }] },
      legs: [makeLeg({ side: 'BUY', type: 'CE', sl: 30 })],
    }),
  },
  {
    name: 'Supertrend flip', hint: 'Trade direction changes',
    patch: () => {
      const dir = { kind: 'ind' as const, name: 'SupertrendDir', n: 10, n2: 3 };
      return {
        timeframe: 15, maxTradesPerDay: 2, exitOnOpposite: true,
        entryConds: { logic: 'AND', rules: [{ lhs: dir, op: 'crosses_above', rhs: k(0) }] },
        exitConds: emptyBlock('OR'),
        legs: [makeLeg({ side: 'SELL', type: 'PE', sl: 40 })],
        short: { legs: [makeLeg({ side: 'SELL', type: 'CE', sl: 40 })], entryConds: { logic: 'AND', rules: [{ lhs: dir, op: 'crosses_below', rhs: k(0) }] }, exitConds: emptyBlock('OR') },
      };
    },
  },
  {
    name: 'Opening range breakout', hint: 'Close above 15-min OR high',
    patch: () => ({
      timeframe: 5, maxTradesPerDay: 1, entryTime: '09:30', short: null,
      entryConds: { logic: 'AND', rules: [{ lhs: { kind: 'ind', name: 'Close' }, op: 'crosses_above', rhs: { kind: 'ind', name: 'ORHigh', n: 3 } }] },
      exitConds: { logic: 'OR', rules: [{ lhs: { kind: 'pos', field: 'PnLpct' }, op: '<=', rhs: k(-30) }] },
      legs: [makeLeg({ side: 'BUY', type: 'CE', tgt: 60 })],
    }),
  },
];

export default function IndicatorBuilder() {
  const c = useStore(s => s.config);
  const set = useStore(s => s.setConfig);
  const entry = c.entryConds ?? emptyBlock('AND');
  const exit = c.exitConds ?? emptyBlock('OR');
  const short = c.short;

  const setShort = (p: Partial<{ legs: Leg[]; entryConds: Block; exitConds: Block }>) =>
    set({ short: { legs: short?.legs ?? [], entryConds: short?.entryConds ?? emptyBlock('AND'), exitConds: short?.exitConds ?? emptyBlock('OR'), ...p } });

  return (
    <div className="space-y-5">
      <Card title="Start from" icon={<Sparkles size={16} />}>
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
          {PRESETS.map(p => (
            <button key={p.name} className="card card-hover !rounded-xl px-3 py-2.5 text-left" onClick={() => set({ ...p.patch(), name: p.name, meta: { source: 'indicator' } })}>
              <div className="text-sm font-semibold">{p.name}</div>
              <div className="text-[11px] text-slate-500">{p.hint}</div>
            </button>
          ))}
        </div>
      </Card>

      <Card title="Long side" icon={<ArrowUpRight size={16} />} actions={<span className="badge bg-brand-100 text-brand-700 dark:bg-brand-900/50 dark:text-brand-300">LONG</span>}>
        <div className="space-y-5">
          <div>
            <div className="section-title mb-2">Entry when</div>
            <BlockEditor block={entry} onChange={b => set({ entryConds: b })} emptyText={`No rules: enters at ${c.entryTime} (time-based).`} />
          </div>
          <div>
            <div className="section-title mb-2">Exit when</div>
            <BlockEditor block={exit} onChange={b => set({ exitConds: b })} allowPos emptyText="No rules: exits on SL / target / time." />
          </div>
          <div>
            <div className="section-title mb-2">Legs to trade on long signal</div>
            <LegsEditor legs={c.legs} onChange={legs => set({ legs })} />
          </div>
        </div>
      </Card>

      <Card
        title="Short side"
        icon={<ArrowDownRight size={16} />}
        actions={<Toggle checked={!!short} onChange={v => set({ short: v ? { legs: [makeLeg({ side: 'BUY', type: 'PE', sl: 25 })], entryConds: emptyBlock('AND'), exitConds: emptyBlock('OR') } : null })} label="Enable" />}
      >
        {!short ? <div className="text-sm text-slate-400">Optional. Enable to trade a separate set of legs on a bearish signal.</div> : (
          <div className="space-y-5">
            <div>
              <div className="section-title mb-2">Short entry when</div>
              <BlockEditor block={short.entryConds ?? emptyBlock('AND')} onChange={b => setShort({ entryConds: b })} emptyText="Add at least one rule for the short side." />
            </div>
            <div>
              <div className="section-title mb-2">Short exit when</div>
              <BlockEditor block={short.exitConds ?? emptyBlock('OR')} onChange={b => setShort({ exitConds: b })} allowPos emptyText="No rules: exits on SL / target / time." />
            </div>
            <div>
              <div className="section-title mb-2">Legs to trade on short signal</div>
              <LegsEditor legs={short.legs} onChange={legs => setShort({ legs })} />
            </div>
            <Toggle checked={!!c.exitOnOpposite} onChange={v => set({ exitOnOpposite: v })} label="Exit (and reverse) when the opposite signal fires" />
          </div>
        )}
      </Card>
      <p className="text-xs text-slate-400">Rules are evaluated on the close of each {c.timeframe}-min candle of the underlying between {c.entryTime} and {c.lastEntryTime || c.exitTime}; fills happen at the next minute's option price.</p>
    </div>
  );
}
