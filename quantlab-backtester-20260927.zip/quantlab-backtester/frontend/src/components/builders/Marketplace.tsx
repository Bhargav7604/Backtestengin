import { useEffect, useMemo, useState } from 'react';
import clsx from 'clsx';
import { Play, Search, Settings2, Store } from 'lucide-react';
import { api } from '../../lib/api';
import { useStore } from '../../lib/store';
import { hasSignals } from '../../lib/strategy';
import { inrCompact, signCls } from '../../lib/format';
import type { MarketplaceItem } from '../../lib/types';
import { Alert, Chip, Empty } from '../ui';

const CATS = ['Neutral', 'Bullish', 'Bearish', 'Directional', 'Intraday', 'Positional'];
const RISKS = ['Low', 'Medium', 'High'] as const;
const riskCls: Record<string, string> = {
  Low: 'bg-brand-100 text-brand-700 dark:bg-brand-900/50 dark:text-brand-300',
  Medium: 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300',
  High: 'bg-rose-100 text-rose-700 dark:bg-rose-900/40 dark:text-rose-300',
};

export default function Marketplace() {
  const [items, setItems] = useState<MarketplaceItem[] | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [cats, setCats] = useState<string[]>([]);
  const [risk, setRisk] = useState<string | null>(null);
  const [q, setQ] = useState('');
  const run = useStore(s => s.run);
  const busy = useStore(s => !!s.job);

  useEffect(() => { api.marketplace().then(setItems).catch(e => setErr((e as Error).message)); }, []);

  const list = useMemo(() => (items ?? []).filter(it => {
    if (risk && it.risk !== risk) return false;
    if (cats.length && !cats.some(c => it.category === c || (it.style || '').toLowerCase().includes(c.toLowerCase()) || it.tags.some(t => t.toLowerCase() === c.toLowerCase()))) return false;
    if (q) {
      const hay = `${it.name} ${it.description} ${it.tags.join(' ')} ${it.config.und}`.toLowerCase();
      if (!q.toLowerCase().split(/\s+/).every(w => hay.includes(w))) return false;
    }
    return true;
  }), [items, cats, risk, q]);

  const customize = (it: MarketplaceItem) => {
    const st = useStore.getState();
    st.replaceConfig({ ...it.config, name: it.name });
    st.go('builder', hasSignals(it.config) ? 'indicator' : 'option');
  };

  return (
    <div className="space-y-5">
      <div className="card-mint p-5">
        <div className="flex items-center gap-2"><Store size={18} className="text-brand-600" /><h2 className="text-lg font-semibold">Strategy marketplace</h2></div>
        <p className="mt-1 text-sm text-slate-500">Popular Indian F&O algos, ready to backtest on real data. Customize any of them in the builders.</p>
        <div className="mt-4 flex flex-col gap-3 sm:flex-row sm:items-center">
          <div className="relative flex-1">
            <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input className="inp pl-9" placeholder="Search straddle, supertrend, BANKNIFTY…" value={q} onChange={e => setQ(e.target.value)} />
          </div>
          <div className="flex flex-wrap gap-1.5">
            {RISKS.map(r => <Chip key={r} on={risk === r} onClick={() => setRisk(risk === r ? null : r)}>{r} risk</Chip>)}
          </div>
        </div>
        <div className="mt-3 flex flex-wrap gap-1.5">
          <Chip on={!cats.length} onClick={() => setCats([])}>All</Chip>
          {CATS.map(c => <Chip key={c} on={cats.includes(c)} onClick={() => setCats(cats.includes(c) ? cats.filter(x => x !== c) : [...cats, c])}>{c}</Chip>)}
        </div>
      </div>

      {err && <Alert>Couldn't load the marketplace: {err}</Alert>}
      {!items && !err && <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">{[0, 1, 2, 3, 4, 5].map(i => <div key={i} className="card h-52 animate-pulse" />)}</div>}
      {items && !list.length && <Empty>No strategies match these filters.</Empty>}

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {list.map(it => (
          <div key={it.id} className="card card-hover flex flex-col p-4">
            <div className="flex items-start gap-2">
              <h3 className="font-semibold leading-snug">{it.name}</h3>
              <span className={clsx('badge ml-auto shrink-0', riskCls[it.risk] ?? riskCls.Medium)}>{it.risk}</span>
            </div>
            <div className="mt-1 text-xs text-slate-500">{it.config.und} · {it.category}{it.style ? ` · ${it.style}` : ''}</div>
            <p className="mt-2 line-clamp-3 text-sm text-slate-600 dark:text-slate-400">{it.description}</p>
            <div className="mt-2 flex flex-wrap gap-1">
              {it.tags.map(t => <span key={t} className="badge bg-slate-100 font-medium text-slate-600 dark:bg-slate-800 dark:text-slate-300">{t}</span>)}
            </div>
            {it.stats && (
              <div className="mt-3 grid grid-cols-3 gap-2 rounded-xl bg-slate-50 p-2 text-center dark:bg-slate-800/50">
                <div><div className="text-[10px] uppercase text-slate-400">Net P&L</div><div className={clsx('text-sm font-semibold', signCls(it.stats.netPnl as number))}>{inrCompact(it.stats.netPnl as number)}</div></div>
                <div><div className="text-[10px] uppercase text-slate-400">Win rate</div><div className="text-sm font-semibold">{it.stats.winRate != null ? `${it.stats.winRate}%` : '—'}</div></div>
                <div><div className="text-[10px] uppercase text-slate-400">Max DD</div><div className="neg text-sm font-semibold">{inrCompact(it.stats.maxDD as number)}</div></div>
              </div>
            )}
            <div className="mt-auto flex gap-2 pt-4">
              <button className="btn-primary btn-sm flex-1 !py-1.5" disabled={busy} onClick={() => run(it.config)}><Play size={13} /> Backtest</button>
              <button className="btn btn-sm flex-1 !py-1.5" onClick={() => customize(it)}><Settings2 size={13} /> Customize</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
