import clsx from 'clsx';
import { FolderPlus, Plus, X } from 'lucide-react';
import { emptyBlock, isBlock, isNot, makeRule, OPS } from '../../lib/strategy';
import type { Block, CmpOp, Rule, RuleNode } from '../../lib/types';
import OperandPicker from './OperandPicker';

const opSel = 'h-8 rounded-lg border border-slate-200 bg-brand-50 px-1.5 text-[13px] font-semibold text-brand-800 outline-none focus:border-brand-500 dark:border-slate-700 dark:bg-brand-950/50 dark:text-brand-300';

function RuleEditor({ rule, onChange, allowPos }: { rule: Rule; onChange: (r: Rule) => void; allowPos?: boolean }) {
  const unary = rule.op === 'is_true' || rule.op === 'is_false';
  return (
    <div className="flex flex-wrap items-center gap-1.5">
      <OperandPicker value={rule.lhs} onChange={lhs => onChange({ ...rule, lhs })} allowPos={allowPos} />
      <select className={opSel} value={rule.op} onChange={e => onChange({ ...rule, op: e.target.value as CmpOp })}>
        {OPS.map(([v, t]) => <option key={v} value={v}>{t}</option>)}
      </select>
      {!unary && <OperandPicker value={rule.rhs} onChange={rhs => onChange({ ...rule, rhs })} allowPos={allowPos} />}
    </div>
  );
}

function NodeRow({ node, onChange, onRemove, allowPos, depth }: { node: RuleNode; onChange: (n: RuleNode) => void; onRemove: () => void; allowPos?: boolean; depth: number }) {
  const negated = isNot(node);
  const inner = negated ? node.not : node;
  const wrap = (n: Rule | Block): RuleNode => (negated ? { not: n } : n);
  return (
    <div className="flex items-start gap-2">
      <button
        type="button"
        onClick={() => onChange(negated ? inner : { not: inner })}
        title="Negate (NOT)"
        className={clsx('mt-1 shrink-0 rounded-md border px-1.5 py-0.5 text-[10px] font-bold tracking-wide transition',
          negated ? 'border-rose-400 bg-rose-50 text-rose-600 dark:bg-rose-950/40' : 'border-slate-200 text-slate-400 hover:border-slate-400 dark:border-slate-700')}
      >NOT</button>
      <div className="min-w-0 flex-1">
        {isBlock(inner)
          ? <BlockEditor block={inner} onChange={b => onChange(wrap(b))} allowPos={allowPos} depth={depth + 1} />
          : <RuleEditor rule={inner as Rule} onChange={r => onChange(wrap(r))} allowPos={allowPos} />}
      </div>
      <button className="mt-1 shrink-0 rounded-md p-1 text-slate-400 hover:bg-rose-50 hover:text-rose-600 dark:hover:bg-rose-950/40" onClick={onRemove} title="Remove"><X size={14} /></button>
    </div>
  );
}

export default function BlockEditor({ block, onChange, allowPos, depth = 0, emptyText }: { block: Block; onChange: (b: Block) => void; allowPos?: boolean; depth?: number; emptyText?: string }) {
  const setRules = (rules: RuleNode[]) => onChange({ ...block, rules });
  return (
    <div className={clsx('space-y-2', depth > 0 && 'rounded-xl border border-slate-200 bg-slate-50/70 p-2.5 dark:border-slate-700 dark:bg-slate-800/40')}>
      <div className="flex flex-wrap items-center gap-2">
        <div className="inline-flex rounded-lg border border-slate-200 p-0.5 text-xs font-semibold dark:border-slate-700">
          {(['AND', 'OR'] as const).map(l => (
            <button key={l} onClick={() => onChange({ ...block, logic: l })}
              className={clsx('rounded-md px-2 py-0.5', block.logic === l ? 'bg-brand-600 text-white' : 'text-slate-500')}>
              {l === 'AND' ? 'ALL (AND)' : 'ANY (OR)'}
            </button>
          ))}
        </div>
        <button className="btn btn-sm" onClick={() => setRules([...block.rules, makeRule()])}><Plus size={13} /> Rule</button>
        {depth < 3 && <button className="btn btn-sm" onClick={() => setRules([...block.rules, { ...emptyBlock(block.logic === 'AND' ? 'OR' : 'AND'), rules: [makeRule()] }])}><FolderPlus size={13} /> Group</button>}
      </div>
      {!block.rules.length && depth === 0 && <div className="text-sm text-slate-400">{emptyText ?? 'No rules.'}</div>}
      {block.rules.map((n, i) => (
        <div key={i}>
          {i > 0 && <div className="my-1 pl-10 text-[10px] font-bold tracking-widest text-brand-600 dark:text-brand-400">{block.logic}</div>}
          <NodeRow node={n} depth={depth} allowPos={allowPos}
            onChange={nn => setRules(block.rules.map((x, j) => (j === i ? nn : x)))}
            onRemove={() => setRules(block.rules.filter((_, j) => j !== i))} />
        </div>
      ))}
    </div>
  );
}
