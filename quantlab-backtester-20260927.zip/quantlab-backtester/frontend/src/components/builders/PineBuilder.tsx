import { FileCode2, RefreshCcw, Repeat2 } from 'lucide-react';
import { useStore } from '../../lib/store';
import type { Instrument } from '../../lib/types';
import { Alert, Card, Field, Select, Spinner } from '../ui';
import CodeEditor from './CodeEditor';
import CompileResult, { useCompile } from './CompileResult';

export const PINE_SAMPLE = `//@version=5
strategy("EMA crossover + RSI filter", overlay=true)

fastLen = input.int(9, "Fast EMA")
slowLen = input.int(21, "Slow EMA")
fast = ta.ema(close, fastLen)
slow = ta.ema(close, slowLen)
r = ta.rsi(close, 14)

longCond = ta.crossover(fast, slow) and r > 55
shortCond = ta.crossunder(fast, slow) and r < 45

if longCond
    strategy.entry("Long", strategy.long)
if shortCond
    strategy.entry("Short", strategy.short)

if ta.crossunder(fast, slow)
    strategy.close("Long")
if ta.crossover(fast, slow)
    strategy.close("Short")
`;

export const INSTRUMENTS: [Instrument, string][] = [
  ['atm_options', 'Buy ATM options (long → CE, short → PE)'],
  ['sell_options', 'Sell ATM options (long → sell PE, short → sell CE)'],
  ['futures', 'Futures (long → buy, short → sell)'],
];

export default function PineBuilder() {
  const code = useStore(s => s.codes.pine) || PINE_SAMPLE;
  const setCode = useStore(s => s.setCode);
  const instrument = useStore(s => s.instrument);
  const setInstrument = useStore(s => s.setInstrument);
  const { busy, error, compile, clearError } = useCompile('pine');

  return (
    <div className="space-y-5">
      <Card title="Pine Script v4 / v5" icon={<FileCode2 size={16} />}
        actions={<button className="btn btn-sm" onClick={() => setCode('pine', PINE_SAMPLE)}><RefreshCcw size={13} /> Sample</button>}>
        <CodeEditor value={code} onChange={v => setCode('pine', v)} language="pine" />
        <div className="mt-4 grid gap-3 sm:grid-cols-[1fr_auto] sm:items-end">
          <Field label="Map signals to">
            <Select<Instrument> value={instrument} onChange={setInstrument} options={INSTRUMENTS} />
          </Field>
          <button className="btn-primary" disabled={busy || !code.trim()} onClick={() => compile(code)}>
            {busy ? <Spinner /> : <Repeat2 size={16} />} Convert
          </button>
        </div>
        <p className="mt-2 text-xs text-slate-400">Supported: ta.* indicators, crossover/crossunder, inputs, strategy.entry/close/exit. Rules run on the underlying; trades are placed with the mapped instrument.</p>
        {error && <div className="mt-3"><Alert onClose={clearError}>{error}</Alert></div>}
      </Card>
      <CompileResult source="pine" />
    </div>
  );
}
