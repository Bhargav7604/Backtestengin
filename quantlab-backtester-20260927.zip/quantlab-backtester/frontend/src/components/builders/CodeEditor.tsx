import { useRef, type KeyboardEvent } from 'react';

/** Minimal code editor: textarea + synced line-number gutter + Tab / Shift-Tab indentation. */
export default function CodeEditor({ value, onChange, minRows = 18, language }: { value: string; onChange: (v: string) => void; minRows?: number; language?: string }) {
  const ta = useRef<HTMLTextAreaElement>(null);
  const gutter = useRef<HTMLDivElement>(null);
  const lines = Math.max(value.split('\n').length, minRows);

  const onKey = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    const el = e.currentTarget;
    const { selectionStart: s, selectionEnd: en } = el;
    const IND = '    ';
    const apply = (text: string, a: number, b: number) => {
      onChange(text);
      requestAnimationFrame(() => { el.selectionStart = a; el.selectionEnd = b; });
    };
    if (e.key === 'Tab') {
      e.preventDefault();
      const ls = value.lastIndexOf('\n', s - 1) + 1;
      if (s === en && !e.shiftKey) { apply(value.slice(0, s) + IND + value.slice(en), s + IND.length, s + IND.length); return; }
      const block = value.slice(ls, en);
      const out = e.shiftKey ? block.replace(/^( {1,4}|\t)/gm, '') : block.replace(/^/gm, IND);
      const delta = out.length - block.length;
      const firstDelta = e.shiftKey ? -(block.match(/^( {1,4}|\t)/)?.[0].length ?? 0) : IND.length;
      apply(value.slice(0, ls) + out + value.slice(en), Math.max(ls, s + firstDelta), en + delta);
    } else if (e.key === 'Enter' && !e.metaKey && !e.ctrlKey) {
      // keep indentation (+ indent after ':' for python)
      const ls = value.lastIndexOf('\n', s - 1) + 1;
      const cur = value.slice(ls, s);
      let ind = cur.match(/^\s*/)?.[0] ?? '';
      if (/[:{(\[]\s*$/.test(cur)) ind += IND;
      e.preventDefault();
      apply(value.slice(0, s) + '\n' + ind + value.slice(en), s + 1 + ind.length, s + 1 + ind.length);
    }
  };

  return (
    <div className="relative flex overflow-hidden rounded-xl border border-slate-200 bg-slate-950 font-mono text-[13px] leading-[1.6] dark:border-slate-700">
      <div ref={gutter} className="select-none overflow-hidden border-r border-slate-800 bg-slate-900 py-3 pl-3 pr-2 text-right text-slate-500" aria-hidden="true">
        {Array.from({ length: lines }, (_, i) => <div key={i}>{i + 1}</div>)}
      </div>
      <textarea
        ref={ta}
        value={value}
        spellCheck={false}
        autoCapitalize="off"
        autoCorrect="off"
        data-language={language}
        onChange={e => onChange(e.target.value)}
        onKeyDown={onKey}
        onScroll={e => { if (gutter.current) gutter.current.scrollTop = e.currentTarget.scrollTop; }}
        rows={minRows}
        className="scroll-thin block w-full resize-y whitespace-pre bg-transparent px-3 py-3 text-slate-100 caret-brand-400 outline-none"
        style={{ minHeight: `${minRows * 1.6 + 1.5}em`, tabSize: 4 }}
        wrap="off"
      />
    </div>
  );
}
