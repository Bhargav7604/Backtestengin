import { useState, type ReactNode } from 'react';
import { ArrowDownRight, ArrowUpRight, CheckCircle2, Clock3, Pencil } from 'lucide-react';
import { api } from '../../lib/api';
import { useStore } from '../../lib/store';
import { describeBlock, describeLeg, hasSignals } from '../../lib/strategy';
import type { CompileDefaults, StrategyConfig } from '../../lib/types';
import { Alert, Card } from '../ui';

export function compileDefaults(): CompileDefaults {
  const { config: c, instrument } = useStore.getState();
  return { exch: c.exch, und: c.und, start: c.start, end: c.end, capital: c.capital, timeframe: c.timeframe, instrument, lots: 1, expiry: 'weekly' };
}

/** Compile helper hook for prompt / pine / python sources. */
export function useCompile(source: 'prompt' | 'pine' | 'python') {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const compile = async (code: string): Promise<boolean> => {
    setBusy(true); setError(null);
    try {
      const r = await api.compile(source, code, compileDefaults());
      const st = useStore.getState();
      st.replaceConfig({ ...r.config, meta: { ...(r.config.meta || {}), source, code } });
      st.setCompileInfo(source, { notes: r.notes || [], warnings: r.warnings || [], at: Date.now() });
      return true;
    } catch (e) {
      setError((e as Error).message);
      useStore.getState().setCompileInfo(source, undefined);
      return false;
    } finally { setBusy(false); }
  };
  return { busy, error, compile, clearError: () => setError(null) };
}

export function StrategySummary({ c }: { c: StrategyConfig }) {
  const sig = hasSignals(c);
  const Row = ({ k, v }: { k: ReactNode; v: ReactNode }) => (
    <div className="flex gap-3 py-1.5 text-sm"><span className="w-24 shrink-0 text-slate-500">{k}</span><span className="min-w-0 flex-1 break-words font-medium">{v}</span></div>
  );
  return (
    <div className="divide-y divide-slate-100 dark:divide-slate-800">
      <Row k="Instrument" v={`${c.und} (${c.exch}) · ${c.start} → ${c.end}`} />
      <Row k="Timing" v={<span className="inline-flex items-center gap-1"><Clock3 size={13} /> {c.mode} · {sig ? `${c.timeframe}m candles, ${c.entryTime}–${c.lastEntryTime || c.exitTime}` : `enter ${c.entryTime}`} · exit {c.exitTime}</span>} />
      {sig && <Row k="Long entry" v={<span className="inline-flex items-start gap-1"><ArrowUpRight size={14} className="mt-0.5 shrink-0 text-brand-600" />{describeBlock(c.entryConds) || '—'}</span>} />}
      {sig && describeBlock(c.exitConds) && <Row k="Long exit" v={describeBlock(c.exitConds)} />}
      <Row k={c.short ? 'Long legs' : 'Legs'} v={c.legs.length ? <ul className="space-y-0.5">{c.legs.map((l, i) => <li key={i}>{describeLeg(l)}</li>)}</ul> : '—'} />
      {c.short && <>
        <Row k="Short entry" v={<span className="inline-flex items-start gap-1"><ArrowDownRight size={14} className="mt-0.5 shrink-0 text-rose-500" />{describeBlock(c.short.entryConds) || '—'}</span>} />
        {describeBlock(c.short.exitConds) && <Row k="Short exit" v={describeBlock(c.short.exitConds)} />}
        <Row k="Short legs" v={<ul className="space-y-0.5">{c.short.legs.map((l, i) => <li key={i}>{describeLeg(l)}</li>)}</ul>} />
      </>}
      {(c.overall.sl || c.overall.tgt) ? <Row k="Overall" v={[c.overall.sl && `SL ₹${c.overall.sl}`, c.overall.tgt && `Target ₹${c.overall.tgt}`].filter(Boolean).join(' · ')} /> : null}
      <Row k="Days" v={c.weekdays.map(d => ['', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][d]).join(', ')} />
    </div>
  );
}

export default function CompileResult({ source }: { source: 'prompt' | 'pine' | 'python' }) {
  const info = useStore(s => s.compileInfo[source]);
  const c = useStore(s => s.config);
  const go = useStore(s => s.go);
  if (!info || c.meta?.source !== source) return null;
  return (
    <Card title="Compiled strategy" icon={<CheckCircle2 size={16} />}
      actions={<>
        <button className="btn btn-sm" onClick={() => go('builder', 'option')}><Pencil size={13} /> Edit legs</button>
        <button className="btn btn-sm" onClick={() => go('builder', 'indicator')}><Pencil size={13} /> Edit rules</button>
      </>}>
      <StrategySummary c={c} />
      {(info.notes.length > 0 || info.warnings.length > 0) && (
        <div className="mt-4 space-y-2">
          {info.warnings.map((w, i) => <Alert key={'w' + i} kind="warn">{w}</Alert>)}
          {info.notes.map((n, i) => <Alert key={'n' + i} kind="info">{n}</Alert>)}
        </div>
      )}
    </Card>
  );
}
