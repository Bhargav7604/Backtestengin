import { MessageSquareText, Wand2 } from 'lucide-react';
import { useStore } from '../../lib/store';
import { Alert, Card, Chip, Spinner } from '../ui';
import CompileResult, { useCompile } from './CompileResult';

const EXAMPLES = [
  'Sell NIFTY ATM straddle at 9:20 with 25% SL, exit 3:15',
  'Buy BANKNIFTY ATM call when 9 EMA crosses above 21 EMA on 5 min and RSI > 55, SL 30%',
  'Iron condor on SENSEX every Thursday, 3 strikes OTM, hedges 8 strikes',
  'Short strangle on FINNIFTY at 30 delta, 40% SL on each leg, overall SL 6000',
  'Buy NIFTY ATM put when supertrend 10,3 turns down on 15 min, target 60%',
  'Sell NIFTY 100 premium CE and PE at 9:30 on expiry day only, exit 2:30',
];

export default function PromptBuilder() {
  const text = useStore(s => s.codes.prompt);
  const setCode = useStore(s => s.setCode);
  const { busy, error, compile, clearError } = useCompile('prompt');

  return (
    <div className="space-y-5">
      <Card title="Describe your strategy" icon={<MessageSquareText size={16} />}>
        <textarea
          className="inp h-auto min-h-[140px] resize-y py-3 text-[15px] leading-relaxed"
          placeholder="e.g. Sell NIFTY ATM straddle at 9:20 with 25% SL on each leg, exit at 3:15, only on Tuesdays and Thursdays"
          value={text}
          onChange={e => setCode('prompt', e.target.value)}
          onKeyDown={e => { if (e.key === 'Enter' && (e.metaKey || e.ctrlKey) && text.trim()) compile(text); }}
        />
        <div className="mt-3 flex flex-wrap gap-2">
          {EXAMPLES.map(x => <Chip key={x} onClick={() => setCode('prompt', x)} className="!text-left">{x}</Chip>)}
        </div>
        <div className="mt-4 flex flex-wrap items-center gap-3">
          <button className="btn-primary" disabled={busy || !text.trim()} onClick={() => compile(text)}>
            {busy ? <Spinner /> : <Wand2 size={16} />} Build strategy
          </button>
          <span className="text-xs text-slate-400">⌘/Ctrl + Enter · anything not mentioned uses the common settings</span>
        </div>
        {error && <div className="mt-3"><Alert onClose={clearError}>{error}</Alert></div>}
      </Card>
      <CompileResult source="prompt" />
    </div>
  );
}
