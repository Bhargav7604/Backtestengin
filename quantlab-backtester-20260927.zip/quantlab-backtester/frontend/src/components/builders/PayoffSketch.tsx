import { useMemo } from 'react';
import { Area, AreaChart, CartesianGrid, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import type { Leg } from '../../lib/types';

/** Rough strike offset (in strike steps, +OTM) for a leg, just for a visual sketch. */
function offsetSteps(l: Leg): number {
  switch (l.strikeMode) {
    case 'atm': return l.strikeValue;
    case 'pct': return l.strikeValue / 0.5;
    case 'delta': return (50 - l.strikeValue) / 7;
    default: return Math.max(0, 6 - Math.log2(Math.max(l.strikeValue, 1)));
  }
}
const premium = (k: number) => 3.2 * Math.exp(-Math.abs(k) / 3.2) + Math.max(0, -k); // extrinsic + intrinsic when ITM

export default function PayoffSketch({ legs }: { legs: Leg[] }) {
  const data = useMemo(() => {
    const out: { x: number; pnl: number }[] = [];
    // near expiry legs only (payoff at first expiry); longer-dated legs approximated by their premium
    for (let x = -14; x <= 14; x += 0.5) {
      let p = 0;
      for (const l of legs) {
        const sgn = l.side === 'BUY' ? 1 : -1;
        if (l.type === 'FUT') { p += sgn * x * l.lots; continue; }
        const off = offsetSteps(l);
        const K = l.type === 'CE' ? off : -off;
        const iv = l.type === 'CE' ? Math.max(0, x - K) : Math.max(0, K - x);
        const far = l.expiry !== 'weekly' && legs.some(o => o.expiry === 'weekly');
        const value = far ? premium(l.type === 'CE' ? K - x : x - K) * 1.4 : iv;
        p += sgn * (value - premium(off) * (far ? 1.4 : 1)) * l.lots;
      }
      out.push({ x, pnl: +p.toFixed(2) });
    }
    return out;
  }, [legs]);

  if (!legs.length) return null;
  const max = Math.max(...data.map(d => d.pnl)), min = Math.min(...data.map(d => d.pnl));
  const zeroFrac = max <= 0 ? 0 : min >= 0 ? 1 : max / (max - min);

  return (
    <div>
      <div className="h-44">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data} margin={{ top: 8, right: 8, bottom: 0, left: -24 }}>
            <defs>
              <linearGradient id="payoffFill" x1="0" y1="0" x2="0" y2="1">
                <stop offset={0} stopColor="#16a34a" stopOpacity={0.35} />
                <stop offset={zeroFrac} stopColor="#16a34a" stopOpacity={0.08} />
                <stop offset={zeroFrac} stopColor="#e11d48" stopOpacity={0.08} />
                <stop offset={1} stopColor="#e11d48" stopOpacity={0.3} />
              </linearGradient>
              <linearGradient id="payoffStroke" x1="0" y1="0" x2="0" y2="1">
                <stop offset={zeroFrac} stopColor="#16a34a" />
                <stop offset={zeroFrac} stopColor="#e11d48" />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#94a3b8" strokeOpacity={0.25} vertical={false} />
            <XAxis dataKey="x" type="number" domain={[-14, 14]} ticks={[-12, -8, -4, 0, 4, 8, 12]} tickFormatter={v => (v === 0 ? 'Spot' : `${v > 0 ? '+' : ''}${v}`)} tick={{ fontSize: 10 }} stroke="#94a3b8" />
            <YAxis tick={{ fontSize: 10 }} stroke="#94a3b8" tickFormatter={() => ''} />
            <ReferenceLine y={0} stroke="#94a3b8" />
            <ReferenceLine x={0} stroke="#94a3b8" strokeDasharray="4 4" />
            <Tooltip formatter={(v) => [Number(v).toFixed(2), 'P&L (rel.)']} labelFormatter={v => `${v} steps from spot`} contentStyle={{ borderRadius: 10, fontSize: 12 }} />
            <Area type="linear" dataKey="pnl" stroke="url(#payoffStroke)" strokeWidth={2} fill="url(#payoffFill)" isAnimationActive={false} />
          </AreaChart>
        </ResponsiveContainer>
      </div>
      <div className="mt-1 text-[11px] text-slate-400">Approximate payoff at expiry vs. spot move in strike steps (premiums modelled, not market data).</div>
    </div>
  );
}
