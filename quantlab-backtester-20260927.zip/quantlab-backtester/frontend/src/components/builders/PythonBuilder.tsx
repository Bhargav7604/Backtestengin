import { useState } from 'react';
import clsx from 'clsx';
import { BookOpen, ChevronDown, Code2, RefreshCcw, Repeat2 } from 'lucide-react';
import { useStore } from '../../lib/store';
import type { Instrument } from '../../lib/types';
import { Alert, Card, Field, Select, Spinner } from '../ui';
import CodeEditor from './CodeEditor';
import CompileResult, { useCompile } from './CompileResult';
import { INSTRUMENTS } from './PineBuilder';

export const PY_SAMPLE = `from quantlab import *

# NIFTY 5-min EMA momentum: buy ATM calls on bullish crosses, ATM puts on bearish ones
strategy("NIFTY EMA momentum", timeframe=5, mode="intraday",
         entry_time="09:30", exit_time="15:15", last_entry_time="14:30",
         max_trades_per_day=3, weekdays=[MON, TUE, WED, THU, FRI])

fast, slow = ema(close, 9), ema(close, 21)
trend_up = (close > vwap()) & (adx(14) > 20)

long_when(crossover(fast, slow) & trend_up & (rsi(close, 14) > 55))
long_exit_when(crossunder(fast, slow) | (minutes_in_trade() > 90) | (pnl() < -3000))

short_when(crossunder(fast, slow) & ~trend_up & (rsi(close, 14) < 45))
short_exit_when(crossover(fast, slow) | (minutes_in_trade() > 90))
exit_on_opposite(True)

leg(BUY, CE, strike=ATM, expiry=WEEKLY, lots=1, sl=pct(25), target=pct(50), trail=(pct(10), pct(5)))
short_leg(BUY, PE, strike=ATM, expiry=WEEKLY, lots=1, sl=pct(25), target=pct(50))

overall(stop_loss=5000, target=10000, lock_at=3000, lock_profit=1000)
costs(brokerage=20, slippage_pct=0.1)
`;

const CHEATS: [string, string[]][] = [
  ['Setup', ['from quantlab import *', 'strategy("Name", underlying="NIFTY", timeframe=5, mode="intraday", entry_time="09:20", exit_time="15:15", max_trades_per_day=3, weekdays=[MON, WED], dte=(0, 7))', 'omitted fields use the common settings']],
  ['Series', ['open high low close volume hl2 hlc3 ohlc4', 'ema sma rma wma hma dema tema vwma (src, n)', 'rsi(src, 14)  cci(20)  roc(src, n)  atr(14)  adx(14)  vwap()  obv()', 'm = macd(src, 12, 26, 9) → m.line m.signal m.hist', 'bb = bbands(src, 20, 2) → bb.upper bb.mid bb.lower', 'st = supertrend(10, 3) → st.line st.direction', 'close[1]  → value 1 candle ago · ema(rsi(close, 14), 9)']],
  ['Conditions', ['crossover(a, b)  crossunder(a, b)  cross(a, b)', '(a > b) & (c < 30) | ~cond   — wrap comparisons in ()', 'time_of_day() < 1100  hour()  minute()  weekday()', 'exit only: pnl()  pnl_pct()  minutes_in_trade()']],
  ['Signals', ['long_when(cond)   long_exit_when(cond)', 'short_when(cond)  short_exit_when(cond)', 'exit_on_opposite(True) · no signals → time-based entry']],
  ['Legs', ['leg(BUY|SELL, CE|PE|FUT, strike=ATM|OTM(2)|ITM(1)|delta(30)|premium(100)|pct_otm(1.5), expiry=WEEKLY|MONTHLY, lots=1, sl=pct(25)|pts(20), target=pct(50), trail=(pct(10), pct(5)), reentries=2)', 'short_leg(...)  same arguments, traded on short signal']],
  ['Risk & costs', ['overall(stop_loss=5000, target=10000, lock_at=3000, lock_profit=1000, trail_every=1000, trail_by=500)', 'costs(brokerage=20, slippage_pct=0.1)  ·  costs(enabled=False)']],
];

export default function PythonBuilder() {
  const code = useStore(s => s.codes.python) || PY_SAMPLE;
  const setCode = useStore(s => s.setCode);
  const instrument = useStore(s => s.instrument);
  const setInstrument = useStore(s => s.setInstrument);
  const { busy, error, compile, clearError } = useCompile('python');
  const [cheat, setCheat] = useState(false);

  return (
    <div className="space-y-5">
      <Card title="QuantLab Python DSL" icon={<Code2 size={16} />}
        actions={<>
          <button className="btn btn-sm" onClick={() => setCheat(!cheat)}><BookOpen size={13} /> Cheat-sheet <ChevronDown size={13} className={clsx('transition', cheat && 'rotate-180')} /></button>
          <button className="btn btn-sm" onClick={() => setCode('python', PY_SAMPLE)}><RefreshCcw size={13} /> Sample</button>
        </>}>
        {cheat && (
          <div className="mb-4 grid gap-3 rounded-xl border border-brand-100 bg-brand-50/60 p-3 sm:grid-cols-2 dark:border-brand-900 dark:bg-brand-950/30">
            {CHEATS.map(([h, xs]) => (
              <div key={h}>
                <div className="mb-1 text-xs font-semibold uppercase tracking-wide text-brand-700 dark:text-brand-400">{h}</div>
                {xs.map(x => <code key={x} className="block break-words font-mono text-[12px] text-slate-700 dark:text-slate-300">{x}</code>)}
              </div>
            ))}
          </div>
        )}
        <CodeEditor value={code} onChange={v => setCode('python', v)} language="python" minRows={20} />
        <div className="mt-4 grid gap-3 sm:grid-cols-[1fr_auto] sm:items-end">
          <Field label="Default instrument (when no leg() is given)">
            <Select<Instrument> value={instrument} onChange={setInstrument} options={INSTRUMENTS} />
          </Field>
          <button className="btn-primary" disabled={busy || !code.trim()} onClick={() => compile(code)}>
            {busy ? <Spinner /> : <Repeat2 size={16} />} Compile
          </button>
        </div>
        {error && <div className="mt-3"><Alert onClose={clearError}>{error}</Alert></div>}
      </Card>
      <CompileResult source="python" />
    </div>
  );
}
