import clsx from 'clsx';
import { Copy, Plus, Trash2 } from 'lucide-react';
import { EXPIRIES, FUT_EXPIRIES, makeLeg, STRIKE_MODES } from '../../lib/strategy';
import type { Expiry, Leg, OptType, ReentryMode, Side, StrikeMode, Unit } from '../../lib/types';
import { Field, NumInput, Segmented, Select } from '../ui';

const UNITS = [['pct', '%'], ['pts', 'pts']] as const;

function LegCard({ leg, i, onChange, onRemove, onDup }: { leg: Leg; i: number; onChange: (l: Leg) => void; onRemove: () => void; onDup: () => void }) {
  const set = (p: Partial<Leg>) => onChange({ ...leg, ...p });
  const valLabel = STRIKE_MODES.find(m => m[0] === leg.strikeMode)?.[2] ?? 'Value';
  const accent = leg.type === 'FUT' ? 'border-l-amber-400' : leg.type === 'CE' ? 'border-l-brand-500' : 'border-l-rose-400';
  return (
    <div className={clsx('rounded-xl border border-l-4 border-slate-200 bg-slate-50/60 p-3 dark:border-slate-700 dark:bg-slate-800/40', accent)}>
      <div className="mb-3 flex flex-wrap items-center gap-2">
        <span className="text-xs font-semibold text-slate-400">LEG {i + 1}</span>
        <Segmented<Side> small value={leg.side} onChange={v => set({ side: v })} options={[['BUY', 'Buy'], ['SELL', 'Sell']]} />
        <Segmented<OptType> small value={leg.type} onChange={v => set({ type: v, expiry: v === 'FUT' && !leg.expiry.includes('monthly') ? 'monthly' : leg.expiry })} options={[['CE', 'CE'], ['PE', 'PE'], ['FUT', 'FUT']]} />
        <div className="ml-auto flex gap-1">
          <button className="btn-ghost btn-sm" onClick={onDup} title="Duplicate leg"><Copy size={14} /></button>
          <button className="btn-ghost btn-sm hover:!text-rose-600" onClick={onRemove} title="Remove leg"><Trash2 size={14} /></button>
        </div>
      </div>
      <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-4">
        <Field label="Lots"><NumInput small value={leg.lots} onChange={v => set({ lots: Math.max(1, v ?? 1) })} min={1} /></Field>
        <Field label="Expiry"><Select<Expiry> small value={leg.expiry} onChange={v => set({ expiry: v })} options={(leg.type === 'FUT' ? FUT_EXPIRIES : EXPIRIES) as [Expiry, string][]} /></Field>
        {leg.type !== 'FUT' && <>
          <Field label="Strike by"><Select<StrikeMode> small value={leg.strikeMode} onChange={v => set({ strikeMode: v, strikeValue: v === 'delta' ? 30 : v.startsWith('premium') ? 100 : 0 })} options={STRIKE_MODES.map(m => [m[0] as StrikeMode, m[1]] as const)} /></Field>
          <Field label={valLabel}><NumInput small value={leg.strikeValue} onChange={v => set({ strikeValue: v ?? 0 })} step={leg.strikeMode === 'pct' ? 0.5 : 1} /></Field>
        </>}
      </div>
      <div className="mt-2.5 grid grid-cols-2 gap-2.5 sm:grid-cols-4">
        <Field label="Stop loss">
          <div className="flex gap-1"><NumInput small value={leg.sl || null} onChange={v => set({ sl: v ?? 0 })} placeholder="off" /><Select<Unit> small className="!w-16" value={leg.slType} onChange={v => set({ slType: v })} options={UNITS} /></div>
        </Field>
        <Field label="Target">
          <div className="flex gap-1"><NumInput small value={leg.tgt || null} onChange={v => set({ tgt: v ?? 0 })} placeholder="off" /><Select<Unit> small className="!w-16" value={leg.tgtType} onChange={v => set({ tgtType: v })} options={UNITS} /></div>
        </Field>
        <Field label="Trail every X → Y">
          <div className="flex gap-1">
            <NumInput small value={leg.trailX || null} onChange={v => set({ trailX: v ?? 0 })} placeholder="X" />
            <NumInput small value={leg.trailY || null} onChange={v => set({ trailY: v ?? 0 })} placeholder="Y" />
            <Select<Unit> small className="!w-16" value={leg.trailType} onChange={v => set({ trailType: v })} options={UNITS} />
          </div>
        </Field>
        <Field label="Re-entries">
          <div className="flex gap-1">
            <NumInput small className="!w-14" value={leg.reentries} onChange={v => set({ reentries: Math.max(0, v ?? 0) })} min={0} />
            <Select<ReentryMode> small value={leg.reentryMode} onChange={v => set({ reentryMode: v })} options={[['immediate', 'Immediate'], ['same_strike', 'Same strike'], ['cost', 'At cost']]} />
          </div>
        </Field>
      </div>
    </div>
  );
}

export default function LegsEditor({ legs, onChange, emptyText = 'No legs yet.' }: { legs: Leg[]; onChange: (legs: Leg[]) => void; emptyText?: string }) {
  return (
    <div className="space-y-3">
      {!legs.length && <div className="text-sm text-slate-400">{emptyText}</div>}
      {legs.map((l, i) => (
        <LegCard key={i} leg={l} i={i}
          onChange={nl => onChange(legs.map((x, j) => (j === i ? nl : x)))}
          onRemove={() => onChange(legs.filter((_, j) => j !== i))}
          onDup={() => onChange([...legs.slice(0, i + 1), { ...l }, ...legs.slice(i + 1)])} />
      ))}
      <button className="btn w-full border-dashed" onClick={() => onChange([...legs, makeLeg(legs.length ? { ...legs[legs.length - 1] } : {})])}><Plus size={15} /> Add leg</button>
    </div>
  );
}
