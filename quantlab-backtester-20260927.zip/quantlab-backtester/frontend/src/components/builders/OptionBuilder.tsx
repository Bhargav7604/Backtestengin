import { Layers, LineChart } from 'lucide-react';
import { useStore } from '../../lib/store';
import { describeBlock, hasSignals, LEG_TEMPLATES } from '../../lib/strategy';
import { Alert, Card } from '../ui';
import LegsEditor from './LegsEditor';
import PayoffSketch from './PayoffSketch';

export default function OptionBuilder() {
  const c = useStore(s => s.config);
  const set = useStore(s => s.setConfig);
  const go = useStore(s => s.go);

  return (
    <div className="space-y-5">
      <Card title="Quick templates" icon={<Layers size={16} />}>
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
          {LEG_TEMPLATES.map(t => (
            <button key={t.key} className="card card-hover !rounded-xl px-3 py-2.5 text-left"
              onClick={() => set({ legs: t.legs(), name: t.name, meta: { ...c.meta, source: 'option' } })}>
              <div className="text-sm font-semibold">{t.name}</div>
              <div className="text-[11px] text-slate-500">{t.hint}</div>
            </button>
          ))}
        </div>
      </Card>

      {hasSignals(c) && (
        <Alert kind="info">
          This strategy also has indicator entry rules: <b>{describeBlock(c.entryConds) || describeBlock(c.short?.entryConds)}</b>.{' '}
          <button className="font-semibold underline" onClick={() => go('builder', 'indicator')}>Edit rules</button>
        </Alert>
      )}

      <Card title="Legs" icon={<Layers size={16} />} actions={<span className="text-xs text-slate-400">entered at {c.entryTime}{hasSignals(c) ? ' / on signal' : ''}</span>}>
        <LegsEditor legs={c.legs} onChange={legs => set({ legs })} />
      </Card>

      {c.legs.length > 0 && (
        <Card title="Payoff at expiry (sketch)" icon={<LineChart size={16} />}>
          <PayoffSketch legs={c.legs} />
        </Card>
      )}
    </div>
  );
}
