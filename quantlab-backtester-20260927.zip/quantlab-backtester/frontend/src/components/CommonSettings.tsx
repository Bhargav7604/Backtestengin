import { useState, type ReactNode } from 'react';
import clsx from 'clsx';
import { CalendarRange, ChevronDown, Clock3, Coins, ShieldAlert, SlidersHorizontal } from 'lucide-react';
import { useStore } from '../lib/store';
import { TIMEFRAMES } from '../lib/strategy';
import type { Overall, StrategyConfig } from '../lib/types';
import { Chip, Field, NumInput, Segmented, Select, TextInput, Toggle } from './ui';

function Section({ title, icon, children, defaultOpen = true }: { title: string; icon: ReactNode; children: ReactNode; defaultOpen?: boolean }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="border-b border-slate-100 last:border-0 dark:border-slate-800">
      <button className="flex w-full items-center gap-2 px-4 py-3 text-left text-sm font-semibold" onClick={() => setOpen(!open)}>
        <span className="text-brand-600 dark:text-brand-400">{icon}</span>
        {title}
        <ChevronDown size={16} className={clsx('ml-auto text-slate-400 transition', open && 'rotate-180')} />
      </button>
      {open && <div className="space-y-3 px-4 pb-4">{children}</div>}
    </div>
  );
}

export default function CommonSettings({ signals }: { signals?: boolean }) {
  const meta = useStore(s => s.meta);
  const c = useStore(s => s.config);
  const set = useStore(s => s.setConfig);
  const setOv = (k: keyof Overall, v: number | null) => set({ overall: { ...c.overall, [k]: v } });

  const unds = meta?.underlyings ?? [];
  const idx = unds.filter(u => u.index), stk = unds.filter(u => !u.index);
  const u = unds.find(x => x.exch === c.exch && x.und === c.und);

  const pickUnd = (key: string) => {
    const [exch, und] = key.split(':');
    const nu = unds.find(x => x.exch === exch && x.und === und);
    const patch: Partial<StrategyConfig> = { exch, und };
    if (nu) {
      if (!c.start || c.start < nu.from || c.start > nu.to) patch.start = nu.from;
      if (!c.end || c.end > nu.to || c.end < nu.from) patch.end = nu.to;
    }
    set(patch);
  };

  return (
    <div className="card overflow-hidden">
      <div className="border-b border-slate-100 px-4 py-3 dark:border-slate-800">
        <div className="flex items-center gap-2">
          <SlidersHorizontal size={16} className="text-brand-600" />
          <h3 className="text-sm font-semibold">Common settings</h3>
        </div>
        <input className="inp mt-2" value={c.name ?? ''} onChange={e => set({ name: e.target.value })} placeholder="Strategy name" />
      </div>

      <Section title="Instrument & period" icon={<CalendarRange size={15} />}>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Underlying" className="col-span-2">
            <select className="inp" value={`${c.exch}:${c.und}`} onChange={e => pickUnd(e.target.value)}>
              {!u && <option value={`${c.exch}:${c.und}`}>{c.und} ({c.exch})</option>}
              {idx.length > 0 && <optgroup label="Indices">{idx.map(x => <option key={x.exch + x.und} value={`${x.exch}:${x.und}`}>{x.und}</option>)}</optgroup>}
              {stk.length > 0 && <optgroup label="Stocks">{stk.map(x => <option key={x.exch + x.und} value={`${x.exch}:${x.und}`}>{x.und}</option>)}</optgroup>}
            </select>
          </Field>
          <Field label="Exchange"><div className="inp flex items-center bg-slate-50 text-slate-500 dark:bg-slate-800">{c.exch}</div></Field>
          <Field label="Capital ₹"><NumInput value={c.capital} onChange={v => set({ capital: v ?? 0 })} min={0} step={10000} /></Field>
          <Field label="From"><TextInput type="date" value={c.start} min={u?.from} max={u?.to} onChange={v => set({ start: v })} /></Field>
          <Field label="To"><TextInput type="date" value={c.end} min={u?.from} max={u?.to} onChange={v => set({ end: v })} /></Field>
        </div>
        {u && <div className="text-[11px] text-slate-400">Data available {u.from} → {u.to}. Lot size follows exchange data per expiry.</div>}
      </Section>

      <Section title="Timing" icon={<Clock3 size={15} />}>
        <div className="flex flex-wrap items-center gap-3">
          <Segmented value={c.mode} onChange={v => set({ mode: v })} options={[['intraday', 'Intraday'], ['positional', 'Positional']]} />
          <Select<number> className="!w-auto" value={c.timeframe} onChange={v => set({ timeframe: v })} options={TIMEFRAMES.map(t => [t, `${t} min`] as const)} title="Signal timeframe" />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Entry"><TextInput type="time" value={c.entryTime} onChange={v => set({ entryTime: v })} /></Field>
          <Field label={c.mode === 'positional' ? 'Exit (expiry day)' : 'Exit / square-off'}><TextInput type="time" value={c.exitTime} onChange={v => set({ exitTime: v })} /></Field>
          <Field label="Last entry"><TextInput type="time" value={c.lastEntryTime ?? ''} onChange={v => set({ lastEntryTime: v })} /></Field>
          <Field label="Max trades / day"><NumInput value={c.maxTradesPerDay} onChange={v => set({ maxTradesPerDay: v ?? 1 })} min={1} /></Field>
        </div>
        <Field label="Weekdays">
          <div className="flex flex-wrap gap-1.5">
            {['Mon', 'Tue', 'Wed', 'Thu', 'Fri'].map((n, i) => {
              const d = i + 1, on = c.weekdays.includes(d);
              return <Chip key={n} on={on} onClick={() => set({ weekdays: on ? c.weekdays.filter(x => x !== d) : [...c.weekdays, d].sort() })}>{n}</Chip>;
            })}
          </div>
        </Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="DTE min"><NumInput value={c.dteMin} onChange={v => set({ dteMin: v })} placeholder="any" min={0} /></Field>
          <Field label="DTE max"><NumInput value={c.dteMax} onChange={v => set({ dteMax: v })} placeholder="any" min={0} /></Field>
        </div>
        {c.mode === 'positional' && (
          <Field label="Exit N days before expiry"><NumInput value={c.exitDaysBeforeExpiry ?? 0} onChange={v => set({ exitDaysBeforeExpiry: v ?? 0 })} min={0} /></Field>
        )}
        {!signals && <Toggle checked={!!c.reenterAfterExit} onChange={v => set({ reenterAfterExit: v })} label="Re-enter after exit (same day)" />}
      </Section>

      <Section title="Overall risk (₹ MTM)" icon={<ShieldAlert size={15} />} defaultOpen={false}>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Stop loss ₹"><NumInput value={c.overall.sl} onChange={v => setOv('sl', v)} placeholder="off" /></Field>
          <Field label="Target ₹"><NumInput value={c.overall.tgt} onChange={v => setOv('tgt', v)} placeholder="off" /></Field>
          <Field label="Lock when profit ≥"><NumInput value={c.overall.lockAt} onChange={v => setOv('lockAt', v)} placeholder="off" /></Field>
          <Field label="Lock ₹"><NumInput value={c.overall.lockProfit} onChange={v => setOv('lockProfit', v)} placeholder="—" /></Field>
          <Field label="Trail every ₹"><NumInput value={c.overall.trailEvery} onChange={v => setOv('trailEvery', v)} placeholder="off" /></Field>
          <Field label="Raise by ₹"><NumInput value={c.overall.trailBy} onChange={v => setOv('trailBy', v)} placeholder="—" /></Field>
          <Field label="SL % of capital" className="col-span-2"><NumInput value={c.overall.slPctCapital} onChange={v => setOv('slPctCapital', v)} placeholder="off" step={0.5} /></Field>
        </div>
        <Toggle checked={!!c.exitAllOnLegSl} onChange={v => set({ exitAllOnLegSl: v })} label="Exit all legs when any leg hits SL" />
      </Section>

      <Section title="Costs" icon={<Coins size={15} />} defaultOpen={false}>
        <Toggle checked={c.costs.enabled} onChange={v => set({ costs: { ...c.costs, enabled: v } })} label="Statutory charges (STT, exch, GST, stamp)" />
        <div className="grid grid-cols-2 gap-3">
          <Field label="Brokerage ₹/order"><NumInput value={c.costs.brokerage} onChange={v => set({ costs: { ...c.costs, brokerage: v ?? 0 } })} min={0} /></Field>
          <Field label="Slippage %"><NumInput value={c.costs.slippagePct} onChange={v => set({ costs: { ...c.costs, slippagePct: v ?? 0 } })} step={0.05} min={0} /></Field>
        </div>
      </Section>
    </div>
  );
}
