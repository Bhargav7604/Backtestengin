import { Area, CartesianGrid, ComposedChart, Line, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { inr, inrCompact, pct } from '../../lib/format';
import type { MonteCarlo as MC } from '../../lib/types';
import { COLORS, useChartTheme } from './chartTheme';

function Stat({ k, p5, p50, p95, neg }: { k: string; p5: number; p50: number; p95: number; neg?: boolean }) {
  return (
    <div className="rounded-xl bg-slate-50 p-3 dark:bg-slate-800/50">
      <div className="text-[11px] font-medium uppercase tracking-wide text-slate-500">{k}</div>
      <div className="mt-1 grid grid-cols-3 gap-1 text-center">
        {[['P5', p5], ['P50', p50], ['P95', p95]].map(([l, v]) => (
          <div key={l as string}>
            <div className="text-[10px] text-slate-400">{l}</div>
            <div className={`text-sm font-semibold tabular-nums ${neg ? 'neg' : ''}`}>{inrCompact(v as number)}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function MonteCarlo({ mc }: { mc: MC | null | undefined }) {
  const t = useChartTheme();
  if (!mc) return <div className="text-sm text-slate-400">Monte Carlo needs at least 5 trades.</div>;
  const data = mc.bands.map(b => ({ i: b.i, range: [b.p5, b.p95] as [number, number], p50: b.p50 }));
  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_280px]">
      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={data} margin={{ top: 6, right: 8, bottom: 0, left: 4 }}>
            <CartesianGrid stroke={t.grid} strokeDasharray="3 3" vertical={false} />
            <XAxis dataKey="i" tick={t.tick} stroke={t.axis} label={{ value: 'trade #', position: 'insideBottomRight', offset: -2, fontSize: 11, fill: t.axis }} />
            <YAxis tick={t.tick} stroke={t.axis} tickFormatter={v => inrCompact(v)} width={64} domain={['auto', 'auto']} />
            <Tooltip {...t.tooltip} labelFormatter={v => `After trade ${v}`}
              formatter={(v, n) => (Array.isArray(v) ? [`${inr(Number(v[0]))} – ${inr(Number(v[1]))}`, 'P5–P95'] : [inr(Number(v)), n === 'p50' ? 'Median' : String(n)])} />
            <Area type="monotone" dataKey="range" stroke="none" fill={COLORS.band} fillOpacity={0.45} isAnimationActive={false} />
            <Line type="monotone" dataKey="p50" stroke={COLORS.strategy} strokeWidth={2} dot={false} isAnimationActive={false} />
          </ComposedChart>
        </ResponsiveContainer>
      </div>
      <div className="space-y-3">
        <Stat k="Final equity" {...mc.finalEquity} />
        <Stat k="Max drawdown" {...mc.maxDD} neg />
        <div className="flex items-center justify-between rounded-xl bg-slate-50 p-3 dark:bg-slate-800/50">
          <div>
            <div className="text-[11px] font-medium uppercase tracking-wide text-slate-500">Probability of loss</div>
            <div className="text-[11px] text-slate-400">{mc.runs.toLocaleString('en-IN')} resampled runs</div>
          </div>
          <div className={`text-xl font-bold ${mc.probLoss > 20 ? 'neg' : 'pos'}`}>{pct(mc.probLoss, 1)}</div>
        </div>
      </div>
    </div>
  );
}
