import { useStore } from '../../lib/store';

export const COLORS = {
  strategy: '#16a34a',
  benchmark: '#94a3b8',
  loss: '#e11d48',
  band: '#86efac',
  series: ['#16a34a', '#2563eb', '#d97706', '#9333ea'],
};

export function useChartTheme() {
  const dark = useStore(s => s.theme === 'dark');
  return {
    grid: dark ? '#334155' : '#e2e8f0',
    axis: dark ? '#64748b' : '#94a3b8',
    tooltip: {
      contentStyle: {
        borderRadius: 12, border: `1px solid ${dark ? '#334155' : '#e2e8f0'}`, fontSize: 12,
        background: dark ? '#0f172a' : '#ffffff', color: dark ? '#e2e8f0' : '#0f172a', boxShadow: '0 8px 24px rgba(15,23,42,.12)',
      },
      labelStyle: { fontWeight: 600, marginBottom: 4 },
    },
    tick: { fontSize: 11, fill: dark ? '#94a3b8' : '#64748b' },
  };
}
