import { inr, inrCompact, MONTHS, signCls } from '../../lib/format';

export default function MonthlyHeatmap({ monthly }: { monthly: Record<string, number> }) {
  const years: Record<string, Record<number, number>> = {};
  for (const [k, v] of Object.entries(monthly)) {
    const [y, m] = k.split('-');
    (years[y] ||= {})[+m] = v;
  }
  const mx = Math.max(1, ...Object.values(monthly).map(Math.abs));
  const bg = (v: number | undefined) =>
    v == null ? undefined : `rgba(${v >= 0 ? '22,163,74' : '225,29,72'},${(0.1 + 0.6 * Math.abs(v) / mx).toFixed(2)})`;
  const ys = Object.keys(years).sort();
  if (!ys.length) return <div className="text-sm text-slate-400">No monthly data.</div>;

  return (
    <div className="scroll-thin overflow-x-auto">
      <table className="w-full min-w-[720px] border-separate border-spacing-1 text-xs">
        <thead>
          <tr>
            <th className="px-1 text-left font-medium text-slate-500">Year</th>
            {MONTHS.map(m => <th key={m} className="font-medium text-slate-500">{m}</th>)}
            <th className="font-semibold text-slate-600 dark:text-slate-300">Total</th>
          </tr>
        </thead>
        <tbody>
          {ys.map(y => {
            const ms = years[y];
            const tot = Object.values(ms).reduce((a, b) => a + b, 0);
            return (
              <tr key={y}>
                <td className="px-1 font-semibold">{y}</td>
                {MONTHS.map((_, i) => {
                  const v = ms[i + 1];
                  return (
                    <td key={i} title={v == null ? '' : inr(v)} className="h-10 rounded-lg text-center font-medium tabular-nums" style={{ background: bg(v) ?? 'transparent' }}>
                      {v == null ? <span className="text-slate-300 dark:text-slate-700">·</span> : inrCompact(v)}
                    </td>
                  );
                })}
                <td className={`rounded-lg bg-slate-50 text-center font-semibold tabular-nums dark:bg-slate-800 ${signCls(tot)}`}>{inrCompact(tot)}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
