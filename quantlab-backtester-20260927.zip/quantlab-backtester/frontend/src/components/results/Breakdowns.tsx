import { Bar, BarChart, CartesianGrid, Cell, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { inr, inrCompact, WEEKDAYS } from '../../lib/format';
import type { BacktestResult } from '../../lib/types';
import { COLORS, useChartTheme } from './chartTheme';

function PnlBars({ data, label }: { data: { name: string; pnl: number; trades: number; wins?: number }[]; label: string }) {
  const t = useChartTheme();
  if (!data.length) return <div className="text-sm text-slate-400">No data.</div>;
  return (
    <div className="h-52">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 6, right: 4, bottom: 0, left: 0 }}>
          <CartesianGrid stroke={t.grid} strokeDasharray="3 3" vertical={false} />
          <XAxis dataKey="name" tick={t.tick} stroke={t.axis} interval={0} />
          <YAxis tick={t.tick} stroke={t.axis} tickFormatter={v => inrCompact(v)} width={56} />
          <ReferenceLine y={0} stroke={t.axis} />
          <Tooltip {...t.tooltip} cursor={{ fill: 'rgba(148,163,184,.12)' }}
            formatter={(v, _n, item) => {
              const p = (item as { payload?: { trades: number; wins?: number } }).payload;
              return [`${inr(Number(v))}${p ? ` · ${p.trades} trades${p.wins != null ? `, ${Math.round((p.wins / Math.max(p.trades, 1)) * 100)}% win` : ''}` : ''}`, label];
            }} />
          <Bar dataKey="pnl" radius={[6, 6, 0, 0]} maxBarSize={44} isAnimationActive={false}>
            {data.map((d, i) => <Cell key={i} fill={d.pnl >= 0 ? COLORS.strategy : COLORS.loss} />)}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

export function WeekdayBars({ r }: { r: BacktestResult }) {
  return <PnlBars label="P&L" data={r.weekday.map(d => ({ name: WEEKDAYS[d.day], pnl: d.pnl, trades: d.trades, wins: d.wins }))} />;
}

export function DteBars({ r }: { r: BacktestResult }) {
  return <PnlBars label="P&L" data={r.byDte.map(d => ({ name: `${d.dte}d`, pnl: d.pnl, trades: d.trades }))} />;
}

export function ExitReasons({ r }: { r: BacktestResult }) {
  const items = Object.entries(r.exitReasons).sort((a, b) => b[1] - a[1]);
  const total = items.reduce((a, [, v]) => a + v, 0) || 1;
  if (!items.length) return <div className="text-sm text-slate-400">No exits.</div>;
  return (
    <div className="space-y-2.5">
      {items.map(([k, v]) => (
        <div key={k}>
          <div className="mb-1 flex justify-between text-xs"><span className="font-medium">{k}</span><span className="text-slate-500">{v} · {Math.round((v / total) * 100)}%</span></div>
          <div className="h-2 overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800">
            <div className="h-full rounded-full bg-brand-500" style={{ width: `${(v / total) * 100}%` }} />
          </div>
        </div>
      ))}
    </div>
  );
}
