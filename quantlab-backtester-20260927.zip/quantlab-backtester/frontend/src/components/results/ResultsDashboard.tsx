import { useState } from 'react';
import { AlertTriangle, ArrowLeft, BarChart3, CalendarDays, Check, Dice5, GitCompareArrows, ListOrdered, Save, TrendingUp } from 'lucide-react';
import { api } from '../../lib/api';
import { useStore, type BuilderKind } from '../../lib/store';
import { hasSignals } from '../../lib/strategy';
import type { Stats } from '../../lib/types';
import { Alert, Card, Empty, Modal, Spinner } from '../ui';
import { JobProgress } from '../run/RunBar';
import { DteBars, ExitReasons, WeekdayBars } from './Breakdowns';
import EquityChart from './EquityChart';
import KpiTiles from './KpiTiles';
import MonteCarlo from './MonteCarlo';
import MonthlyHeatmap from './MonthlyHeatmap';
import TradeLog, { CsvButton } from './TradeLog';

function SaveDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const cfg = useStore(s => s.resultConfig);
  const [name, setName] = useState(cfg?.name || '');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [done, setDone] = useState(false);
  const save = async () => {
    if (!cfg) return;
    setBusy(true); setErr(null);
    try { await api.saveStrategy(name || 'Untitled', { ...cfg, name: name || cfg.name }); setDone(true); setTimeout(onClose, 900); }
    catch (e) { setErr((e as Error).message); } finally { setBusy(false); }
  };
  return (
    <Modal open={open} onClose={onClose} title="Save strategy">
      <label className="lbl">Name</label>
      <input className="inp" value={name} onChange={e => setName(e.target.value)} autoFocus onKeyDown={e => e.key === 'Enter' && save()} />
      {err && <div className="mt-3"><Alert>{err}</Alert></div>}
      <div className="mt-4 flex justify-end gap-2">
        <button className="btn" onClick={onClose}>Cancel</button>
        <button className="btn-primary" onClick={save} disabled={busy || done}>{busy ? <Spinner /> : done ? <Check size={15} /> : <Save size={15} />} {done ? 'Saved' : 'Save'}</button>
      </div>
    </Modal>
  );
}

export default function ResultsDashboard() {
  const r = useStore(s => s.result);
  const cfg = useStore(s => s.resultConfig);
  const runs = useStore(s => s.runs);
  const compare = useStore(s => s.compare);
  const toggleCompare = useStore(s => s.toggleCompare);
  const go = useStore(s => s.go);
  const builder = useStore(s => s.builder);
  const job = useStore(s => s.job);
  const [saveOpen, setSaveOpen] = useState(false);

  if (!r || !cfg) return <Empty>No results yet. Build a strategy and run a backtest.</Empty>;
  const current = runs.find(x => x.result === r);
  const inCompare = current ? compare.includes(current.id) : false;
  const s = r.stats as Stats & { benchmarkReturnPct?: number };

  const backToBuilder = () => {
    useStore.getState().replaceConfig(cfg);
    const src = cfg.meta?.source as BuilderKind | undefined;
    const k: BuilderKind = src === 'prompt' || src === 'pine' || src === 'python' ? src : src === 'marketplace' ? (hasSignals(cfg) ? 'indicator' : 'option') : builder === 'marketplace' ? 'option' : builder;
    go('builder', k);
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center gap-3">
        <button className="btn-ghost btn-sm" onClick={backToBuilder}><ArrowLeft size={15} /> Edit strategy</button>
        <div className="min-w-0">
          <h1 className="truncate text-xl font-bold tracking-tight">{cfg.name || 'Backtest results'}</h1>
          <div className="text-xs text-slate-500">{cfg.und} ({cfg.exch}) · {cfg.start} → {cfg.end} · capital {cfg.capital.toLocaleString('en-IN')} {r.elapsed != null && `· ${r.elapsed}s`} {r.spotSource && `· spot: ${r.spotSource}`}</div>
        </div>
        <div className="ml-auto flex flex-wrap gap-2">
          <CsvButton trades={r.trades} und={cfg.und} name={cfg.name || 'run'} />
          {current && (
            <button className={`btn btn-sm ${inCompare ? 'chip-on' : ''}`} onClick={() => toggleCompare(current.id)}>
              <GitCompareArrows size={13} /> {inCompare ? 'In compare' : 'Add to compare'}
            </button>
          )}
          {compare.length > 0 && <button className="btn btn-sm" onClick={() => go('compare')}>Compare ({compare.length})</button>}
          <button className="btn-primary btn-sm" onClick={() => setSaveOpen(true)}><Save size={13} /> Save strategy</button>
        </div>
      </div>

      {job && <div className="card p-3"><JobProgress /></div>}

      <KpiTiles s={s} />

      {(Object.keys(r.skipped || {}).length > 0 || (r.warnings || []).length > 0) && (
        <div className="space-y-2">
          {Object.keys(r.skipped || {}).length > 0 && (
            <Alert kind="info">Skipped sessions: {Object.entries(r.skipped).map(([k, v]) => `${k} ×${v}`).join(' · ')}</Alert>
          )}
          {(r.warnings || []).slice(0, 6).map((w, i) => <Alert key={i} kind="warn">{w}</Alert>)}
          {(r.warnings || []).length > 6 && <div className="text-xs text-slate-400"><AlertTriangle size={12} className="inline" /> +{r.warnings.length - 6} more warnings</div>}
        </div>
      )}

      {!r.trades.length ? <Empty>No trades were triggered in this period. Loosen the filters or rules and try again.</Empty> : <>
        <Card title="Equity curve" icon={<TrendingUp size={16} />}><EquityChart r={r} /></Card>
        <Card title="Monthly P&L" icon={<CalendarDays size={16} />}><MonthlyHeatmap monthly={r.monthly} /></Card>
        <div className="grid gap-5 lg:grid-cols-3">
          <Card title="P&L by weekday" icon={<BarChart3 size={16} />}><WeekdayBars r={r} /></Card>
          <Card title="P&L by days to expiry" icon={<BarChart3 size={16} />}><DteBars r={r} /></Card>
          <Card title="Leg exit reasons" icon={<ListOrdered size={16} />}><ExitReasons r={r} /></Card>
        </div>
        <Card title="Monte Carlo (trade resampling)" icon={<Dice5 size={16} />}><MonteCarlo mc={r.montecarlo} /></Card>
        <Card title="Trade log" icon={<ListOrdered size={16} />} actions={<CsvButton trades={r.trades} und={cfg.und} name={cfg.name || 'run'} />}>
          <TradeLog trades={r.trades} und={cfg.und} />
        </Card>
      </>}
      {saveOpen && <SaveDialog open={saveOpen} onClose={() => setSaveOpen(false)} />}
    </div>
  );
}
