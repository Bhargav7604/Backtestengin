import { useMemo, useState } from 'react';
import clsx from 'clsx';
import { ArrowLeft, GitCompareArrows } from 'lucide-react';
import { CartesianGrid, Legend, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { useStore } from '../../lib/store';
import { inr, inrCompact, num, pct, timeAgo } from '../../lib/format';
import type { Stats } from '../../lib/types';
import { Card, Empty, Segmented } from '../ui';
import { COLORS, useChartTheme } from './chartTheme';

const ROWS: [keyof Stats, string, (v: number | null) => string, 'hi' | 'lo'][] = [
  ['netPnl', 'Net P&L', v => inr(v), 'hi'], ['returnPct', 'Return', v => pct(v), 'hi'], ['cagr', 'CAGR', v => pct(v), 'hi'],
  ['winRate', 'Win rate', v => pct(v), 'hi'], ['profitFactor', 'Profit factor', v => num(v), 'hi'], ['maxDD', 'Max DD ₹', v => inr(v), 'hi'],
  ['maxDDPct', 'Max DD %', v => pct(v), 'hi'], ['sharpe', 'Sharpe', v => num(v), 'hi'], ['sortino', 'Sortino', v => num(v), 'hi'],
  ['calmar', 'Calmar', v => num(v), 'hi'], ['expectancy', 'Expectancy', v => inr(v), 'hi'], ['trades', 'Trades', v => String(v ?? '—'), 'hi'],
  ['charges', 'Charges', v => inr(v), 'lo'],
];

export default function ComparePage() {
  const runs = useStore(s => s.runs);
  const compare = useStore(s => s.compare);
  const toggle = useStore(s => s.toggleCompare);
  const go = useStore(s => s.go);
  const t = useChartTheme();
  const [mode, setMode] = useState<'abs' | 'pct'>('abs');
  const sel = compare.map(id => runs.find(r => r.id === id)).filter((x): x is NonNullable<typeof x> => !!x);

  const data = useMemo(() => {
    const m = new Map<string, Record<string, number | string>>();
    sel.forEach((r, i) => {
      const cap = r.config.capital || 1;
      for (const e of r.result.equity) {
        const row = m.get(e.date) ?? { date: e.date };
        row[`r${i}`] = mode === 'abs' ? e.equity - cap : ((e.equity - cap) / cap) * 100;
        m.set(e.date, row);
      }
    });
    return [...m.values()].sort((a, b) => String(a.date).localeCompare(String(b.date)));
  }, [sel, mode]);

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center gap-3">
        <button className="btn-ghost btn-sm" onClick={() => go(useStore.getState().result ? 'results' : 'home')}><ArrowLeft size={15} /> Back</button>
        <h1 className="text-xl font-bold tracking-tight">Compare runs</h1>
        <span className="text-xs text-slate-500">pick up to 4</span>
      </div>

      <Card title="Runs this session" icon={<GitCompareArrows size={16} />}>
        {!runs.length ? <Empty>Run a few backtests first.</Empty> : (
          <div className="flex flex-wrap gap-2">
            {runs.map(r => {
              const i = compare.indexOf(r.id);
              return (
                <button key={r.id} onClick={() => toggle(r.id)} className={clsx('chip !py-1.5', i >= 0 && 'chip-on')}>
                  {i >= 0 && <span className="h-2.5 w-2.5 rounded-full" style={{ background: COLORS.series[i] }} />}
                  {r.label} <span className="text-slate-400">· {timeAgo(r.at)}</span>
                </button>
              );
            })}
          </div>
        )}
      </Card>

      {sel.length > 0 && <>
        <Card title="Equity overlay" actions={<Segmented small value={mode} onChange={setMode} options={[['abs', '₹ P&L'], ['pct', '% of capital']]} />}>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data} margin={{ top: 4, right: 8, bottom: 0, left: 4 }}>
                <CartesianGrid stroke={t.grid} strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="date" tick={t.tick} stroke={t.axis} minTickGap={40} />
                <YAxis tick={t.tick} stroke={t.axis} width={64} tickFormatter={v => (mode === 'abs' ? inrCompact(v) : `${v.toFixed(0)}%`)} />
                <Tooltip {...t.tooltip} formatter={(v, n) => [mode === 'abs' ? inr(Number(v)) : pct(Number(v)), sel[+String(n).slice(1)]?.label ?? String(n)]} />
                <Legend formatter={v => sel[+String(v).slice(1)]?.label ?? v} wrapperStyle={{ fontSize: 12 }} />
                {sel.map((_, i) => <Line key={i} type="monotone" dataKey={`r${i}`} stroke={COLORS.series[i]} strokeWidth={2} dot={false} connectNulls isAnimationActive={false} />)}
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card title="Side-by-side stats" bodyClass="p-0">
          <div className="scroll-thin overflow-x-auto">
            <table className="tbl">
              <thead>
                <tr>
                  <th className="l">Metric</th>
                  {sel.map((r, i) => (
                    <th key={r.id} className="normal-case">
                      <span className="inline-flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-full" style={{ background: COLORS.series[i] }} />{r.label}</span>
                      <div className="text-[10px] font-normal text-slate-400">{r.config.start} → {r.config.end}</div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {ROWS.map(([k, label, f, better]) => {
                  const vs = sel.map(r => r.result.stats[k] as number | null);
                  const valid = vs.filter((v): v is number => v != null);
                  const best = valid.length > 1 ? (better === 'hi' ? Math.max(...valid) : Math.min(...valid)) : null;
                  return (
                    <tr key={k}>
                      <td className="l font-medium">{label}</td>
                      {vs.map((v, i) => <td key={i} className={clsx(v === best && 'font-bold text-brand-600 dark:text-brand-400')}>{f(v)}</td>)}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </Card>
      </>}
    </div>
  );
}
