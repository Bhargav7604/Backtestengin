import { useMemo, useState } from 'react';
import { Area, CartesianGrid, ComposedChart, Legend, Line, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { inr, inrCompact } from '../../lib/format';
import type { BacktestResult } from '../../lib/types';
import { Toggle } from '../ui';
import { COLORS, useChartTheme } from './chartTheme';

export default function EquityChart({ r }: { r: BacktestResult }) {
  const t = useChartTheme();
  const [bench, setBench] = useState(true);
  const data = useMemo(() => {
    const b = new Map((r.benchmark ?? []).map(x => [x.date, x.equity]));
    return r.equity.map(e => ({ date: e.date, equity: e.equity, dd: e.dd, benchmark: b.get(e.date) ?? null }));
  }, [r]);
  const hasBench = (r.benchmark?.length ?? 0) > 0;

  return (
    <div>
      {hasBench && <div className="mb-2 flex justify-end"><Toggle checked={bench} onChange={setBench} label={<span className="text-xs">Buy & hold {r.config?.und ?? 'underlying'}</span>} /></div>}
      <div className="h-72">
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={data} syncId="eq" margin={{ top: 4, right: 8, bottom: 0, left: 4 }}>
            <defs>
              <linearGradient id="eqFill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={COLORS.strategy} stopOpacity={0.25} />
                <stop offset="100%" stopColor={COLORS.strategy} stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid stroke={t.grid} strokeDasharray="3 3" vertical={false} />
            <XAxis dataKey="date" tick={t.tick} stroke={t.axis} minTickGap={40} />
            <YAxis tick={t.tick} stroke={t.axis} tickFormatter={v => inrCompact(v)} width={64} domain={['auto', 'auto']} />
            <Tooltip {...t.tooltip} formatter={(v, n) => [inr(Number(v)), n === 'equity' ? 'Strategy' : 'Buy & hold']} />
            <Legend verticalAlign="top" height={24} iconType="plainline" formatter={v => (v === 'equity' ? 'Strategy equity' : 'Buy & hold')} wrapperStyle={{ fontSize: 12 }} />
            <Area type="monotone" dataKey="equity" stroke={COLORS.strategy} strokeWidth={2} fill="url(#eqFill)" dot={false} isAnimationActive={false} />
            {hasBench && bench && <Line type="monotone" dataKey="benchmark" stroke={COLORS.benchmark} strokeWidth={1.5} strokeDasharray="5 4" dot={false} connectNulls isAnimationActive={false} />}
          </ComposedChart>
        </ResponsiveContainer>
      </div>
      <div className="mt-2 text-[11px] font-medium uppercase tracking-wide text-slate-500">Drawdown</div>
      <div className="h-28">
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={data} syncId="eq" margin={{ top: 4, right: 8, bottom: 0, left: 4 }}>
            <defs>
              <linearGradient id="ddFill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={COLORS.loss} stopOpacity={0.05} />
                <stop offset="100%" stopColor={COLORS.loss} stopOpacity={0.35} />
              </linearGradient>
            </defs>
            <CartesianGrid stroke={t.grid} strokeDasharray="3 3" vertical={false} />
            <XAxis dataKey="date" tick={false} stroke={t.axis} height={4} />
            <YAxis tick={t.tick} stroke={t.axis} tickFormatter={v => inrCompact(v)} width={64} />
            <Tooltip {...t.tooltip} formatter={v => [inr(Number(v)), 'Drawdown']} />
            <Area type="monotone" dataKey="dd" stroke={COLORS.loss} strokeWidth={1.5} fill="url(#ddFill)" dot={false} isAnimationActive={false} />
          </ComposedChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
