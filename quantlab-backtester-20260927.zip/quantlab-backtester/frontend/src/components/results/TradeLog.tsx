import { Fragment, useMemo, useState } from 'react';
import clsx from 'clsx';
import { ArrowDown, ArrowUp, ChevronRight, Download } from 'lucide-react';
import { downloadText, inr, signCls } from '../../lib/format';
import type { Trade } from '../../lib/types';

type Key = 'id' | 'entry' | 'exit' | 'side' | 'spotIn' | 'exitReason' | 'mfe' | 'mae' | 'charges' | 'net';
const COLS: [Key, string, boolean][] = [
  ['id', '#', true], ['entry', 'Entry', true], ['exit', 'Exit', true], ['side', 'Side', true], ['spotIn', 'Spot', false],
  ['exitReason', 'Reason', true], ['mfe', 'MFE', false], ['mae', 'MAE', false], ['charges', 'Charges', false], ['net', 'Net P&L', false],
];
const val = (t: Trade, k: Key): string | number =>
  k === 'entry' ? `${t.entryDate} ${t.entryTime}` : k === 'exit' ? `${t.exitDate} ${t.exitTime}` : k === 'side' ? t.side ?? 'long' : (t[k] as string | number);

export function exportTradesCsv(trades: Trade[], und: string, name: string) {
  const head = ['trade', 'side', 'entry_date', 'entry_time', 'exit_date', 'exit_time', 'spot_in', 'trade_net', 'leg', 'reentry', 'leg_side', 'type', 'expiry', 'strike', 'qty', 'entry', 'exit', 'reason', 'leg_pnl', 'leg_charges', 'iv', 'delta'];
  const rows = [head.join(',')];
  const esc = (x: unknown) => { const s = x == null ? '' : String(x); return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
  for (const t of trades) for (const l of t.legs) {
    rows.push([t.id, t.side ?? 'long', t.entryDate, t.entryTime, t.exitDate, t.exitTime, t.spotIn, t.net, l.leg, l.reentry, l.side, l.type, l.expiry, l.strike, l.qty, l.entry, l.exit, l.reason, l.pnl, l.charges, l.iv, l.delta].map(esc).join(','));
  }
  downloadText(`trades_${und}_${name.replace(/\W+/g, '_')}.csv`, rows.join('\n'));
}

export default function TradeLog({ trades, und }: { trades: Trade[]; und: string }) {
  const [sort, setSort] = useState<{ k: Key; asc: boolean }>({ k: 'id', asc: false });
  const [open, setOpen] = useState<Set<number>>(new Set());
  const [limit, setLimit] = useState(100);
  const [filter, setFilter] = useState<'all' | 'win' | 'loss' | 'long' | 'short'>('all');

  const rows = useMemo(() => {
    const f = trades.filter(t => filter === 'all' || (filter === 'win' ? t.net > 0 : filter === 'loss' ? t.net <= 0 : (t.side ?? 'long') === filter));
    const s = [...f].sort((a, b) => {
      const x = val(a, sort.k), y = val(b, sort.k);
      const c = typeof x === 'number' && typeof y === 'number' ? x - y : String(x).localeCompare(String(y));
      return sort.asc ? c : -c;
    });
    return s;
  }, [trades, sort, filter]);
  const hasShort = trades.some(t => t.side === 'short');

  const toggle = (id: number) => { const n = new Set(open); n.has(id) ? n.delete(id) : n.add(id); setOpen(n); };

  return (
    <div>
      <div className="mb-3 flex flex-wrap gap-1.5">
        {(['all', 'win', 'loss', ...(hasShort ? ['long', 'short'] : [])] as const).map(f => (
          <button key={f} className={clsx('chip', filter === f && 'chip-on')} onClick={() => setFilter(f as typeof filter)}>{f[0].toUpperCase() + f.slice(1)}</button>
        ))}
        <span className="ml-auto self-center text-xs text-slate-400">{rows.length} trades</span>
      </div>
      <div className="scroll-thin max-h-[560px] overflow-auto rounded-xl border border-slate-100 dark:border-slate-800">
        <table className="tbl">
          <thead>
            <tr>
              <th className="l w-6" />
              {COLS.map(([k, t, left]) => (
                <th key={k} className={clsx(left && 'l', 'cursor-pointer select-none hover:text-brand-600')} onClick={() => setSort({ k, asc: sort.k === k ? !sort.asc : k !== 'net' })}>
                  <span className="inline-flex items-center gap-0.5">{t}{sort.k === k && (sort.asc ? <ArrowUp size={11} /> : <ArrowDown size={11} />)}</span>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.slice(0, limit).map(t => (
              <Fragment key={t.id}>
                <tr className="cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800/50" onClick={() => toggle(t.id)}>
                  <td className="l"><ChevronRight size={14} className={clsx('text-slate-400 transition', open.has(t.id) && 'rotate-90')} /></td>
                  <td className="l text-slate-500">{t.id}</td>
                  <td className="l">{t.entryDate} <span className="text-slate-400">{t.entryTime}</span></td>
                  <td className="l">{t.exitDate} <span className="text-slate-400">{t.exitTime}</span></td>
                  <td className="l">
                    <span className={clsx('badge', (t.side ?? 'long') === 'long' ? 'bg-brand-100 text-brand-700 dark:bg-brand-900/50 dark:text-brand-300' : 'bg-rose-100 text-rose-700 dark:bg-rose-900/40 dark:text-rose-300')}>
                      {(t.side ?? 'long').toUpperCase()}
                    </span>
                  </td>
                  <td>{t.spotIn.toLocaleString('en-IN')}</td>
                  <td className="l">{t.exitReason}</td>
                  <td className={signCls(t.mfe)}>{inr(t.mfe)}</td>
                  <td className={signCls(t.mae)}>{inr(t.mae)}</td>
                  <td className="mut">{inr(t.charges)}</td>
                  <td className={clsx('font-semibold', signCls(t.net))}>{inr(t.net)}</td>
                </tr>
                {open.has(t.id) && (
                  <tr>
                    <td colSpan={COLS.length + 1} className="!bg-slate-50/80 !p-2 dark:!bg-slate-800/40">
                      <div className="overflow-x-auto">
                        <table className="tbl text-xs">
                          <thead>
                            <tr>{['Leg', 'Side', 'Contract', 'Qty', 'Entry', 'Entry ₹', 'Exit', 'Exit ₹', 'IV %', 'Δ', 'Reason', 'P&L'].map((h, i) => <th key={h} className={clsx(i < 3 || h === 'Reason' ? 'l' : '', '!bg-transparent')}>{h}</th>)}</tr>
                          </thead>
                          <tbody>
                            {t.legs.map((l, i) => (
                              <tr key={i}>
                                <td className="l">{l.leg}{l.reentry && <span className="ml-1 text-[10px] text-amber-600">re</span>}</td>
                                <td className={clsx('l font-semibold', l.side === 'BUY' ? 'pos' : 'neg')}>{l.side}</td>
                                <td className="l">{und} {l.expiry} {l.type === 'FUT' ? 'FUT' : `${l.strike} ${l.type}`}</td>
                                <td>{l.qty}</td>
                                <td className="l">{l.entryTime.slice(5)}</td>
                                <td>{l.entry.toFixed(2)}</td>
                                <td className="l">{l.exitTime.slice(5)}</td>
                                <td>{l.exit.toFixed(2)}</td>
                                <td>{l.iv ?? '—'}</td>
                                <td>{l.delta ?? '—'}</td>
                                <td className="l">{l.reason}</td>
                                <td className={signCls(l.pnl)}>{inr(l.pnl)}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </td>
                  </tr>
                )}
              </Fragment>
            ))}
          </tbody>
        </table>
      </div>
      {rows.length > limit && (
        <div className="mt-3 text-center"><button className="btn btn-sm" onClick={() => setLimit(limit + 200)}>Show more ({rows.length - limit} left)</button></div>
      )}
    </div>
  );
}

export function CsvButton({ trades, und, name }: { trades: Trade[]; und: string; name: string }) {
  return <button className="btn btn-sm" onClick={() => exportTradesCsv(trades, und, name)} disabled={!trades.length}><Download size={13} /> CSV</button>;
}
