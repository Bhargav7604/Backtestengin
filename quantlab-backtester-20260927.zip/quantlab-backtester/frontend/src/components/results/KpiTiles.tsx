import clsx from 'clsx';
import { inr, num, pct, signCls } from '../../lib/format';
import type { Stats } from '../../lib/types';

function Tile({ k, v, cls, sub, big }: { k: string; v: string; cls?: string; sub?: string; big?: boolean }) {
  return (
    <div className={clsx('card p-3.5', big && 'card-mint')}>
      <div className="text-[11px] font-medium uppercase tracking-wide text-slate-500 dark:text-slate-400">{k}</div>
      <div className={clsx('mt-1 font-semibold tabular-nums tracking-tight', big ? 'text-2xl' : 'text-lg', cls)}>{v}</div>
      {sub && <div className="mt-0.5 text-[11px] text-slate-400">{sub}</div>}
    </div>
  );
}

export default function KpiTiles({ s }: { s: Stats & { benchmarkReturnPct?: number } }) {
  return (
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
      <Tile big k="Net P&L" v={inr(s.netPnl)} cls={signCls(s.netPnl)} sub={`Gross ${inr(s.grossPnl)}`} />
      <Tile big k="Return" v={pct(s.returnPct)} cls={signCls(s.returnPct)} sub={s.benchmarkReturnPct != null ? `Buy & hold ${pct(s.benchmarkReturnPct)}` : undefined} />
      <Tile big k="CAGR" v={pct(s.cagr)} cls={signCls(s.cagr)} />
      <Tile big k="Win rate" v={pct(s.winRate)} sub={`${s.winDays} win / ${s.lossDays} loss days`} />
      <Tile big k="Profit factor" v={s.profitFactor == null ? '—' : num(s.profitFactor)} cls={s.profitFactor != null ? (s.profitFactor >= 1 ? 'pos' : 'neg') : ''} sub={s.payoffRatio != null ? `Payoff ${num(s.payoffRatio)}` : undefined} />
      <Tile big k="Max drawdown" v={inr(s.maxDD)} cls="neg" sub={`${pct(s.maxDDPct)} · ${s.maxDDDays}d`} />
      <Tile k="Sharpe" v={num(s.sharpe)} />
      <Tile k="Sortino" v={num(s.sortino)} />
      <Tile k="Calmar" v={s.calmar == null ? '—' : num(s.calmar)} />
      <Tile k="Expectancy" v={inr(s.expectancy)} cls={signCls(s.expectancy)} sub={`Avg win ${inr(s.avgWin)} · loss ${inr(s.avgLoss)}`} />
      <Tile k="Trades" v={String(s.trades)} sub={`${s.tradedDays}/${s.sessions} sessions · streak ${s.maxWinStreak}W/${s.maxLossStreak}L`} />
      <Tile k="Charges" v={inr(s.charges)} cls="mut" sub={`Best ${inr(s.bestTrade)} · worst ${inr(s.worstTrade)}`} />
    </div>
  );
}
