import { useMemo, useRef, useState } from 'react';
import clsx from 'clsx';
import { Grid3x3, Play, Plus, Square, Trophy, X } from 'lucide-react';
import { api, pollJob } from '../../lib/api';
import { useStore } from '../../lib/store';
import { cleanConfig, getPath, setPath } from '../../lib/strategy';
import { inr, num } from '../../lib/format';
import type { OptimizeResult, Stats } from '../../lib/types';
import { Alert, Field, Modal, Select, Spinner } from '../ui';

const PRESETS: [string, string, string][] = [
  ['legs.0.sl', 'Leg 1 stop loss', '20,25,30,40'],
  ['legs.0.tgt', 'Leg 1 target', '0,40,60,80'],
  ['legs.0.strikeValue', 'Leg 1 strike value', '0,1,2,3'],
  ['legs.1.sl', 'Leg 2 stop loss', '20,25,30,40'],
  ['legs.1.strikeValue', 'Leg 2 strike value', '0,1,2,3'],
  ['entryTime', 'Entry time', '09:20,09:30,09:45,10:00'],
  ['exitTime', 'Exit time', '14:30,15:00,15:15'],
  ['timeframe', 'Timeframe (min)', '3,5,15'],
  ['maxTradesPerDay', 'Max trades / day', '1,2,3'],
  ['overall.sl', 'Overall SL ₹', '3000,5000,8000'],
  ['overall.tgt', 'Overall target ₹', '5000,10000,15000'],
];
const METRICS: [keyof Stats, string][] = [
  ['netPnl', 'Net P&L'], ['sharpe', 'Sharpe'], ['returnPct', 'Return %'], ['calmar', 'Calmar'],
  ['profitFactor', 'Profit factor'], ['winRate', 'Win rate'], ['maxDD', 'Max DD (least)'], ['expectancy', 'Expectancy'],
];
const TIMEY = new Set(['entryTime', 'exitTime', 'lastEntryTime']);

const parseVals = (path: string, s: string) =>
  s.split(',').map(x => x.trim()).filter(Boolean).map(x => (TIMEY.has(path) || Number.isNaN(+x) ? x : +x));

const fmtMetric = (m: string, v: number | null | undefined) =>
  v == null ? '—' : ['netPnl', 'maxDD', 'expectancy'].includes(m) ? inr(v) : m.endsWith('Pct') || m === 'winRate' ? `${num(v)}%` : num(v);

export default function OptimizeDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const config = useStore(s => s.config);
  const setConfig = useStore(s => s.replaceConfig);
  const [rows, setRows] = useState<{ path: string; values: string }[]>([{ path: PRESETS[0][0], values: PRESETS[0][2] }]);
  const [metric, setMetric] = useState<keyof Stats>('netPnl');
  const [job, setJob] = useState<{ id: string; progress: number; message?: string } | null>(null);
  const [res, setRes] = useState<OptimizeResult | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const cancelRef = useRef(false);

  const params = rows.map(r => ({ path: r.path, values: parseVals(r.path, r.values) }));
  const combos = params.reduce((a, p) => a * Math.max(p.values.length, 1), 1);
  const available = PRESETS.filter(p => getPath(config, p[0].split('.').slice(0, 2).join('.')) !== undefined || !p[0].startsWith('legs'));

  const start = async () => {
    setErr(null); setRes(null); cancelRef.current = false;
    try {
      const { id } = await api.startOptimize(cleanConfig(config), params, metric);
      setJob({ id, progress: 0 });
      const j = await pollJob<OptimizeResult>(id, s => setJob({ id, progress: s.progress, message: s.message }), () => cancelRef.current);
      if (j.status === 'error') throw new Error(j.error || 'Optimization failed');
      if (j.status === 'done' && j.result) setRes(j.result);
    } catch (e) { setErr((e as Error).message); } finally { setJob(null); }
  };
  const stop = async () => { cancelRef.current = true; if (job) { try { await api.cancelJob(job.id); } catch { /* ignore */ } } };

  const apply = (values: (number | string)[]) => {
    let c = config;
    const ps = (res?.params ?? params) as { path: string }[];
    ps.forEach((p, i) => { c = setPath(c, typeof p === 'string' ? p : p.path, values[i]); });
    setConfig(c);
    onClose();
  };

  const grid = useMemo(() => {
    if (!res) return null;
    const ps = (res.params as { path: string; values: (number | string)[] }[]);
    const m = res.metric;
    const vals = res.grid.map(g => (g.stats ? (g.stats as Record<string, number | null>)[m] : null)).filter((v): v is number => v != null);
    const lo = Math.min(...vals), hi = Math.max(...vals);
    const lookup = new Map(res.grid.map(g => [JSON.stringify(g.values), g]));
    const rowsV = ps[0]?.values ?? [];
    const colsV = ps[1]?.values ?? [null];
    return { ps, m, lo, hi, lookup, rowsV, colsV };
  }, [res]);

  const bestKey = res?.best ? JSON.stringify(res.best.values) : '';

  return (
    <Modal open={open} onClose={onClose} title={<span className="inline-flex items-center gap-2"><Grid3x3 size={16} className="text-brand-600" /> Optimize parameters</span>} wide>
      <div className="space-y-4">
        {rows.map((r, i) => (
          <div key={i} className="grid grid-cols-[1fr_1.3fr_auto] items-end gap-2">
            <Field label={`Parameter ${i + 1}`}>
              <Select value={r.path} onChange={v => setRows(rows.map((x, j) => (j === i ? { path: v, values: PRESETS.find(p => p[0] === v)?.[2] ?? '' } : x)))}
                options={available.map(p => [p[0], p[1]] as const)} />
            </Field>
            <Field label="Values (comma separated)">
              <input className="inp font-mono" value={r.values} onChange={e => setRows(rows.map((x, j) => (j === i ? { ...x, values: e.target.value } : x)))} />
            </Field>
            <button className="btn h-9" disabled={rows.length === 1} onClick={() => setRows(rows.filter((_, j) => j !== i))} aria-label="Remove"><X size={14} /></button>
          </div>
        ))}
        <div className="flex flex-wrap items-end gap-3">
          {rows.length < 2 && <button className="btn btn-sm" onClick={() => setRows([...rows, { path: PRESETS[5][0], values: PRESETS[5][2] }])}><Plus size={13} /> Second parameter</button>}
          <Field label="Optimize for" className="w-48"><Select<keyof Stats> value={metric} onChange={setMetric} options={METRICS} /></Field>
          <span className={clsx('text-xs', combos > 36 ? 'font-semibold text-rose-600' : 'text-slate-500')}>{combos} combinations (max 36)</span>
          <div className="ml-auto">
            {job
              ? <button className="btn" onClick={stop}><Square size={14} /> Stop</button>
              : <button className="btn-primary" disabled={combos > 36 || combos < 1} onClick={start}><Play size={15} /> Run optimization</button>}
          </div>
        </div>

        {job && (
          <div>
            <div className="mb-1 flex items-center gap-2 text-xs text-slate-500"><Spinner className="h-3 w-3" /> {job.message || 'Working…'} <span className="ml-auto">{Math.round(job.progress * 100)}%</span></div>
            <div className="h-2 overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800"><div className="h-full rounded-full bg-brand-500 transition-all" style={{ width: `${job.progress * 100}%` }} /></div>
          </div>
        )}
        {err && <Alert onClose={() => setErr(null)}>{err}</Alert>}

        {grid && res && (
          <div className="space-y-3">
            {res.best && (
              <div className="flex flex-wrap items-center gap-3 rounded-xl border border-brand-200 bg-brand-50 p-3 text-sm dark:border-brand-900 dark:bg-brand-950/40">
                <Trophy size={16} className="text-brand-600" />
                <span>Best: {grid.ps.map((p, i) => <b key={p.path} className="mr-2">{p.path} = {String(res.best!.values[i])}</b>)}</span>
                <span className="text-slate-500">{METRICS.find(m => m[0] === res.metric)?.[1] ?? res.metric}: <b>{fmtMetric(res.metric, (res.best.stats as Record<string, number>)[res.metric])}</b></span>
                <button className="btn-primary btn-sm ml-auto" onClick={() => apply(res.best!.values)}>Apply best</button>
              </div>
            )}
            <div className="scroll-thin overflow-x-auto">
              <table className="tbl">
                <thead>
                  <tr>
                    <th className="l">{grid.ps[0]?.path}{grid.ps[1] ? ` ↓ / ${grid.ps[1].path} →` : ''}</th>
                    {grid.colsV.map(c => <th key={String(c)}>{c == null ? METRICS.find(m => m[0] === res.metric)?.[1] : String(c)}</th>)}
                  </tr>
                </thead>
                <tbody>
                  {grid.rowsV.map(r => (
                    <tr key={String(r)}>
                      <td className="l font-semibold">{String(r)}</td>
                      {grid.colsV.map(c => {
                        const key = JSON.stringify(c == null ? [r] : [r, c]);
                        const g = grid.lookup.get(key);
                        const v = g?.stats ? (g.stats as Record<string, number | null>)[grid.m] : null;
                        const t = v == null || grid.hi === grid.lo ? 0.5 : (v - grid.lo) / (grid.hi - grid.lo);
                        const good = t >= 0.5;
                        const alpha = 0.1 + Math.abs(t - 0.5) * 1.1;
                        return (
                          <td key={key} className="!p-1">
                            <button
                              onClick={() => g && apply(g.values)}
                              title="Click to apply these values"
                              className={clsx('w-full rounded-lg px-2 py-2 text-center text-xs font-semibold tabular-nums transition hover:ring-2 hover:ring-brand-500', key === bestKey && 'ring-2 ring-brand-600')}
                              style={{ background: v == null ? undefined : good ? `rgba(22,163,74,${alpha})` : `rgba(225,29,72,${alpha})` }}
                            >
                              {v == null ? '—' : fmtMetric(grid.m, v)}
                              {g?.stats?.trades != null && <div className="text-[10px] font-normal opacity-70">{g.stats.trades} trades</div>}
                            </button>
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <p className="text-xs text-slate-400">Click any cell to apply those values to the current strategy.</p>
          </div>
        )}
      </div>
    </Modal>
  );
}
