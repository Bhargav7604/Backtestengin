import { useState } from 'react';
import { Grid3x3, Play, Square } from 'lucide-react';
import { useStore } from '../../lib/store';
import { hasSignals } from '../../lib/strategy';
import { Alert, Spinner } from '../ui';
import OptimizeDialog from './OptimizeDialog';

export function JobProgress() {
  const job = useStore(s => s.job);
  const cancel = useStore(s => s.cancel);
  if (!job) return null;
  const p = Math.max(0.02, job.progress || 0);
  return (
    <div className="flex items-center gap-3">
      <div className="min-w-0 flex-1">
        <div className="mb-1 flex items-center gap-2 text-xs text-slate-500">
          <Spinner className="h-3 w-3 text-brand-600" />
          <span className="truncate">{job.message || (job.status === 'queued' ? 'Queued…' : job.status === 'starting' ? 'Submitting…' : 'Running…')}</span>
          <span className="ml-auto tabular-nums">{Math.round((job.progress || 0) * 100)}%</span>
        </div>
        <div className="h-2 overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800">
          <div className="h-full rounded-full bg-gradient-to-r from-brand-500 to-emerald-400 transition-all duration-500" style={{ width: `${p * 100}%` }} />
        </div>
      </div>
      <button className="btn btn-sm" onClick={cancel}><Square size={12} /> Cancel</button>
    </div>
  );
}

/** Sticky bottom bar used by every builder. */
export default function RunBar({ disabledReason }: { disabledReason?: string }) {
  const run = useStore(s => s.run);
  const job = useStore(s => s.job);
  const err = useStore(s => s.runError);
  const clear = useStore(s => s.clearRunError);
  const c = useStore(s => s.config);
  const [opt, setOpt] = useState(false);

  const legsMissing = !c.legs.length && !(c.short && c.short.legs.length);
  const reason = disabledReason || (legsMissing ? 'Add at least one leg' : !c.start || !c.end ? 'Pick a date range' : '');

  return (
    <>
      <div className="sticky bottom-3 z-20 mt-6">
        {err && <div className="mb-2"><Alert onClose={clear}>Backtest failed: {err}</Alert></div>}
        <div className="card flex flex-col gap-3 p-3 shadow-lg sm:flex-row sm:items-center">
          {job ? <div className="flex-1"><JobProgress /></div> : (
            <>
              <div className="min-w-0 flex-1 text-sm">
                <div className="truncate font-semibold">{c.name || 'Untitled strategy'}</div>
                <div className="truncate text-xs text-slate-500">
                  {c.und} · {c.start || '…'} → {c.end || '…'} · {c.legs.length} leg{c.legs.length === 1 ? '' : 's'}{c.short ? ` + ${c.short.legs.length} short` : ''} · {hasSignals(c) ? `${c.timeframe}m signals` : `time entry ${c.entryTime}`}
                </div>
              </div>
              {reason && <span className="text-xs text-amber-600">{reason}</span>}
              <div className="flex gap-2">
                <button className="btn flex-1 sm:flex-none" disabled={!!reason} onClick={() => setOpt(true)}><Grid3x3 size={15} /> Optimize</button>
                <button className="btn-primary flex-1 px-5 sm:flex-none" disabled={!!reason} onClick={() => run()}><Play size={15} /> Run backtest</button>
              </div>
            </>
          )}
        </div>
      </div>
      <OptimizeDialog open={opt} onClose={() => setOpt(false)} />
    </>
  );
}
