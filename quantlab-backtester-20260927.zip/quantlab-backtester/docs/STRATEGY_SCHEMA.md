# QuantLab strategy config (canonical) + API contract

Every creation mode (Prompt, Option, Indicator, Pine, Python DSL, Marketplace) compiles to ONE
JSON config that `backend/engine.py::run_backtest(cfg)` executes on real 1-min NFO/BFO data.

## Config

```jsonc
{
  "name": "EMA cross calls",                 // optional label
  "exch": "NFO",                             // NFO | BFO
  "und": "NIFTY",                            // NIFTY BANKNIFTY FINNIFTY MIDCPNIFTY SENSEX + F&O stocks
  "start": "2025-02-01", "end": "2026-06-19",// data: 2025-01-14 .. 2026-06-19
  "capital": 1000000,
  "mode": "intraday",                        // intraday | positional
  "timeframe": 5,                            // candle minutes for indicator rules (1,3,5,10,15,30,60)
  "entryTime": "09:20",                      // time entry (no rules) or earliest signal time
  "exitTime": "15:15",                       // square-off (intraday) / expiry-day exit time (positional)
  "lastEntryTime": "14:30",                  // optional, signals only
  "weekdays": [1,2,3,4,5],                   // ISO weekday allowed to enter
  "dteMin": null, "dteMax": null,            // days-to-expiry filter on leg 1 expiry
  "maxTradesPerDay": 1,
  "reenterAfterExit": false,                 // time-based: re-enter after exit same day
  "exitDaysBeforeExpiry": 0,                 // positional
  "exitAllOnLegSl": false,
  "exitOnOpposite": false,                   // with a short side: exit when opposite signal fires
  "legs": [ LEG, ... ],                      // traded on time entry, or on the LONG signal
  "entryConds": BLOCK, "exitConds": BLOCK,   // long side (optional)
  "short": { "legs": [LEG], "entryConds": BLOCK, "exitConds": BLOCK },  // optional short side
  "overall": { "sl": 5000, "tgt": 10000, "lockAt": 3000, "lockProfit": 1000,
               "trailEvery": 1000, "trailBy": 500, "slPctCapital": 2 },   // rupees, all optional
  "costs": { "enabled": true, "brokerage": 20, "slippagePct": 0.1 },
  "meta": { "source": "prompt|option|indicator|pine|python|marketplace", "code": "..." }  // ignored by engine
}
```

### LEG
```jsonc
{ "side": "BUY|SELL", "type": "CE|PE|FUT", "lots": 1,
  "expiry": "weekly|next_weekly|far_weekly|monthly|next_monthly|far_monthly",
  "strikeMode": "atm|pct|premium|premium_gte|premium_lte|delta",
  "strikeValue": 0,          // atm: steps OTM (+) / ITM (-); pct: % OTM; premium: ₹; delta: 0-100
  "sl": 25, "slType": "pct|pts", "tgt": 50, "tgtType": "pct|pts",
  "trailX": 10, "trailY": 5, "trailType": "pct|pts",   // every X favourable move, trail SL by Y
  "reentries": 0, "reentryMode": "immediate|same_strike|cost" }
```

### BLOCK / RULE
```jsonc
BLOCK = { "logic": "AND|OR", "rules": [ RULE | BLOCK | {"not": RULE|BLOCK} ] }
RULE  = { "lhs": OPERAND, "op": ">|>=|<|<=|==|!=|crosses_above|crosses_below|crosses|is_true|is_false", "rhs": OPERAND }
```
`is_true/is_false` test lhs != 0 (rhs ignored).

### OPERAND
```jsonc
{"kind":"const","value":30}
{"kind":"ind","name":"EMA","n":20,"src":"Close","n2":0,"n3":0,"offset":0,"of":OPERAND?}
{"kind":"dt","field":"Time|Hour|Minute|WeekDay"}     // Time is HHMM int e.g. 1030
{"kind":"expr","op":"+|-|*|/|pow|max|min|neg|abs|sqrt|log","args":[OPERAND,...],"offset":0}
{"kind":"pos","field":"PnL|PnLpct|MinsInTrade"}      // EXIT rules only, top-level operand only
```
`offset: k` = value k candles ago (Pine `x[k]`). `of` = custom source series (indicator of indicator / of expr).

Indicator names (params):
- Price fields: Open High Low Close Volume HL2 HLC3 OHLC4
- `src`-able (accept `of`): SMA EMA RMA WMA HMA DEMA TEMA VWMA (n) · RSI (n) · MACD MACDSignal MACDHist (n=fast, n2=slow, n3=signal)
  · UpperBB LowerBB MidBB (n, n2=mult) · Stdev Zscore ROC Momentum (n) · Highest Lowest (n) · Change ChangePct · CCI (n)
- OHLC-based: ATR (n) · Supertrend SupertrendDir (n, n2=mult; dir +1 up / -1 down) · ADX PlusDI MinusDI (n, n2=adx smoothing)
  · StochK (n, n2=smoothK) StochD (n, n2=smoothK, n3=smoothD) · WilliamsR (n) · OBV · VWAP (session)
  · VIX (India VIX level at candle close) · HighestHigh LowestLow (n) · DayOpen DayHigh DayLow PrevDayHigh PrevDayLow PrevDayClose · ORHigh ORLow (n = # opening candles)

Signal semantics: rules evaluated on candle close of the underlying (index spot / stock cash);
fill at the next minute's option/future price. Long side checked before short side.

## HTTP API (FastAPI, port 8765)

| Method | Path | Body / Query | Returns |
|---|---|---|---|
| GET | /api/meta | | `{underlyings:[{exch,und,from,to,index,futures}], calendar:[first,last], index_map}` |
| POST | /api/strategy/compile | `{source:"prompt"|"pine"|"python", code:string, defaults:DEFAULTS}` | `{config, notes:[str], warnings:[str]}` (400 `{detail}` on error) |
| GET | /api/marketplace | | `[{id,name,category,description,tags:[],risk:"Low|Medium|High",style,config,stats?}]` |
| POST | /api/jobs | `{config}` | `{id}` |
| POST | /api/jobs/optimize | `{config, params:[{path:"legs.0.sl", values:[20,30,40]}], metric:"netPnl"}` (≤2 params, ≤36 combos) | `{id}` |
| GET | /api/jobs/{id} | | `{id,kind,status:"queued|running|done|error|cancelled",progress:0..1,message,result?,error?}` |
| DELETE | /api/jobs/{id} | | cancel |
| POST | /api/backtest | config | result (sync, legacy) |
| GET/POST | /api/strategies | POST `{name, config}` | list `[{id,name,source,und,updated,config}]` / saved |
| DELETE | /api/strategies/{id} | | |
| GET | /api/chain | exch,und,date,time,expiry? | option chain |

DEFAULTS (used by compilers for anything the source doesn't specify):
`{exch,und,start,end,capital,timeframe,instrument:"atm_options"|"futures"|"sell_options", lots, expiry}`
- `atm_options`: long → BUY ATM CE, short → BUY ATM PE
- `sell_options`: long → SELL ATM PE, short → SELL ATM CE
- `futures`: long → BUY FUT, short → SELL FUT

Backtest result: `{stats, equity:[{date,equity,dd}], daily, monthly, weekday, byDte, exitReasons, trades:[{id,side,entryDate,entryTime,exitDate,exitTime,spotIn,exitReason,gross,charges,net,mae,mfe,premium,legs:[...]}], skipped, warnings, spotSource, benchmark:[{date,equity}], montecarlo:{runs, maxDD:{p5,p50,p95}, finalEquity:{p5,p50,p95}, probLoss, bands:[{i,p5,p50,p95}]}, elapsed, config}`
Optimize result: `{metric, params, grid:[{values:[..], stats}], best:{values, stats}}`
