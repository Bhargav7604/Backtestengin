"""Tests for the QuantLab Python DSL compiler.

Run: cd backend && PYTHONPATH=. ../.venv/bin/python strategy/test_pydsl.py
"""
import json
import time

import engine
from strategy.pydsl import compile_python, EXAMPLE, DSL_REFERENCE

DEFAULTS = {"exch": "NFO", "und": "NIFTY", "start": "2025-06-01", "end": "2026-06-19", "capital": 1_000_000,
            "timeframe": 5, "lots": 1, "expiry": "weekly", "instrument": "atm_options"}
WEEK = {"start": "2026-03-02", "end": "2026-03-06"}


def compile_ok(code, defaults=DEFAULTS):
    out = compile_python(code, defaults)
    assert set(out) == {"config", "notes", "warnings"}, out.keys()
    cfg = out["config"]
    json.dumps(cfg, allow_nan=False)
    assert cfg["meta"] == {"source": "python", "code": code}
    engine.Backtest({**cfg, **WEEK})  # compiles every condition against real candles
    return out


def expect_error(code, *fragments):
    try:
        compile_python(code, DEFAULTS)
    except ValueError as e:
        msg = str(e)
        assert msg.startswith("line "), msg
        for f in fragments:
            assert f in msg, f"{f!r} not in {msg!r}"
        return msg
    raise AssertionError(f"expected an error for:\n{code}")


def find_rules(block, out=None):
    out = [] if out is None else out
    if "rules" in block:
        for r in block["rules"]:
            find_rules(r, out)
    elif "not" in block:
        find_rules(block["not"], out)
    else:
        out.append(block)
    return out


# ------------------------------------------------------------------------------------------ cases

def test_example():
    out = compile_ok(EXAMPLE)
    c = out["config"]
    assert c["und"] == "NIFTY" and c["timeframe"] == 5 and c["entryTime"] == "09:30"
    assert c["lastEntryTime"] == "14:30" and c["maxTradesPerDay"] == 3 and c["dteMin"] == 0 and c["dteMax"] == 7
    assert c["exitOnOpposite"] is True
    assert c["legs"][0]["type"] == "CE" and c["legs"][0]["trailX"] == 10 and c["legs"][0]["trailType"] == "pct"
    assert c["short"]["legs"][0]["type"] == "PE"
    ops = [r["op"] for r in find_rules(c["entryConds"])]
    assert ops == ["crosses_above", ">", ">", ">"], ops
    ex = find_rules(c["exitConds"])
    assert c["exitConds"]["logic"] == "OR" and {"kind": "pos", "field": "MinsInTrade"} in [r["lhs"] for r in ex]
    # ~trend_up on the short side
    assert any("not" in r for r in c["short"]["entryConds"]["rules"])
    assert c["overall"] == {"sl": 5000, "tgt": 10000, "lockAt": 3000, "lockProfit": 1000}
    assert c["costs"] == {"enabled": True, "brokerage": 20, "slippagePct": 0.1}
    return out


STRADDLE = '''from quantlab import *
strategy("Short straddle 09:20", underlying="NIFTY", timeframe=1, entry_time="09:20", exit_time="15:15")
leg(SELL, CE, strike=ATM, expiry=WEEKLY, lots=1, sl=pct(30))
leg(SELL, PE, strike=ATM, expiry=WEEKLY, lots=1, sl=pct(30), reentries=1, reentry="cost")
overall(stop_loss=6000, target=8000)
'''


def test_straddle():
    out = compile_ok(STRADDLE)
    c = out["config"]
    assert "entryConds" not in c and "short" not in c
    assert c["maxTradesPerDay"] == 1 and len(c["legs"]) == 2
    assert c["legs"][1]["reentries"] == 1 and c["legs"][1]["reentryMode"] == "cost"
    assert any("time-based" in n for n in out["notes"])
    return out


ORB = '''from quantlab import *
strategy("ORB 15m", underlying="BANKNIFTY", timeframe=5, entry_time="09:30", last_entry_time="13:00",
         max_trades_per_day=1)
orh, orl = or_high(3), or_low(3)
morning = time_of_day() < "13:00"
long_when(crossover(close, orh) & morning & (volume >= 0))
short_when(crossunder(close, orl) & morning)
long_exit_when(close < (orh + orl) / 2)
short_exit_when(close > (orh + orl) / 2)
'''


def test_orb():
    out = compile_ok(ORB)
    c = out["config"]
    assert c["und"] == "BANKNIFTY"
    # no legs given -> derived from atm_options defaults
    assert c["legs"][0]["side"] == "BUY" and c["legs"][0]["type"] == "CE"
    assert c["short"]["legs"][0]["side"] == "BUY" and c["short"]["legs"][0]["type"] == "PE"
    r = c["entryConds"]["rules"][1]
    assert r["lhs"] == {"kind": "dt", "field": "Time"} and r["rhs"] == {"kind": "const", "value": 1300}
    x = c["exitConds"]["rules"][0]["rhs"]
    assert x["kind"] == "expr" and x["op"] == "/"


SUPERTREND = '''from quantlab import *
strategy("Supertrend futures", underlying="NIFTY", timeframe=15, mode="positional", exit_time="15:15")
st = supertrend(10, 3)
long_when((st.direction > 0) & (st.direction[1] < 0) & (close > ema(close, 50)))
short_when((st.direction < 0) & (st.direction[1] > 0))
exit_on_opposite()
leg(BUY, FUT, lots=1)
short_leg(SELL, FUT, lots=1)
overall(stop_loss=15000)
'''


def test_supertrend_futures():
    out = compile_ok(SUPERTREND, {**DEFAULTS, "instrument": "futures"})
    c = out["config"]
    assert c["mode"] == "positional" and c["legs"][0]["type"] == "FUT" and c["legs"][0]["expiry"] == "monthly"
    assert c["short"]["legs"][0]["side"] == "SELL"
    prev = c["entryConds"]["rules"][1]["lhs"]
    assert prev["name"] == "SupertrendDir" and prev["offset"] == 1 and prev["n2"] == 3


MACD_BB = '''from quantlab import *
strategy("MACD + BB", timeframe=10)
m = macd(close, 12, 26, 9)
bb = bbands(hlc3, 20, 2.5)
sq = (bb.upper - bb.lower) / bb.mid * 100
long_when(crossover(m.line, m.signal) & (m.hist > 0) & (close > bb.mid) & (sq < 3))
long_exit_when((close > bb.upper) | crossunder(m.line, m.signal) | (pnl_pct() > 40))
short_when(crossunder(m, m.signal) & (close < bb.lower) & (ema(rsi(close, 14), 5) < 45) &
           (stoch(14, 3, 3).k < 30) & (abs(zscore(close, 20)) > 1) & (max_(atr(14), 1) > sqrt(4)))
'''


def test_macd_bb():
    out = compile_ok(MACD_BB, {**DEFAULTS, "instrument": "sell_options"})
    c = out["config"]
    r = find_rules(c["entryConds"])
    assert r[0]["lhs"]["name"] == "MACD" and r[0]["rhs"]["name"] == "MACDSignal" and r[0]["rhs"]["n3"] == 9
    assert r[2]["rhs"] == {"kind": "ind", "name": "MidBB", "n": 20, "src": "HLC3", "n2": 2.5, "n3": 0, "offset": 0}
    # sell_options: long -> SELL PE, short -> SELL CE
    assert c["legs"][0]["side"] == "SELL" and c["legs"][0]["type"] == "PE"
    assert c["short"]["legs"][0]["type"] == "CE"
    ema_of_rsi = find_rules(c["short"]["entryConds"])[2]["lhs"]
    assert ema_of_rsi["name"] == "EMA" and ema_of_rsi["of"]["name"] == "RSI"
    assert c["maxTradesPerDay"] == 5


def test_no_strategy_call_uses_defaults():
    out = compile_ok("long_when(rsi(14) > 70)\n", {**DEFAULTS, "und": "FINNIFTY", "timeframe": 3})
    c = out["config"]
    assert c["und"] == "FINNIFTY" and c["timeframe"] == 3 and c["start"] == "2025-06-01"
    assert c["entryConds"]["rules"][0]["lhs"]["name"] == "RSI"


def test_misc_semantics():
    out = compile_python("x = close[2] + 2 * 3\nlong_when((x > open) & ~(hour() == 9) & (time_of_day()[1] > 930))\n",
                         DEFAULTS)
    r = find_rules(out["config"]["entryConds"])
    assert r[0]["lhs"]["args"][0]["offset"] == 2 and r[0]["lhs"]["args"][1] == {"kind": "const", "value": 6}
    assert r[2]["lhs"]["kind"] == "expr" and r[2]["lhs"]["offset"] == 1  # dt offset wrapped
    engine.Backtest({**out["config"], **WEEK})


def test_errors():
    expect_error("long_when(pnl() > 100)\n", "only allowed in exit")
    expect_error("x = 1\nlong_when((close > 1) and (close < 2))\n", "line 2", "&")
    expect_error("long_when(not (close > 1))\n", "~")
    expect_error("long_when(close > 1 & close < 2)\n", "chained")
    expect_error("long_when(rsi(14) > 50 & (close > 1))\n", "parentheses")
    expect_error("if close > 1:\n    pass\n", "if")
    expect_error("long_when(close > 1)\nlong_when(close > 2)\n", "line 2", "already")
    expect_error("long_when(foo(close) > 1)\n", "unknown name 'foo'")
    expect_error("\n\nlong_when(ema(close) > 1)\n", "line 3", "length")
    expect_error("long_when(macd(close).upper > 1)\n", "no attribute")
    expect_error("strategy(timeframe=7)\n", "timeframe")
    expect_error("leg(BUY, 'XX')\n", "type")
    expect_error("", "nothing to trade")
    expect_error("long_when(close[1:2] > 1)\n", "slice")
    expect_error("long_when(pnl() + 1 > 5)\n", "arithmetic")
    expect_error("long_when(close > 1)\nlong_exit_when(pnl() > 10)\nexit_on_opposite()\nshort_leg(BUY, PE)\n"
                 "leg(BUY, CE, sl='x')\n", "line 5", "pct")


SECURITY = [
    "__import__('os')",
    "x = __import__('os').system('echo pwned')",
    "().__class__.__bases__",
    "x = ().__class__.__bases__[0].__subclasses__()",
    "x = close.__class__",
    "x = close._op",
    "x = ema.__globals__",
    "x = close.shift.__self__",
    "x = ema.func_globals",
    "x = strategy.__code__",
    "x = open('x')",
    "x = open('/etc/passwd').read()",
    "exec('import os')",
    "eval('1+1')",
    "compile('1', 'x', 'exec')",
    "getattr(close, '_op')",
    "import os",
    "from os import system",
    "from quantlab import ema as __x",
    "def f():\n    pass",
    "class A:\n    pass",
    "f = lambda: 1",
    "for i in [1, 2]:\n    pass",
    "while True:\n    pass",
    "x = [i for i in (1, 2)]",
    "x = {'a': 1}",
    "with open('x') as f:\n    pass",
    "x = f'{close}'",
    "x = 9 ** 9 ** 9 ** 9",
    "x = 'a' * 10 ** 8",
    "x = [1] * 10 ** 8",
    "x = 1 << 100000",
    "globals()",
    "x = vars()",
    "x = type(close)",
    "x = close.mro",
    "x = (1).real",
    "x = 'abc'.format",
    "x = close[x]",
    "x = __builtins__",
    "strategy(**{'name': 'x'})",
    "x = (-(-(-(-(-(-(-(-(-(-(-(-(-(-(-(-(-(-(-(-(-(-(close)))))))))))))))))))))))",
    "x = " + "+".join(["close"] * 500),
    "x = close\n" + "x = x + x\n" * 40 + "long_when(x > 1)",
    "a = close\n" + "a = -a\n" * 100 + "long_when(a > 1)",
    "x = 'y' * 50000",
    "try:\n    pass\nexcept Exception:\n    pass",
    "global x",
    "x: int = 1",
    "x += 1",
    "del close",
    "assert 1",
    "raise ValueError()",
    "x = (yield)",
    "print(1)",
]


def test_security():
    for code in SECURITY:
        try:
            compile_python(code, DEFAULTS)
        except ValueError as e:
            assert str(e).startswith("line "), (code, e)
            continue
        raise AssertionError(f"security case compiled: {code!r}")
    # huge script
    expect_error("x = 1\n" * 5000, "too long")


def test_reference():
    assert "long_when" in DSL_REFERENCE and "crossover" in DSL_REFERENCE and len(DSL_REFERENCE) < 8000


def run_week(out, label):
    t = time.time()
    res = engine.run_backtest({**out["config"], **WEEK})
    n = len(res["trades"])
    print(f"  {label}: {n} trades, net {res['stats'].get('netPnl', res['stats'])}, {time.time() - t:.1f}s")
    assert n > 0, f"{label}: no trades"


if __name__ == "__main__":
    t0 = time.time()
    tests = [(k, v) for k, v in list(globals().items()) if k.startswith("test_") and callable(v)]
    outs = {}
    for name, fn in tests:
        t = time.time()
        outs[name] = fn()
        print(f"ok  {name} ({time.time() - t:.1f}s)")
    print("full 1-week backtests (NIFTY 2026-03-02..06):")
    run_week(outs["test_example"], "EXAMPLE")
    run_week(outs["test_straddle"], "short straddle")
    print(f"all {len(tests)} tests passed in {time.time() - t0:.1f}s")
