"""Plain-English prompt -> QuantLab strategy config.

Two paths:
  1. Claude (if the `anthropic` package is installed and credentials resolve): the model is given the
     schema and returns config JSON, which is then validated by the engine.
  2. Deterministic rule parser (always available, used as fallback): recognises common Indian F&O
     structures (straddle, strangle, iron condor, spreads, futures), strike selection, SL/target/trail,
     timings, weekdays, DTE, re-entries, overall MTM limits and indicator entry/exit rules.
"""
from __future__ import annotations

import copy
import json
import os
import re

SCHEMA_DOC = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
                          "docs", "STRATEGY_SCHEMA.md")

UND_ALIASES = [
    (r"\b(bank\s*nifty|banknifty|bnf|nifty\s*bank)\b", "NIFTY BANK"),
    (r"\b(fin\s*nifty|finnifty)\b", "FINNIFTY"),
    (r"\b(midcp\s*nifty|midcap\s*nifty|midcpnifty|midcap)\b", "MIDCPNIFTY"),
    (r"\bsensex\b", "SENSEX"),
    (r"\bnifty\b", "NIFTY"),
]
WEEKDAYS = {"monday": 1, "mon": 1, "tuesday": 2, "tue": 2, "wednesday": 3, "wed": 3,
            "thursday": 4, "thu": 4, "friday": 5, "fri": 5}


def leg(side="SELL", typ="CE", **kw):
    base = {"side": side, "type": typ, "lots": 1, "expiry": "weekly", "strikeMode": "atm", "strikeValue": 0,
            "sl": 0, "slType": "pct", "tgt": 0, "tgtType": "pct", "trailX": 0, "trailY": 0, "trailType": "pct",
            "reentries": 0, "reentryMode": "immediate"}
    base.update(kw)
    return base


def base_config(defaults: dict) -> dict:
    d = defaults or {}
    return {
        "name": "Prompt strategy",
        "exch": d.get("exch", "NFO"), "und": d.get("und", "NIFTY"),
        "start": d.get("start", "2025-06-01"), "end": d.get("end", "2026-06-19"),
        "capital": d.get("capital", 1_000_000), "mode": "intraday", "timeframe": int(d.get("timeframe", 5)),
        "entryTime": "09:20", "exitTime": "15:15", "weekdays": [1, 2, 3, 4, 5],
        "maxTradesPerDay": 1, "legs": [], "overall": {},
        "costs": {"enabled": True, "brokerage": 20, "slippagePct": 0.1},
    }


# ----------------------------------------------------------------------------- rule parser

NUM = r"(\d+(?:\.\d+)?)"


def _time(s: str):
    """'9:20', '9.20', '09:20 am', '3:15 pm', '1515' -> 'HH:MM'"""
    m = re.match(r"(\d{1,2})[:.](\d{2})\s*(am|pm)?", s) or re.match(r"(\d{2})(\d{2})()", s)
    if not m:
        return None
    h, mi, ap = int(m.group(1)), int(m.group(2)), (m.group(3) or "")
    if ap == "pm" and h < 12:
        h += 12
    if not ap and h < 8:  # "3:15" in a trading context = 15:15
        h += 12
    if not (9 <= h <= 15):
        return None
    return f"{h:02d}:{mi:02d}"


IND_PATTERNS = [
    # (regex, builder(match) -> operand)
    (rf"(?:{NUM}\s*(?:period\s*)?(ema|sma|wma|hma|vwma)|(ema|sma|wma|hma|vwma)\s*\(?\s*{NUM}\)?)",
     lambda m: {"kind": "ind", "name": (m.group(2) or m.group(3)).upper(), "n": int(float(m.group(1) or m.group(4)))}),
    (rf"rsi\s*\(?\s*(\d+)?\)?", lambda m: {"kind": "ind", "name": "RSI", "n": int(m.group(1) or 14)}),
    (r"vwap", lambda m: {"kind": "ind", "name": "VWAP"}),
    (r"(?:india\s*)?vix", lambda m: {"kind": "ind", "name": "VIX"}),
    (r"supertrend", lambda m: {"kind": "ind", "name": "Supertrend", "n": 10, "n2": 3}),
    (r"adx\s*\(?\s*(\d+)?\)?", lambda m: {"kind": "ind", "name": "ADX", "n": int(m.group(1) or 14)}),
    (r"cci\s*\(?\s*(\d+)?\)?", lambda m: {"kind": "ind", "name": "CCI", "n": int(m.group(1) or 20)}),
    (r"macd\s+signal", lambda m: {"kind": "ind", "name": "MACDSignal", "n": 12, "n2": 26, "n3": 9}),
    (r"macd", lambda m: {"kind": "ind", "name": "MACD", "n": 12, "n2": 26, "n3": 9}),
    (r"upper\s*(?:bollinger|bb)(?:\s*band)?", lambda m: {"kind": "ind", "name": "UpperBB", "n": 20, "n2": 2}),
    (r"lower\s*(?:bollinger|bb)(?:\s*band)?", lambda m: {"kind": "ind", "name": "LowerBB", "n": 20, "n2": 2}),
    (r"previous\s*day'?s?\s*high|prev(?:ious)?\s*day\s*high|pdh", lambda m: {"kind": "ind", "name": "PrevDayHigh"}),
    (r"previous\s*day'?s?\s*low|prev(?:ious)?\s*day\s*low|pdl", lambda m: {"kind": "ind", "name": "PrevDayLow"}),
    (r"opening\s*range\s*high|or\s*high", lambda m: {"kind": "ind", "name": "ORHigh", "n": 3}),
    (r"opening\s*range\s*low|or\s*low", lambda m: {"kind": "ind", "name": "ORLow", "n": 3}),
    (r"day\s*high", lambda m: {"kind": "ind", "name": "DayHigh"}),
    (r"day\s*low", lambda m: {"kind": "ind", "name": "DayLow"}),
    (rf"{NUM}", lambda m: {"kind": "const", "value": float(m.group(1))}),
    (r"(?:price|close|spot|the\s+index|it)", lambda m: {"kind": "ind", "name": "Close"}),
]
OPS = [
    (r"crosses?\s+above|cross(?:es)?\s+over|breaks?\s+above|crosses?\s+up", "crosses_above"),
    (r"crosses?\s+below|cross(?:es)?\s+under|breaks?\s+below|crosses?\s+down", "crosses_below"),
    (r"(?:is\s+)?(?:>=|at\s+least)", ">="), (r"(?:is\s+)?(?:<=|at\s+most)", "<="),
    (r"(?:is\s+)?(?:>|above|greater\s+than|over|more\s+than)", ">"),
    (r"(?:is\s+)?(?:<|below|less\s+than|under)", "<"),
]


def _operand(s: str):
    s = s.strip().strip(",.;")
    for pat, fn in IND_PATTERNS:
        m = re.fullmatch(r"(?:the\s+)?" + pat + r"(?:\s+line)?", s)
        if m:
            return fn(m)
    return None


def _parse_clause(txt: str):
    """'9 ema crosses above 21 ema' -> RULE or None"""
    t = txt.strip()
    st = re.search(r"supertrend(?:_(\d+)_(\d+(?:\.\d+)?))?", t)
    st_op = {"kind": "ind", "name": "SupertrendDir", "n": int(st.group(1)) if st and st.group(1) else 10,
             "n2": float(st.group(2)) if st and st.group(2) else 3}
    if re.search(r"supertrend(?:_[\d_.]+)?\s+(?:turns?\s+|is\s+|becomes\s+)?(?:green|bullish|up|buy)", t):
        return {"lhs": st_op, "op": "crosses_above", "rhs": {"kind": "const", "value": 0}}
    if re.search(r"supertrend(?:_[\d_.]+)?\s+(?:turns?\s+|is\s+|becomes\s+)?(?:red|bearish|down|sell)", t):
        return {"lhs": st_op, "op": "crosses_below", "rhs": {"kind": "const", "value": 0}}
    for pat, op in OPS:
        m = re.search(r"\s" + pat + r"\s", " " + t + " ")
        if m:
            lhs_s = (" " + t + " ")[: m.start()].strip()
            rhs_s = (" " + t + " ")[m.end():].strip()
            lhs, rhs = _operand(lhs_s), _operand(rhs_s)
            if lhs and rhs:
                return {"lhs": lhs, "op": op, "rhs": rhs}
    return None


def _parse_conditions(txt: str, notes: list):
    """Split on and/or and parse each clause. Returns BLOCK or None."""
    parts = re.split(r"\s+(and|or)\s+", txt)
    rules, logic = [], "AND"
    for p in parts:
        if p in ("and", "or"):
            if p == "or":
                logic = "OR"
            continue
        r = _parse_clause(p)
        if r:
            rules.append(r)
        elif p.strip():
            notes.append(f"Could not understand condition: “{p.strip()}”")
    return {"logic": logic, "rules": rules} if rules else None


def _strike(txt: str):
    """Return (strikeMode, strikeValue) from a phrase near a leg."""
    m = re.search(rf"{NUM}\s*delta|delta\s*(?:of\s*)?{NUM}", txt)
    if m:
        v = float(m.group(1) or m.group(2))
        return "delta", v * 100 if v < 1 else v
    m = re.search(rf"premium\s*(?:of|near|around|~|=)?\s*(?:rs\.?|₹)?\s*{NUM}|(?:rs\.?|₹)\s*{NUM}\s*premium|{NUM}\s*(?:rs|₹)?\s*premium", txt)
    if m:
        return "premium", float(next(g for g in m.groups() if g))
    m = re.search(rf"{NUM}\s*%\s*otm", txt)
    if m:
        return "pct", float(m.group(1))
    m = re.search(r"(\d+)\s*(?:strikes?|steps?)\s*(otm|itm|away|out)", txt)
    if m:
        v = int(m.group(1))
        return "atm", -v if m.group(2) == "itm" else v
    m = re.search(r"\b(otm|itm)\s*(\d+)\b", txt)
    if m:
        v = int(m.group(2))
        return "atm", -v if m.group(1) == "itm" else v
    if re.search(r"\botm\b", txt):
        return "atm", 1
    if re.search(r"\bitm\b", txt):
        return "atm", -1
    return "atm", 0


def rule_parse(text: str, defaults: dict, known_unds=()) -> dict:
    notes, warnings = [], []
    t = " " + re.sub(r"\s+", " ", text.lower().replace("’", "'")) + " "
    cfg = base_config(defaults)

    # underlying
    und = None
    for pat, name in UND_ALIASES:
        if re.search(pat, t):
            und = "BANKNIFTY" if name == "NIFTY BANK" else name
            break
    if not und:
        for u in known_unds:
            if re.search(r"\b" + re.escape(u.lower()) + r"\b", t):
                und = u
                break
    if und:
        cfg["und"] = und
    cfg["exch"] = "BFO" if cfg["und"] in ("SENSEX", "BANKEX", "SENSEX50") else "NFO"

    # expiry
    expiry = "weekly"
    if re.search(r"next\s*week", t):
        expiry = "next_weekly"
    elif re.search(r"next\s*month", t):
        expiry = "next_monthly"
    elif re.search(r"month(ly)?\s*expiry|monthly", t):
        expiry = "monthly"
    if cfg["und"] not in ("NIFTY", "SENSEX") and expiry == "weekly":
        expiry = "monthly"
        notes.append(f"{cfg['und']} has monthly expiries only — using monthly.")

    # lots
    m = re.search(r"(\d+)\s*lots?", t)
    lots = int(m.group(1)) if m else int((defaults or {}).get("lots", 1))

    # risk per leg
    sl = tgt = None
    t_leg = re.sub(r"(?:overall|mtm|max(?:imum)?|daily|total|portfolio)\s*(?:sl|stop\s*-?\s*loss|target|tgt|loss|profit)\s*(?:of\s*)?(?:rs\.?|₹)?\s*\d+(?:\.\d+)?\s*k?", " ", t)

    def risk(keys):
        m = re.search(rf"(?:{keys})\s*(?:of\s*|at\s*|=\s*)?{NUM}\s*(%|percent|points?|pts?)?", t_leg) or \
            re.search(rf"{NUM}\s*(%|percent|points?|pts?)?\s*(?:{keys})", t_leg)
        if not m:
            return None
        unit = m.group(2) or "%"
        return float(m.group(1)), "pct" if unit in ("%", "percent") else "pts"
    sl = risk(r"\bsl\b|stop\s*-?\s*loss|stoploss")
    tgt = risk(r"target|\btgt\b|\btp\b|take\s*profit")
    trail = None
    m = re.search(rf"trail(?:ing)?\s*(?:sl|stop)?\s*(?:by\s*)?{NUM}\s*%?\s*(?:/|and|every)\s*{NUM}", t)
    if m:
        trail = (float(m.group(1)), float(m.group(2)))
    reentries = 0
    m = re.search(r"re-?\s*enter(?:y|ies)?\s*(?:up\s*to\s*)?(\d+)|(\d+)\s*re-?\s*entr", t)
    if m:
        reentries = int(m.group(1) or m.group(2))
    elif re.search(r"re-?\s*ent(er|ry)", t):
        reentries = 1
    reentry_mode = "cost" if re.search(r"(re-?\s*ent\w*.*(at|on)\s*cost|cost\s*re-?\s*ent)", t) else "immediate"

    # structure
    strike_mode, strike_val = _strike(t)
    hedge = re.search(r"(?:hedges?|wings?|protection)\s*(?:at\s*)?(\d+)\s*(?:strikes?|steps?)?|(\d+)\s*(?:strikes?|steps?)\s*(?:otm\s*)?(?:hedges?|wings?)", t)
    hedge_n = int(hedge.group(1) or hedge.group(2)) if hedge else None
    side_sell = bool(re.search(r"\b(sell|short|write|writing)\b", t))
    side_buy = bool(re.search(r"\b(buy|long|purchase)\b", t))
    legs = []

    def L(side, typ, mode=None, val=None, **kw):
        return leg(side, typ, lots=lots, expiry=expiry,
                   strikeMode=mode or strike_mode, strikeValue=strike_val if val is None else val, **kw)

    if "iron condor" in t or re.search(r"\bic\b", t):
        s = strike_val if strike_mode == "atm" and strike_val else 3
        h = hedge_n or s + 5
        legs = [L("SELL", "CE", "atm", s), L("SELL", "PE", "atm", s), L("BUY", "CE", "atm", h), L("BUY", "PE", "atm", h)]
    elif re.search(r"iron\s*f?l?y|iron\s*butterfly", t):
        h = hedge_n or 5
        legs = [L("SELL", "CE", "atm", 0), L("SELL", "PE", "atm", 0), L("BUY", "CE", "atm", h), L("BUY", "PE", "atm", h)]
    elif "strangle" in t:
        side = "BUY" if side_buy and not side_sell else "SELL"
        v = strike_val if strike_val else (2 if strike_mode == "atm" else strike_val)
        legs = [L(side, "CE", val=v), L(side, "PE", val=v)]
        if hedge_n and side == "SELL":
            legs += [L("BUY", "CE", "atm", hedge_n), L("BUY", "PE", "atm", hedge_n)]
    elif "straddle" in t:
        side = "BUY" if side_buy and not side_sell else "SELL"
        legs = [L(side, "CE", "atm", 0), L(side, "PE", "atm", 0)]
        if hedge_n and side == "SELL":
            legs += [L("BUY", "CE", "atm", hedge_n), L("BUY", "PE", "atm", hedge_n)]
    elif re.search(r"bull\s*call", t):
        legs = [L("BUY", "CE", "atm", 0), L("SELL", "CE", "atm", hedge_n or 3)]
    elif re.search(r"bear\s*put", t):
        legs = [L("BUY", "PE", "atm", 0), L("SELL", "PE", "atm", hedge_n or 3)]
    elif re.search(r"bull\s*put", t):
        legs = [L("SELL", "PE", "atm", 0), L("BUY", "PE", "atm", hedge_n or 3)]
    elif re.search(r"bear\s*call", t):
        legs = [L("SELL", "CE", "atm", 0), L("BUY", "CE", "atm", hedge_n or 3)]
    elif re.search(r"\bfutures?\b|\bfut\b", t):
        legs = [leg("SELL" if side_sell and not side_buy else "BUY", "FUT", lots=lots, expiry="monthly")]
    else:
        ce = re.search(r"\b(call|ce)s?\b", t)
        pe = re.search(r"\b(put|pe)s?\b", t)
        side = "SELL" if side_sell and not side_buy else "BUY"
        if ce:
            legs.append(L(side, "CE"))
        if pe:
            legs.append(L(side, "PE"))
    if not legs:
        legs = [L("SELL", "CE", "atm", 0), L("SELL", "PE", "atm", 0)]
        warnings.append("No option structure recognised — defaulted to an ATM short straddle.")

    for lg in legs:
        is_hedge = lg["side"] == "BUY" and any(x["side"] == "SELL" for x in legs)
        if sl and not is_hedge:
            lg["sl"], lg["slType"] = sl
        if tgt and not is_hedge:
            lg["tgt"], lg["tgtType"] = tgt
        if trail and not is_hedge:
            lg["trailX"], lg["trailY"] = trail
        if reentries and not is_hedge:
            lg["reentries"], lg["reentryMode"] = reentries, reentry_mode
    cfg["legs"] = legs
    if trail and not sl:
        warnings.append("Trailing SL needs a stop-loss — add e.g. “SL 30%”; trail ignored.")

    # timing
    m = re.search(r"(?:at|enter\w*\s*(?:at)?|entry\s*(?:at|time)?|from)\s*(\d{1,2}[:.]\d{2}\s*(?:am|pm)?)", t)
    if m and _time(m.group(1)):
        cfg["entryTime"] = _time(m.group(1))
    m = re.search(r"(?:exit|square\s*-?\s*off|close)\w*\s*(?:all\s*)?(?:at|by)?\s*(\d{1,2}[:.]\d{2}\s*(?:am|pm)?)", t)
    if m and _time(m.group(1)):
        cfg["exitTime"] = _time(m.group(1))
    m = re.search(r"(?:no\s*(?:new\s*)?entr\w*\s*after|last\s*entry\s*(?:at|by)?)\s*(\d{1,2}[:.]\d{2}\s*(?:am|pm)?)", t)
    if m and _time(m.group(1)):
        cfg["lastEntryTime"] = _time(m.group(1))
    days = [v for k, v in WEEKDAYS.items() if re.search(r"\b" + k + r"s?\b", t)]
    if days:
        cfg["weekdays"] = sorted(set(days))
    if re.search(r"expiry\s*day|0\s*dte|zero\s*dte", t):
        cfg["dteMin"], cfg["dteMax"] = 0, 0
    m = re.search(r"(\d+)\s*dte", t)
    if m and not re.search(r"0\s*dte", t):
        cfg["dteMin"] = cfg["dteMax"] = int(m.group(1))
    if re.search(r"positional|overnight|carry|hold\s*(till|until)\s*expiry|btst", t):
        cfg["mode"] = "positional"
        if cfg["exitTime"] == "15:15":
            cfg["exitTime"] = "15:00"
    m = re.search(r"(\d+)\s*(?:-|\s)?\s*min(?:ute)?s?\s*(?:candle|chart|tf|timeframe)?", t)
    if m and int(m.group(1)) in (1, 3, 5, 10, 15, 30, 60):
        cfg["timeframe"] = int(m.group(1))

    # overall MTM
    ov = {}
    m = re.search(rf"(?:max(?:imum)?\s*loss|overall\s*(?:sl|stop\s*loss)|mtm\s*(?:sl|stop\s*loss)|daily\s*loss)\s*(?:of\s*)?(?:rs\.?|₹)?\s*{NUM}\s*(k)?", t)
    if m:
        ov["sl"] = float(m.group(1)) * (1000 if m.group(2) else 1)
    m = re.search(rf"(?:overall\s*target|mtm\s*target|max(?:imum)?\s*profit|daily\s*target)\s*(?:of\s*)?(?:rs\.?|₹)?\s*{NUM}\s*(k)?", t)
    if m:
        ov["tgt"] = float(m.group(1)) * (1000 if m.group(2) else 1)
    cfg["overall"] = ov
    if re.search(r"exit\s*all\s*(?:legs\s*)?(?:if|when|on)\s*(?:any\s*)?(?:one\s*)?leg\s*(?:hits\s*)?sl", t):
        cfg["exitAllOnLegSl"] = True

    # indicator signals
    t = re.sub(r"super\s*trend\s*\(?\s*(\d+)\s*[,/x]\s*(\d+(?:\.\d+)?)\s*\)?", r"supertrend_\1_\2 ", t)
    # timeframe phrases ("on 5 min", "5-minute chart") are parsed above; drop them so they don't split conditions
    t = re.sub(r"\s(?:on|using|in)\s+(?:the\s+)?\d+\s*-?\s*min(?:ute)?s?(?:\s*(?:candles?|charts?|tf|timeframe))?", " ", t)
    m = re.search(r"\b(?:when|if|once|after)\s+(.+?)(?=\s+(?:with|sl\b|stop|target|exit\b|square|,|;|\.\s|every|and\s+exit)|\s*$)", t)
    if m:
        blk = _parse_conditions(m.group(1), notes)
        if blk:
            cfg["entryConds"] = blk
            cfg["maxTradesPerDay"] = 3
            notes.append(f"Entry signal: {len(blk['rules'])} rule(s) on {cfg['timeframe']}-min candles.")
    m = re.search(r"exit\s+(?:when|if|once)\s+(.+?)(?=\s+(?:with|sl\b|stop|target|,|;|\.\s)|\s*$)", t)
    if m:
        blk = _parse_conditions(m.group(1), notes)
        if blk:
            cfg["exitConds"] = blk
    if re.search(r"\borb\b|opening\s*range\s*breakout", t) and "entryConds" not in cfg:
        n = max(1, 15 // cfg["timeframe"])
        cfg["entryConds"] = {"logic": "AND", "rules": [{"lhs": {"kind": "ind", "name": "Close"}, "op": "crosses_above",
                                                          "rhs": {"kind": "ind", "name": "ORHigh", "n": n}}]}
        cfg["entryTime"] = "09:30"
        notes.append("Opening-range breakout: long when close crosses above the first 15-min high.")

    # name
    kind = next((k for k in ("iron condor", "iron fly", "strangle", "straddle", "bull call", "bear put", "bull put",
                             "bear call", "futures") if k in t), None)
    cfg["name"] = f"{cfg['und']} {kind.title() if kind else 'custom'}" + (" (signal)" if cfg.get("entryConds") else f" @ {cfg['entryTime']}")
    notes.insert(0, f"{len(legs)} leg(s) on {cfg['und']} ({cfg['exch']}), {legs[0]['expiry'].replace('_', ' ')} expiry, "
                    f"{'positional' if cfg['mode'] == 'positional' else 'intraday'}.")
    return {"config": cfg, "notes": notes, "warnings": warnings, "engine": "rules"}


# ----------------------------------------------------------------------------- Claude path

SYSTEM = """You convert a trader's plain-English description of an Indian F&O options/futures strategy into a
QuantLab backtest config JSON. Follow the schema below exactly. Output ONLY the JSON object for the config
(no prose, no markdown fences). Use the DEFAULTS for anything the user does not specify. NIFTY and SENSEX have
weekly expiries; BANKNIFTY, FINNIFTY, MIDCPNIFTY and stocks only monthly. SENSEX trades on BFO, others NFO.
Put stop-losses on short legs, not on hedge legs, unless told otherwise. Add a short string field
"_explain" at the top level summarising what you built in one or two sentences."""


def claude_parse(text: str, defaults: dict):
    """Returns result dict or None if Claude is unavailable."""
    if os.environ.get("QUANTLAB_DISABLE_LLM"):
        return None
    try:
        import anthropic  # optional dependency
    except ImportError:
        return None
    if not (os.environ.get("ANTHROPIC_API_KEY") or os.environ.get("ANTHROPIC_AUTH_TOKEN")):
        return None
    schema = open(SCHEMA_DOC).read().split("## HTTP API")[0]
    client = anthropic.Anthropic(timeout=60.0, max_retries=1)
    resp = client.messages.create(
        model=os.environ.get("QUANTLAB_LLM_MODEL", "claude-opus-5"),
        max_tokens=8000,
        output_config={"effort": "low"},
        system=SYSTEM + "\n\n" + schema,
        messages=[{"role": "user", "content": f"DEFAULTS: {json.dumps(defaults)}\n\nSTRATEGY: {text}"}],
    )
    if resp.stop_reason == "refusal":
        return None
    raw = "".join(b.text for b in resp.content if b.type == "text").strip()
    raw = re.sub(r"^```(?:json)?|```$", "", raw, flags=re.M).strip()
    cfg = json.loads(raw)
    explain = cfg.pop("_explain", "")
    merged = base_config(defaults)
    merged.update(cfg)
    return {"config": merged, "notes": [explain] if explain else [], "warnings": [], "engine": "claude"}


def compile_prompt(text: str, defaults: dict, known_unds=()) -> dict:
    text = (text or "").strip()
    if len(text) < 5:
        raise ValueError("Describe your strategy in a sentence or two.")
    if len(text) > 4000:
        raise ValueError("Prompt too long (4000 characters max).")
    res = None
    try:
        res = claude_parse(text, defaults)
    except Exception as e:  # network / parse issues -> deterministic fallback
        res = None
        fallback_note = f"AI parser unavailable ({type(e).__name__}); used rule parser."
    else:
        fallback_note = None
    if res is None:
        res = rule_parse(text, defaults, known_unds)
        if fallback_note:
            res["warnings"].append(fallback_note)
    res["config"]["meta"] = {"source": "prompt", "code": text}
    return copy.deepcopy(res)
