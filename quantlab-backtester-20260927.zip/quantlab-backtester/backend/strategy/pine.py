"""TradingView Pine Script (v4 / v5) -> QuantLab strategy config transpiler.

Pipeline:  source -> tokens -> logical lines (indent + continuation handling) -> statement tree
           -> expression ASTs (recursive descent) -> symbolic evaluation into engine OPERAND /
           RULE / BLOCK dicts (see docs/STRATEGY_SCHEMA.md) -> config.

Variables are bound lazily (AST + environment snapshot) so helper variables that are only used by
plots (colours, labels ...) never need to be translatable.

Public API:  compile_pine(code: str, defaults: dict) -> {"config", "notes", "warnings"}
Errors:      ValueError("line N: message")
"""
from __future__ import annotations

import copy
import re

__all__ = ["compile_pine"]


class PineError(ValueError):
    def __init__(self, line, msg):
        super().__init__(f"line {line or 1}: {msg}")


# ============================================================================ tokenizer

KEYWORDS = {"and", "or", "not", "if", "else", "for", "while", "var", "varip", "true", "false",
            "switch", "import", "export", "type", "method", "to", "by", "in", "continue", "break"}
TYPE_WORDS = {"int", "float", "bool", "string", "color", "series", "simple", "const", "line", "label",
              "box", "table", "linefill"}
OPS3 = ()
OPS2 = (":=", "==", "!=", "<=", ">=", "=>", "+=", "-=", "*=", "/=", "%=")
OPS1 = "+-*/%<>=?:()[],."

_NUM_RE = re.compile(r"(\d+\.?\d*|\.\d+)([eE][+-]?\d+)?")
_NAME_RE = re.compile(r"[A-Za-z_][A-Za-z_0-9]*")


class Tok:
    __slots__ = ("kind", "val", "line", "col")

    def __init__(self, kind, val, line, col):
        self.kind, self.val, self.line, self.col = kind, val, line, col

    def __repr__(self):
        return f"{self.kind}:{self.val!r}@{self.line}"


def tokenize(code: str):
    """Return (tokens, version). Tokens include NL (only at bracket depth 0)."""
    toks, version = [], None
    i, line, col0 = 0, 1, 0  # col0 = index where current line starts
    depth = 0
    n = len(code)
    while i < n:
        ch = code[i]
        col = i - col0
        if ch == "\n":
            if depth == 0:
                toks.append(Tok("NL", "\n", line, col))
            i += 1
            line += 1
            col0 = i
            continue
        if ch in " \t\r":
            i += 1
            continue
        if code.startswith("//", i):
            j = code.find("\n", i)
            j = n if j < 0 else j
            m = re.match(r"//\s*@version\s*=\s*(\d+)", code[i:j])
            if m:
                version = int(m.group(1))
            i = j
            continue
        if ch in "\"'":
            j, buf = i + 1, []
            while j < n and code[j] != ch:
                if code[j] == "\\" and j + 1 < n:
                    buf.append({"n": "\n", "t": "\t"}.get(code[j + 1], code[j + 1]))
                    j += 2
                    continue
                if code[j] == "\n":
                    raise PineError(line, "unterminated string literal")
                buf.append(code[j])
                j += 1
            if j >= n:
                raise PineError(line, "unterminated string literal")
            toks.append(Tok("STR", "".join(buf), line, col))
            i = j + 1
            continue
        if ch == "#":
            m = re.match(r"#[0-9A-Fa-f]{6}([0-9A-Fa-f]{2})?", code[i:])
            if not m:
                raise PineError(line, "unexpected character '#'")
            toks.append(Tok("STR", m.group(0), line, col))
            i += len(m.group(0))
            continue
        if ch.isdigit() or (ch == "." and i + 1 < n and code[i + 1].isdigit()):
            m = _NUM_RE.match(code, i)
            s = m.group(0)
            v = float(s) if ("." in s or "e" in s.lower()) else int(s)
            toks.append(Tok("NUM", v, line, col))
            i = m.end()
            continue
        if ch.isalpha() or ch == "_":
            m = _NAME_RE.match(code, i)
            w = m.group(0)
            toks.append(Tok("KW" if w in KEYWORDS else "NAME", w, line, col))
            i = m.end()
            continue
        two = code[i:i + 2]
        if two in OPS2:
            toks.append(Tok("OP", two, line, col))
            i += 2
            continue
        if ch in OPS1:
            if ch in "([":
                depth += 1
            elif ch in ")]":
                depth = max(0, depth - 1)
            toks.append(Tok("OP", ch, line, col))
            i += 1
            continue
        raise PineError(line, f"unexpected character {ch!r}")
    toks.append(Tok("NL", "\n", line, 0))
    return toks, version


_CONT_END = {"+", "-", "*", "/", "%", "?", ":", ",", "=", ":=", "==", "!=", "<", ">", "<=", ">=", "(", "["}


def logical_lines(toks):
    """Group tokens into (line, indent, [tokens]) handling Pine line wrapping: a physical line whose
    indent is not a multiple of 4, or that follows a line ending in an operator, continues the previous."""
    phys, cur = [], []
    for t in toks:
        if t.kind == "NL":
            if cur:
                phys.append(cur)
            cur = []
        else:
            cur.append(t)
    out = []
    for p in phys:
        indent = p[0].col
        prev = out[-1] if out else None
        cont = prev is not None and (
            (indent % 4 != 0 and indent > prev[1])
            or (prev[2][-1].kind in ("OP", "KW") and prev[2][-1].val in _CONT_END | {"and", "or", "not"})
        )
        if cont:
            prev[2].extend(p)
        else:
            out.append([p[0].line, indent, list(p)])
    return out


# ============================================================================ AST + parser

class Node:
    __slots__ = ("t", "a", "line")

    def __init__(self, t, line, *a):
        self.t, self.line, self.a = t, line, a

    def __repr__(self):
        return f"{self.t}{self.a}"


FORBIDDEN_CALLS = {
    "security": "request.security()/security() (multi-timeframe / other-symbol data) is not supported",
    "request.security": "request.security() (multi-timeframe / other-symbol data) is not supported",
    "request.security_lower_tf": "request.security_lower_tf() is not supported",
    "request.financial": "request.financial() is not supported",
    "request.dividends": "request.* data requests are not supported",
    "request.earnings": "request.* data requests are not supported",
    "request.quandl": "request.* data requests are not supported",
    "time": "time()/time_close() session functions are not supported - use hour/minute comparisons",
    "time_close": "time()/time_close() session functions are not supported - use hour/minute comparisons",
}


class Parser:
    def __init__(self, toks, line):
        self.toks, self.i, self.line = toks, 0, line

    def peek(self, k=0):
        j = self.i + k
        return self.toks[j] if j < len(self.toks) else None

    def at(self, val, kind=None):
        t = self.peek()
        return t is not None and t.val == val and (kind is None or t.kind == kind) and t.kind != "STR"

    def next(self):
        t = self.peek()
        if t is None:
            raise PineError(self.line, "unexpected end of line")
        self.i += 1
        return t

    def expect(self, val):
        t = self.next()
        if t.val != val or t.kind == "STR":
            raise PineError(t.line, f"expected '{val}' but found '{t.val}'")
        return t

    def done(self):
        return self.i >= len(self.toks)

    # expr := ternary
    def expr(self):
        c = self.or_()
        if self.at("?", "OP"):
            t = self.next()
            a = self.expr()
            self.expect(":")
            b = self.expr()
            return Node("tern", t.line, c, a, b)
        return c

    def or_(self):
        a = self.and_()
        while self.at("or", "KW"):
            t = self.next()
            a = Node("bool", t.line, "or", a, self.and_())
        return a

    def and_(self):
        a = self.not_()
        while self.at("and", "KW"):
            t = self.next()
            a = Node("bool", t.line, "and", a, self.not_())
        return a

    def not_(self):
        if self.at("not", "KW"):
            t = self.next()
            return Node("not", t.line, self.not_())
        return self.eq()

    def eq(self):
        a = self.rel()
        while self.peek() and self.peek().kind == "OP" and self.peek().val in ("==", "!="):
            t = self.next()
            a = Node("cmp", t.line, t.val, a, self.rel())
        return a

    def rel(self):
        a = self.add()
        while self.peek() and self.peek().kind == "OP" and self.peek().val in ("<", ">", "<=", ">="):
            t = self.next()
            a = Node("cmp", t.line, t.val, a, self.add())
        return a

    def add(self):
        a = self.mul()
        while self.peek() and self.peek().kind == "OP" and self.peek().val in ("+", "-"):
            t = self.next()
            a = Node("bin", t.line, t.val, a, self.mul())
        return a

    def mul(self):
        a = self.unary()
        while self.peek() and self.peek().kind == "OP" and self.peek().val in ("*", "/", "%"):
            t = self.next()
            a = Node("bin", t.line, t.val, a, self.unary())
        return a

    def unary(self):
        t = self.peek()
        if t and t.kind == "OP" and t.val in ("-", "+"):
            self.next()
            x = self.unary()
            return Node("neg", t.line, x) if t.val == "-" else x
        return self.postfix()

    def postfix(self):
        a = self.primary()
        while True:
            if self.at("[", "OP"):
                t = self.next()
                k = self.expr()
                self.expect("]")
                a = Node("hist", t.line, a, k)
            elif self.at("(", "OP"):
                t = self.next()
                if a.t != "name":
                    raise PineError(t.line, "only named functions can be called")
                args, kwargs = self.call_args()
                fname = a.a[0]
                if fname in FORBIDDEN_CALLS:
                    raise PineError(t.line, FORBIDDEN_CALLS[fname])
                if fname.startswith("array.") or fname.startswith("matrix.") or fname.startswith("map."):
                    raise PineError(t.line, f"{fname}(): arrays / matrices / maps are not supported")
                a = Node("call", t.line, fname, args, kwargs)
            else:
                return a

    def call_args(self):
        args, kwargs = [], {}
        if self.at(")", "OP"):
            self.next()
            return args, kwargs
        while True:
            t, t2 = self.peek(), self.peek(1)
            if t is not None and t.kind in ("NAME", "KW") and t2 is not None and t2.kind == "OP" and t2.val == "=":
                self.next()
                self.next()
                kwargs[t.val] = self.expr()
            else:
                if kwargs:
                    raise PineError(t.line if t else self.line, "positional argument after keyword argument")
                args.append(self.expr())
            if self.at(",", "OP"):
                self.next()
                continue
            self.expect(")")
            return args, kwargs

    def primary(self):
        t = self.next()
        if t.kind == "NUM":
            return Node("num", t.line, t.val)
        if t.kind == "STR":
            return Node("str", t.line, t.val)
        if t.kind == "KW":
            if t.val in ("true", "false"):
                return Node("boolc", t.line, t.val == "true")
            if t.val in ("if", "switch", "for", "while"):
                raise PineError(t.line, f"'{t.val}' expressions are not supported")
            raise PineError(t.line, f"unexpected keyword '{t.val}'")
        if t.kind == "NAME":
            name = t.val
            while self.at(".", "OP") and self.peek(1) is not None and self.peek(1).kind in ("NAME", "KW"):
                self.next()
                name += "." + self.next().val
            if name == "na":
                return Node("na", t.line)
            return Node("name", t.line, name)
        if t.val == "(" and t.kind == "OP":
            e = self.expr()
            self.expect(")")
            return e
        if t.val == "[" and t.kind == "OP":
            items = []
            if not self.at("]", "OP"):
                items.append(self.expr())
                while self.at(",", "OP"):
                    self.next()
                    items.append(self.expr())
            self.expect("]")
            return Node("list", t.line, items)
        raise PineError(t.line, f"unexpected '{t.val}'")


def parse_expr(toks, line):
    p = Parser(toks, line)
    e = p.expr()
    if not p.done():
        t = p.peek()
        raise PineError(t.line, f"unexpected '{t.val}' after expression")
    return e


# ---------------------------------------------------------------------------- statements

class Stmt:
    def __init__(self, kind, line, indent, **kw):
        self.kind, self.line, self.indent = kind, line, indent
        self.body, self.orelse = [], None
        self.__dict__.update(kw)


def parse_statement(line, indent, toks):
    t0 = toks[0]
    if any(t.kind == "OP" and t.val == "=>" for t in toks):
        raise PineError(line, "user-defined functions (=>) are not supported")
    if t0.kind == "KW":
        if t0.val in ("for", "while"):
            raise PineError(line, f"'{t0.val}' loops are not supported")
        if t0.val == "switch":
            raise PineError(line, "'switch' is not supported")
        if t0.val in ("import", "export", "type", "method"):
            raise PineError(line, f"'{t0.val}' (libraries / user types) is not supported")
        if t0.val in ("break", "continue"):
            raise PineError(line, f"'{t0.val}' is not supported")
        if t0.val == "if":
            if len(toks) < 2:
                raise PineError(line, "'if' without a condition")
            return Stmt("if", line, indent, cond=parse_expr(toks[1:], line))
        if t0.val == "else":
            if len(toks) > 1 and toks[1].val == "if" and toks[1].kind == "KW":
                return Stmt("elif", line, indent, cond=parse_expr(toks[2:], line))
            if len(toks) > 1:
                raise PineError(line, "unexpected tokens after 'else'")
            return Stmt("else", line, indent)
    # strip declaration modifiers: var / varip / type words
    i, is_var = 0, False
    while i < len(toks) and ((toks[i].kind == "KW" and toks[i].val in ("var", "varip"))):
        is_var = True
        i += 1
    if (i + 2 < len(toks) and toks[i].kind == "NAME" and toks[i].val in TYPE_WORDS
            and toks[i + 1].kind == "NAME" and toks[i + 2].val in ("=",)):
        i += 1
    if (i + 4 < len(toks) and toks[i].kind == "NAME" and toks[i].val in TYPE_WORDS and toks[i + 1].val == "["):
        raise PineError(line, "arrays are not supported")
    rest = toks[i:]
    # tuple assignment [a, b] = f(...)
    if rest[0].kind == "OP" and rest[0].val == "[":
        j, names = 1, []
        while j < len(rest) and not (rest[j].kind == "OP" and rest[j].val == "]"):
            if rest[j].kind == "NAME":
                names.append(rest[j].val)
            elif not (rest[j].kind == "OP" and rest[j].val == ","):
                raise PineError(line, f"unexpected '{rest[j].val}' in tuple assignment")
            j += 1
        if j + 1 < len(rest) and rest[j + 1].val in ("=", ":="):
            return Stmt("tuple", line, indent, names=names, value=parse_expr(rest[j + 2:], line))
        raise PineError(line, "array literals are not supported")
    if len(rest) >= 2 and rest[0].kind == "NAME" and rest[1].kind == "OP" and \
            rest[1].val in ("=", ":=", "+=", "-=", "*=", "/=", "%="):
        if len(rest) < 3:
            raise PineError(line, f"missing value after '{rest[1].val}'")
        op = rest[1].val
        return Stmt("assign" if op == "=" else "reassign", line, indent, name=rest[0].val, op=op,
                    is_var=is_var, value=parse_expr(rest[2:], line))
    if is_var:
        raise PineError(line, "expected a variable declaration after 'var'")
    return Stmt("expr", line, indent, value=parse_expr(rest, line))


def build_tree(lines):
    stmts = [parse_statement(ln, ind, toks) for ln, ind, toks in lines]
    pos = 0

    def block(indent):
        nonlocal pos
        out = []
        while pos < len(stmts):
            s = stmts[pos]
            if s.indent < indent:
                break
            if s.indent > indent:
                raise PineError(s.line, "unexpected indentation")
            pos += 1
            if s.kind in ("else", "elif"):
                prev = out[-1] if out else None
                while prev is not None and prev.orelse is not None:
                    prev = prev.orelse
                if prev is None or prev.kind not in ("if", "elif") or prev.orelse is not None:
                    raise PineError(s.line, "'else' without matching 'if'")
                prev.orelse = s
            else:
                out.append(s)
            if s.kind in ("if", "elif", "else"):
                if pos < len(stmts) and stmts[pos].indent > indent:
                    s.body = block(stmts[pos].indent)
                else:
                    raise PineError(s.line, f"'{s.kind}' has an empty body")
        return out

    tree = block(stmts[0].indent if stmts else 0)
    if pos < len(stmts):
        raise PineError(stmts[pos].line, "unexpected indentation")
    return tree


# ============================================================================ symbolic values

FIELD_NAMES = {"open": "Open", "high": "High", "low": "Low", "close": "Close", "volume": "Volume",
               "hl2": "HL2", "hlc3": "HLC3", "ohlc4": "OHLC4"}
SOURCE_INDICATORS = {"SMA", "EMA", "RMA", "WMA", "HMA", "DEMA", "TEMA", "VWMA", "RSI", "MACD", "MACDSignal",
                     "MACDHist", "UpperBB", "LowerBB", "MidBB", "Stdev", "Zscore", "ROC", "Momentum",
                     "Highest", "Lowest", "Change", "ChangePct", "CCI"}


class Const:
    def __init__(self, v):
        self.v = v


class Num:
    """Numeric series, `op` is an engine OPERAND dict."""

    def __init__(self, op, dow=False):
        self.op, self.dow = op, dow


class Cond:
    """Boolean series, `c` is a RULE / BLOCK / {"not": ...} dict."""

    def __init__(self, c):
        self.c = c


class TupleV:
    def __init__(self, items):
        self.items = items


class Side:
    def __init__(self, s):
        self.s = s


class AvgLin:
    """strategy.position_avg_price * mult + add"""

    def __init__(self, mult=1.0, add=0.0):
        self.mult, self.add = mult, add


class PosSize:
    pass


def ind(name, n=0, src="Close", n2=0, n3=0, of=None):
    op = {"kind": "ind", "name": name, "n": n, "src": src, "n2": n2, "n3": n3, "offset": 0}
    if of is not None:
        op["of"] = of
    return op


def const_op(v):
    if isinstance(v, bool):
        v = 1 if v else 0
    return {"kind": "const", "value": v}


def is_plain_field(op, name=None):
    return (op.get("kind") == "ind" and op.get("name") in FIELD_NAMES.values() and not op.get("offset")
            and "of" not in op and (name is None or op["name"] == name))


FLIP = {">": "<", "<": ">", ">=": "<=", "<=": ">=", "==": "==", "!=": "!="}
PY_CMP = {">": lambda a, b: a > b, "<": lambda a, b: a < b, ">=": lambda a, b: a >= b,
          "<=": lambda a, b: a <= b, "==": lambda a, b: a == b, "!=": lambda a, b: a != b}

IGNORED_CALLS = {"plot", "plotshape", "plotchar", "plotarrow", "plotcandle", "plotbar", "hline", "fill",
                 "bgcolor", "barcolor", "alert", "alertcondition", "runtime.error"}
IGNORED_PREFIXES = ("label.", "line.", "box.", "table.", "linefill.", "log.", "polyline.", "chart.")

# Pine dayofweek.* constants (Sunday = 1)
DOW_CONST = {"sunday": 1, "monday": 2, "tuesday": 3, "wednesday": 4, "thursday": 5, "friday": 6, "saturday": 7}


def pine_dow_to_iso(p):
    return (int(p) + 5) % 7 + 1


class Binding:
    __slots__ = ("node", "env", "line", "memo", "index", "name")

    def __init__(self, node, env, line, name, index=None, memo=None):
        self.node, self.env, self.line, self.name, self.index, self.memo = node, env, line, name, index, memo


class Compiler:
    def __init__(self, code, defaults):
        self.code = code
        self.defaults = defaults or {}
        self.notes, self.warnings = [], []
        self.env = {}
        self.entries = []   # (side, id, cond_or_None, line)
        self.closes = []    # (id, cond, line)
        self.close_all = []  # (cond, line)
        self.exits = []     # (from_entry or None, dict, line)
        self.title = None
        self.version = None
        self.header_seen = False
        self._evaluating = set()

    # -------------------------------------------------------------- messages
    def note(self, msg):
        if msg not in self.notes:
            self.notes.append(msg)

    def warn(self, msg):
        if msg not in self.warnings:
            self.warnings.append(msg)

    # -------------------------------------------------------------- value helpers
    def num(self, v, line, what="value"):
        """Coerce to an operand dict (numeric series)."""
        if isinstance(v, Const):
            if v.v is None:
                raise PineError(line, f"'na' cannot be used as a {what}")
            if isinstance(v.v, str):
                raise PineError(line, f"string {v.v!r} used where a number is expected")
            return const_op(v.v)
        if isinstance(v, Num):
            if v.dow:
                raise PineError(line, "dayofweek can only be compared with constants "
                                      "(e.g. dayofweek == dayofweek.monday)")
            return v.op
        if isinstance(v, Cond):
            raise PineError(line, "a true/false condition was used where a number is expected")
        if isinstance(v, TupleV):
            raise PineError(line, "function returns a tuple - destructure it: [a, b, c] = ...")
        if isinstance(v, AvgLin):
            raise PineError(line, "strategy.position_avg_price can only be used in strategy.exit(stop=, limit=)")
        if isinstance(v, PosSize):
            raise PineError(line, "strategy.position_size can only be compared (e.g. strategy.position_size > 0)")
        raise PineError(line, f"{what} is not a number")

    def cond(self, v, line):
        """Coerce to a Cond or Const(bool)."""
        if isinstance(v, Cond):
            return v
        if isinstance(v, Const):
            if v.v is None:
                return Const(False)
            if isinstance(v.v, str):
                raise PineError(line, f"string {v.v!r} used as a condition")
            return Const(bool(v.v))
        if isinstance(v, Num) and not v.dow:
            return Cond({"lhs": v.op, "op": "is_true", "rhs": const_op(0)})
        return Cond({"lhs": self.num(v, line), "op": "is_true", "rhs": const_op(0)})

    def const_num(self, v, line, what, integer=False):
        if not isinstance(v, Const) or v.v is None or isinstance(v.v, str):
            raise PineError(line, f"{what} must be a constant number (literal or input)")
        x = v.v
        if integer:
            if float(x) != int(x) or int(x) <= 0:
                raise PineError(line, f"{what} must be a positive whole number, got {x}")
            return int(x)
        return float(x) if isinstance(x, float) else x

    # -------------------------------------------------------------- evaluation
    def lookup(self, name, env, line):
        b = env.get(name)
        if b is None:
            return None
        if isinstance(b, Binding):
            if b.memo is None:
                key = id(b)
                if key in self._evaluating:
                    raise PineError(b.line, f"'{b.name}' refers to itself")
                self._evaluating.add(key)
                try:
                    b.memo = self.eval(b.node, b.env)
                finally:
                    self._evaluating.discard(key)
            v = b.memo
            if b.index is not None:
                if not isinstance(v, TupleV):
                    raise PineError(b.line, "right side of a tuple assignment must return a tuple")
                if b.index >= len(v.items):
                    raise PineError(b.line, f"function returns only {len(v.items)} values")
                return v.items[b.index]
            return v
        return b

    def eval(self, node, env):
        t, ln = node.t, node.line
        if t == "num":
            return Const(node.a[0])
        if t == "str":
            return Const(node.a[0])
        if t == "boolc":
            return Const(node.a[0])
        if t == "na":
            return Const(None)
        if t == "name":
            return self.eval_name(node.a[0], env, ln)
        if t == "neg":
            return self.arith("neg", self.eval(node.a[0], env), None, ln)
        if t == "bin":
            return self.arith(node.a[0], self.eval(node.a[1], env), self.eval(node.a[2], env), ln)
        if t == "cmp":
            return self.compare(node.a[0], self.eval(node.a[1], env), self.eval(node.a[2], env), ln)
        if t == "bool":
            return self.logic(node.a[0], self.eval(node.a[1], env), self.eval(node.a[2], env), ln)
        if t == "not":
            return self.negate(self.cond(self.eval(node.a[0], env), ln))
        if t == "tern":
            return self.ternary(node, env)
        if t == "hist":
            k = self.eval(node.a[1], env)
            if not isinstance(k, Const) or not isinstance(k.v, (int, float)) or float(k.v) != int(k.v) or k.v < 0:
                raise PineError(ln, "history reference x[k] needs a constant non-negative whole number k")
            return self.shift(self.eval(node.a[0], env), int(k.v), ln)
        if t == "call":
            return self.call(node, env)
        if t == "list":
            raise PineError(ln, "array literals / tuples are only supported on the left of '=' "
                                "(e.g. [m, s, h] = ta.macd(...)) or in input options=[...]")
        raise PineError(ln, f"unsupported expression ({t})")

    def ternary(self, node, env):
        ln = node.line
        c = self.cond(self.eval(node.a[0], env), ln)
        if isinstance(c, Const):
            return self.eval(node.a[1] if c.v else node.a[2], env)
        a, b = self.eval(node.a[1], env), self.eval(node.a[2], env)
        if isinstance(a, Const) and isinstance(b, Const) and a.v == b.v:
            return a
        bool_like = lambda v: isinstance(v, Cond) or (isinstance(v, Const) and isinstance(v.v, bool))
        if bool_like(a) and bool_like(b):
            # c ? a : b  ==  (c and a) or (not c and b)
            return self.logic("or", self.logic("and", c, a, ln), self.logic("and", self.negate(c), b, ln), ln)
        raise PineError(ln, "ternary 'cond ? a : b' with a changing (series) condition and numeric branches "
                            "is not supported - only constant conditions or true/false branches")

    def eval_name(self, name, env, ln):
        v = self.lookup(name, env, ln)
        if v is not None:
            return v
        base = name[3:] if name.startswith("ta.") else name
        if base in FIELD_NAMES and name == base:
            return Num(ind(FIELD_NAMES[base]))
        if name in ("hour", "minute"):
            self.note("hour/minute are evaluated at candle close time in QuantLab (Pine uses bar open time), "
                      "so time filters act one candle later than on TradingView.")
            return Num({"kind": "dt", "field": name.capitalize(), "offset": 0})
        if name == "dayofweek":
            self.note("dayofweek is converted from Pine numbering (Sunday=1) to ISO weekdays (Monday=1).")
            return Num({"kind": "dt", "field": "WeekDay", "offset": 0}, dow=True)
        if name.startswith("dayofweek."):
            k = name.split(".", 1)[1]
            if k in DOW_CONST:
                return Const(DOW_CONST[k])
        if name in ("ta.vwap", "vwap"):
            return Num(ind("VWAP"))
        if name in ("ta.tr", "tr"):
            raise PineError(ln, "ta.tr is not supported - use ta.atr(n)")
        if name in ("strategy.long",):
            return Side("long")
        if name in ("strategy.short",):
            return Side("short")
        if name == "strategy.position_avg_price":
            return AvgLin()
        if name in ("strategy.position_size", "strategy.opentrades"):
            return PosSize()
        if name == "syminfo.mintick":
            self.note("syminfo.mintick is taken as 0.05 (NSE/BSE index tick).")
            return Const(0.05)
        if name in ("barstate.isconfirmed", "barstate.isrealtime", "barstate.ishistory", "session.ismarket",
                    "session.isfirstbar", "session.islastbar"):
            if name in ("barstate.isrealtime",):
                return Const(False)
            if name.startswith("session.is") and name != "session.ismarket":
                raise PineError(ln, f"{name} is not supported")
            self.note(f"{name} is treated as always true (rules are evaluated on closed candles).")
            return Const(True)
        if name in ("time", "time_close", "timenow"):
            raise PineError(ln, f"'{name}' is not supported - use hour/minute/dayofweek comparisons")
        if name in ("bar_index", "last_bar_index", "year", "month", "dayofmonth", "weekofyear", "second",
                    "timeframe.period", "timeframe.multiplier"):
            raise PineError(ln, f"'{name}' is not supported")
        if name.startswith(("color.", "shape.", "location.", "size.", "position.", "display.", "extend.",
                            "text.", "xloc.", "yloc.", "hline.", "plot.", "format.", "scale.", "currency.",
                            "strategy.", "input.", "barmerge.", "order.", "alert.", "font.", "adjustment.")):
            return Const(name)
        raise PineError(ln, f"undeclared identifier '{name}'")

    # -------------------------------------------------------------- operators
    def arith(self, op, a, b, ln):
        if op == "neg":
            if isinstance(a, Const):
                if a.v is None:
                    return a
                return Const(-self.const_num(a, ln, "operand"))
            if isinstance(a, AvgLin):
                raise PineError(ln, "unsupported use of strategy.position_avg_price")
            x = self.num(a, ln)
            if x.get("kind") == "expr" and x.get("op") == "neg" and not x.get("offset"):
                return Num(x["args"][0])
            return Num({"kind": "expr", "op": "neg", "args": [x], "offset": 0})
        if isinstance(a, Const) and isinstance(b, Const):
            if a.v is None or b.v is None:
                return Const(None)
            if isinstance(a.v, str) or isinstance(b.v, str):
                if op == "+" and isinstance(a.v, str) and isinstance(b.v, str):
                    return Const(a.v + b.v)
                raise PineError(ln, "arithmetic on strings is not supported")
            x, y = a.v, b.v
            if op in ("/", "%") and y == 0:
                raise PineError(ln, "division by zero")
            r = {"+": lambda: x + y, "-": lambda: x - y, "*": lambda: x * y, "/": lambda: x / y,
                 "%": lambda: x % y}[op]()
            if op == "/" and isinstance(x, int) and isinstance(y, int) and x % y == 0:
                r = x // y
            return Const(r)
        # strategy.position_avg_price linear forms
        if isinstance(a, AvgLin) or isinstance(b, AvgLin):
            if isinstance(a, AvgLin) and isinstance(b, Const) and b.v is not None:
                k = float(b.v)
                if op == "*":
                    return AvgLin(a.mult * k, a.add * k)
                if op == "/" and k:
                    return AvgLin(a.mult / k, a.add / k)
                if op == "+":
                    return AvgLin(a.mult, a.add + k)
                if op == "-":
                    return AvgLin(a.mult, a.add - k)
            if isinstance(b, AvgLin) and isinstance(a, Const) and a.v is not None:
                k = float(a.v)
                if op == "*":
                    return AvgLin(b.mult * k, b.add * k)
                if op == "+":
                    return AvgLin(b.mult, b.add + k)
            raise PineError(ln, "strategy.position_avg_price can only be scaled/offset by constants")
        if op == "%":
            raise PineError(ln, "the modulo operator % is only supported on constants")
        x, y = self.num(a, ln), self.num(b, ln)
        eop = op
        if x.get("kind") == "expr" and x.get("op") == eop and not x.get("offset") and len(x["args"]) >= 2:
            return Num({"kind": "expr", "op": eop, "args": x["args"] + [y], "offset": 0})
        return Num({"kind": "expr", "op": eop, "args": [x, y], "offset": 0})

    def compare(self, op, a, b, ln):
        if isinstance(a, PosSize) or isinstance(b, PosSize):
            self.note("strategy.position_size checks are dropped: QuantLab only enters when flat and "
                      "exit rules only run while a position is open.")
            return Const(True)
        if isinstance(a, Const) and isinstance(b, Const):
            if a.v is None or b.v is None:
                return Const(False)
            try:
                return Const(PY_CMP[op](a.v, b.v))
            except TypeError:
                raise PineError(ln, "cannot compare these values")
        # condition == true/false
        if op in ("==", "!=") and (isinstance(a, Cond) or isinstance(b, Cond)):
            c, k = (a, b) if isinstance(a, Cond) else (b, a)
            if isinstance(k, Const) and isinstance(k.v, bool):
                return c if (k.v == (op == "==")) else self.negate(c)
            raise PineError(ln, "comparing two conditions with ==/!= is not supported")
        # normalize: constant on the right
        if isinstance(a, Const) and not isinstance(b, Const):
            a, b, op = b, a, FLIP[op]
        if isinstance(a, Num) and a.dow:
            return self.dow_compare(op, b, ln)
        x, y = self.num(a, ln), self.num(b, ln)
        # neg(X) op c  ->  X flip(op) -c   (keeps SupertrendDir rules readable)
        if y.get("kind") == "const" and x.get("kind") == "expr" and x.get("op") == "neg" and not x.get("offset"):
            x, y, op = x["args"][0], const_op(-y["value"]), FLIP[op]
        return Cond({"lhs": x, "op": op, "rhs": y})

    def dow_compare(self, op, b, ln):
        if not isinstance(b, Const) or not isinstance(b.v, (int, float)):
            raise PineError(ln, "dayofweek can only be compared with constants")
        days = [p for p in range(1, 8) if PY_CMP[op](p, b.v)]
        iso = sorted(pine_dow_to_iso(p) for p in days if 2 <= p <= 6)  # trading days Mon..Fri
        wd = {"kind": "dt", "field": "WeekDay", "offset": 0}
        if not iso:
            return Const(False)
        if iso == [1, 2, 3, 4, 5]:
            return Const(True)
        if iso == list(range(iso[0], iso[-1] + 1)):
            if len(iso) == 1:
                return Cond({"lhs": wd, "op": "==", "rhs": const_op(iso[0])})
            return Cond({"logic": "AND", "rules": [{"lhs": wd, "op": ">=", "rhs": const_op(iso[0])},
                                                   {"lhs": wd, "op": "<=", "rhs": const_op(iso[-1])}]})
        return Cond({"logic": "OR", "rules": [{"lhs": wd, "op": "==", "rhs": const_op(d)} for d in iso]})

    def logic(self, kind, a, b, ln):
        a, b = self.cond(a, ln), self.cond(b, ln)
        for x, y in ((a, b), (b, a)):
            if isinstance(x, Const):
                if kind == "and":
                    return y if x.v else Const(False)
                return Const(True) if x.v else y
        L = kind.upper()
        rules = []
        for c in (a.c, b.c):
            if c.get("logic") == L and "rules" in c:
                rules.extend(c["rules"])
            else:
                rules.append(c)
        return Cond({"logic": L, "rules": rules})

    def negate(self, c):
        if isinstance(c, Const):
            return Const(not c.v)
        if "not" in c.c and len(c.c) == 1:
            return Cond(c.c["not"])
        return Cond({"not": c.c})

    def shift(self, v, k, ln):
        if k == 0 or isinstance(v, Const):
            return v
        if isinstance(v, Num):
            op = copy.deepcopy(v.op)
            if op.get("kind") != "const":
                op["offset"] = int(op.get("offset") or 0) + k
            return Num(op, v.dow)
        if isinstance(v, Cond):
            c = copy.deepcopy(v.c)

            def walk(r):
                if "rules" in r:
                    for x in r["rules"]:
                        walk(x)
                elif "not" in r:
                    walk(r["not"])
                else:
                    for s in ("lhs", "rhs"):
                        o = r.get(s)
                        if o and o.get("kind") != "const":
                            o["offset"] = int(o.get("offset") or 0) + k
            walk(c)
            return Cond(c)
        raise PineError(ln, "history reference [k] is not supported on this value")

    # -------------------------------------------------------------- function calls
    def bind(self, node, env, names, required=0, fname=None):
        _, args, kwargs = node.a
        fname = fname or node.a[0]
        if len(args) > len(names):
            raise PineError(node.line, f"{fname}() takes at most {len(names)} arguments")
        out = {}
        for nm, a in zip(names, args):
            out[nm] = a
        for k, a in kwargs.items():
            if k not in names:
                if k in ("title", "tooltip", "inline", "group", "confirm", "display", "options", "minval",
                         "maxval", "step", "type", "timeframe", "timeframe_gaps", "anchor", "offset"):
                    continue
                raise PineError(node.line, f"{fname}(): unknown argument '{k}'")
            out[k] = a
        missing = [n for n in names[:required] if n not in out]
        if missing:
            raise PineError(node.line, f"{fname}(): missing argument '{missing[0]}'")
        return out

    def src_ind(self, name, srcv, n, ln, n2=0, n3=0):
        """Indicator on a source series: Close -> src, anything else -> 'of'."""
        if isinstance(srcv, Const):
            raise PineError(ln, f"source of {name} must be a price series or indicator, not a constant")
        s = self.num(srcv, ln, "source")
        if is_plain_field(s, "Close"):
            if name == "CCI":
                return ind(name, n, "Close", n2, n3, of=s)  # engine CCI default is HLC3
            return ind(name, n, "Close", n2, n3)
        if name == "CCI" and is_plain_field(s, "HLC3"):
            return ind(name, n, "Close", n2, n3)
        if name not in SOURCE_INDICATORS:
            raise PineError(ln, f"{name} cannot be applied to a custom source")
        return ind(name, n, "Close", n2, n3, of=s)

    def call(self, node, env):
        fname, args, kwargs = node.a
        ln = node.line
        f = fname
        for p in ("ta.", "math."):
            if f.startswith(p):
                f = f[len(p):]
                break
        E = lambda nd: self.eval(nd, env)

        # ---- inputs
        if fname == "input" or fname.startswith("input."):
            return self.input_call(node, env)
        # ---- indicators
        if f in ("sma", "ema", "rma", "wma", "hma", "vwma", "rsi", "stdev", "mom", "roc", "cci") and \
                (fname == f or fname.startswith("ta.")):
            b = self.bind(node, env, ["source", "length"], 2, fname)
            n = self.const_num(E(b["length"]), ln, f"{fname} length", integer=True)
            src = E(b["source"])
            name = {"sma": "SMA", "ema": "EMA", "rma": "RMA", "wma": "WMA", "hma": "HMA", "vwma": "VWMA",
                    "rsi": "RSI", "stdev": "Stdev", "mom": "Momentum", "roc": "ROC", "cci": "CCI"}[f]
            if f == "sma" and isinstance(src, Num) and src.op.get("name") == "StochK" and \
                    src.op.get("kind") == "ind" and not src.op.get("offset") and "of" not in src.op:
                s = src.op
                if int(s.get("n2") or 3) == 1:
                    return Num(ind("StochK", s["n"], n2=n))
                return Num(ind("StochD", s["n"], n2=s["n2"], n3=n))
            if f == "vwma" and not (isinstance(src, Num) and is_plain_field(src.op, "Close")):
                self.warn(f"line {ln}: VWMA on a non-close source uses the candle volume as weights.")
            return Num(self.src_ind(name, src, n, ln))
        if f in ("highest", "lowest") and (fname == f or fname.startswith("ta.")):
            if len(args) + len(kwargs) == 1:
                b = self.bind(node, env, ["length"], 1, fname)
                n = self.const_num(E(b["length"]), ln, f"{fname} length", integer=True)
                return Num(ind("HighestHigh" if f == "highest" else "LowestLow", n))
            b = self.bind(node, env, ["source", "length"], 2, fname)
            n = self.const_num(E(b["length"]), ln, f"{fname} length", integer=True)
            src = E(b["source"])
            if isinstance(src, Num) and is_plain_field(src.op, "High" if f == "highest" else "Low"):
                return Num(ind("HighestHigh" if f == "highest" else "LowestLow", n))
            return Num(self.src_ind("Highest" if f == "highest" else "Lowest", src, n, ln))
        if f == "macd" and (fname == f or fname.startswith("ta.")):
            b = self.bind(node, env, ["source", "fastlen", "slowlen", "siglen"], 4, fname)
            fl = self.const_num(E(b["fastlen"]), ln, "macd fast length", integer=True)
            sl = self.const_num(E(b["slowlen"]), ln, "macd slow length", integer=True)
            sg = self.const_num(E(b["siglen"]), ln, "macd signal length", integer=True)
            src = E(b["source"])
            return TupleV([Num(self.src_ind(nm, src, fl, ln, sl, sg)) for nm in ("MACD", "MACDSignal", "MACDHist")])
        if f == "bb" and (fname == f or fname.startswith("ta.")):
            b = self.bind(node, env, ["series", "length", "mult"], 3, fname)
            n = self.const_num(E(b["length"]), ln, "bb length", integer=True)
            k = self.const_num(E(b["mult"]), ln, "bb mult")
            src = E(b["series"])
            return TupleV([Num(self.src_ind(nm, src, n, ln, k)) for nm in ("MidBB", "UpperBB", "LowerBB")])
        if f == "atr" and (fname == f or fname.startswith("ta.")):
            b = self.bind(node, env, ["length"], 1, fname)
            return Num(ind("ATR", self.const_num(E(b["length"]), ln, "atr length", integer=True)))
        if f == "supertrend" and (fname == f or fname.startswith("ta.")):
            b = self.bind(node, env, ["factor", "atrPeriod"], 2, fname)
            k = self.const_num(E(b["factor"]), ln, "supertrend factor")
            n = self.const_num(E(b["atrPeriod"]), ln, "supertrend ATR period", integer=True)
            self.note("Supertrend direction: Pine returns -1 in an uptrend; it is mapped onto QuantLab "
                      "SupertrendDir (+1 = up), so 'direction < 0' becomes 'SupertrendDir > 0'.")
            d = {"kind": "expr", "op": "neg", "args": [ind("SupertrendDir", n, n2=k)], "offset": 0}
            return TupleV([Num(ind("Supertrend", n, n2=k)), Num(d)])
        if f == "vwap" and (fname == f or fname.startswith("ta.")):
            if args:
                s = E(args[0])
                if not (isinstance(s, Num) and is_plain_field(s.op, "HLC3")):
                    self.warn(f"line {ln}: VWAP is computed on hlc3 (session anchored) regardless of the source.")
            return Num(ind("VWAP"))
        if f == "stoch" and (fname == f or fname.startswith("ta.")):
            b = self.bind(node, env, ["source", "high", "low", "length"], 4, fname)
            n = self.const_num(E(b["length"]), ln, "stoch length", integer=True)
            ok = [isinstance(v, Num) and is_plain_field(v.op, nm)
                  for v, nm in ((E(b["source"]), "Close"), (E(b["high"]), "High"), (E(b["low"]), "Low"))]
            if not all(ok):
                raise PineError(ln, "stoch() is only supported as ta.stoch(close, high, low, length)")
            return Num(ind("StochK", n, n2=1))
        if f == "dmi" and (fname == f or fname.startswith("ta.")):
            b = self.bind(node, env, ["diLength", "adxSmoothing"], 2, fname)
            n = self.const_num(E(b["diLength"]), ln, "dmi length", integer=True)
            sm = self.const_num(E(b["adxSmoothing"]), ln, "adx smoothing", integer=True)
            return TupleV([Num(ind("PlusDI", n, n2=sm)), Num(ind("MinusDI", n, n2=sm)), Num(ind("ADX", n, n2=sm))])
        if f == "change" and (fname == f or fname.startswith("ta.")):
            b = self.bind(node, env, ["source", "length"], 1, fname)
            n = self.const_num(E(b["length"]), ln, "change length", integer=True) if "length" in b else 1
            src = E(b["source"])
            if isinstance(src, Cond):
                raise PineError(ln, "change() of a true/false series is not supported")
            if n == 1:
                return Num(self.src_ind("Change", src, 0, ln))
            return self.arith("-", src, self.shift(src, n, ln), ln)
        if f in ("rising", "falling") and (fname == f or fname.startswith("ta.")):
            b = self.bind(node, env, ["source", "length"], 2, fname)
            n = self.const_num(E(b["length"]), ln, f"{f} length", integer=True)
            src = E(b["source"])
            out = Const(True)
            for i in range(n):
                out = self.logic("and", out, self.compare(">" if f == "rising" else "<", self.shift(src, i, ln),
                                                          self.shift(src, i + 1, ln), ln), ln)
            return out
        if f in ("crossover", "crossunder", "cross") and (fname == f or fname.startswith("ta.")):
            b = self.bind(node, env, ["source1", "source2"], 2, fname) if f != "cross" else \
                self.bind(node, env, ["x", "y"], 2, fname)
            vals = list(b.values())
            a, c = E(vals[0]), E(vals[1])
            if isinstance(a, Const) and isinstance(c, Const):
                raise PineError(ln, f"{fname}() needs at least one series argument")
            op = {"crossover": "crosses_above", "crossunder": "crosses_below", "cross": "crosses"}[f]
            if isinstance(a, Const):
                a, c = c, a
                op = {"crosses_above": "crosses_below", "crosses_below": "crosses_above"}.get(op, op)
            return Cond({"lhs": self.num(a, ln), "op": op, "rhs": self.num(c, ln)})
        # ---- math
        if f in ("abs", "sqrt", "log") and (fname == f or fname.startswith("math.")):
            if len(args) != 1:
                raise PineError(ln, f"{fname}() takes one argument")
            v = E(args[0])
            if isinstance(v, Const):
                import math as _m
                x = self.const_num(v, ln, "argument")
                if f == "abs":
                    return Const(abs(x))
                if x <= 0 and f == "log" or x < 0:
                    raise PineError(ln, f"{fname}() of a non-positive constant")
                return Const(_m.sqrt(x) if f == "sqrt" else _m.log(x))
            return Num({"kind": "expr", "op": f, "args": [self.num(v, ln)], "offset": 0})
        if f in ("max", "min") and (fname == f or fname.startswith("math.")):
            if len(args) < 2:
                raise PineError(ln, f"{fname}() needs at least two arguments")
            vals = [E(a) for a in args]
            if all(isinstance(v, Const) for v in vals):
                xs = [self.const_num(v, ln, "argument") for v in vals]
                return Const(max(xs) if f == "max" else min(xs))
            return Num({"kind": "expr", "op": f, "args": [self.num(v, ln) for v in vals], "offset": 0})
        if f == "pow" and (fname == f or fname.startswith("math.")):
            if len(args) != 2:
                raise PineError(ln, f"{fname}() takes two arguments")
            a, c = E(args[0]), E(args[1])
            if isinstance(a, Const) and isinstance(c, Const):
                return Const(self.const_num(a, ln, "base") ** self.const_num(c, ln, "exponent"))
            return Num({"kind": "expr", "op": "pow", "args": [self.num(a, ln), self.num(c, ln)], "offset": 0})
        if f == "round" and fname.startswith("math.") or fname == "round":
            v = E(args[0]) if args else None
            if isinstance(v, Const):
                return Const(round(self.const_num(v, ln, "argument")))
            raise PineError(ln, "round() is only supported on constants")
        if fname == "nz":
            if not args:
                raise PineError(ln, "nz() needs an argument")
            self.warn(f"line {ln}: nz() dropped - comparisons involving missing values are simply false.")
            return E(args[0])
        if fname == "na":
            raise PineError(ln, "na() checks are not supported")
        if fname in ("color.new", "color.rgb", "color.from_gradient"):
            return Const("color")
        if fname in ("str.tostring", "tostring"):
            return Const("")
        if fname in ("int", "float"):
            return E(args[0])
        if fname in ("strategy.entry", "strategy.close", "strategy.exit", "strategy.close_all", "strategy.order",
                     "strategy.cancel", "strategy.cancel_all", "strategy.risk.allow_entry_in"):
            raise PineError(ln, f"{fname}() cannot be used inside an expression")
        if f in ("valuewhen", "barssince", "pivothigh", "pivotlow", "correlation", "linreg", "sar", "percentrank",
                 "median", "mode", "range", "variance", "dev", "alma", "swma", "kc", "kcw", "bbw", "cmo", "cog",
                 "mfi", "tsi", "wpr", "obv", "accdist", "iii", "nvi", "pvi", "pvt", "wad", "wvad", "cum",
                 "falling", "tr", "highestbars", "lowestbars", "percentile_linear_interpolation",
                 "percentile_nearest_rank"):
            raise PineError(ln, f"{fname}() is not supported by the QuantLab engine")
        raise PineError(ln, f"{fname}() is not supported")

    def input_call(self, node, env):
        fname, args, kwargs = node.a
        ln = node.line
        if "defval" in kwargs:
            dv = kwargs["defval"]
        elif args:
            dv = args[0]
        else:
            dv = None
        kind = fname.split(".", 1)[1] if "." in fname else None
        if kind == "source" or (kind is None and "type" in kwargs and self._is_source_type(kwargs["type"])):
            if dv is None:
                return Num(ind("Close"))
            v = self.eval(dv, env)
            if not isinstance(v, Num):
                raise PineError(ln, "input.source default must be a price series (close, hl2, ...)")
            return v
        if kind in ("timeframe", "symbol", "session", "time", "price", "text_area", "color", "string"):
            if kind == "timeframe":
                self.warn(f"line {ln}: input.timeframe ignored - the backtest timeframe is used.")
            if kind == "time":
                raise PineError(ln, "input.time is not supported")
            return self.eval(dv, env) if dv is not None else Const("")
        if dv is None:
            raise PineError(ln, f"{fname}() needs a default value")
        v = self.eval(dv, env)
        if not isinstance(v, (Const, Num)):
            raise PineError(ln, f"{fname}() default must be a constant")
        return v

    def _is_source_type(self, node):
        return node.t == "name" and node.a[0] in ("input.source",)

    # -------------------------------------------------------------- statements
    def run(self):
        toks, self.version = tokenize(self.code)
        v = self.version
        if v is None:
            self.warn("No //@version= line - parsed as Pine v5/v4 syntax.")
        elif v < 3:
            raise PineError(1, f"Pine v{v} is not supported - use //@version=4 or 5")
        elif v in (3, 6):
            self.warn(f"Pine v{v} detected - translated with v4/v5 rules; review the result.")
        lines = logical_lines(toks)
        if not lines:
            raise PineError(1, "script is empty")
        tree = build_tree(lines)
        self.exec_block(tree, [])
        if not self.header_seen:
            raise PineError(1, "no strategy() declaration found - a Pine strategy script "
                               "(strategy(\"name\", ...)) is required")
        return self.build()

    def exec_block(self, stmts, conds):
        for s in stmts:
            if s.kind == "assign":
                self.env = dict(self.env)
                self.env[s.name] = Binding(s.value, self.env, s.line, s.name)
            elif s.kind == "tuple":
                self.env = dict(self.env)
                shared = Binding(s.value, self.env, s.line, "[" + ", ".join(s.names) + "]")
                for i, nm in enumerate(s.names):
                    if nm == "_":
                        continue
                    self.env[nm] = _TupleSlot(shared, i)
            elif s.kind == "reassign":
                self.reassign(s, conds)
            elif s.kind == "expr":
                self.exec_expr(s, conds)
            elif s.kind == "if":
                self.exec_if(s, conds)
            else:
                raise PineError(s.line, f"unexpected '{s.kind}'")

    @staticmethod
    def has_effects(stmts):
        for s in stmts:
            if s.kind == "reassign":
                return True
            if s.kind == "expr" and s.value.t == "call" and s.value.a[0].startswith("strategy."):
                return True
            if s.kind in ("if", "elif", "else"):
                if Compiler.has_effects(s.body) or (s.orelse is not None and Compiler.has_effects([s.orelse])):
                    return True
        return False

    def exec_if(self, s, conds):
        if not self.has_effects([s]):
            self.note("if-blocks without strategy orders (plots, labels, alerts) are ignored.")
            return
        c = self.cond(self.eval(s.cond, self.env), s.line)
        saved = self.env
        self.exec_block(s.body, conds + [c])
        self.env = saved
        if s.orelse is not None:
            nc = conds + [self.negate(c)]
            o = s.orelse
            if o.kind == "elif":
                self.exec_if(o, nc)
            else:
                self.exec_block(o.body, nc)
                self.env = saved

    def reassign(self, s, conds):
        if s.name not in self.env:
            raise PineError(s.line, f"'{s.name}' is reassigned before being declared")
        if conds:
            raise PineError(s.line, f"conditional reassignment of '{s.name}' (stateful variables) "
                                    "cannot be translated")
        node = s.value
        if s.op != ":=":
            node = Node("bin", s.line, s.op[0], Node("name", s.line, s.name), node)
        v = self.eval(node, self.env)
        if not isinstance(v, Const):
            raise PineError(s.line, f"reassigning '{s.name}' with '{s.op}' to a changing value (stateful "
                                    "variables) cannot be translated - declare it directly with '='")
        self.env = dict(self.env)
        self.env[s.name] = v

    def exec_expr(self, s, conds):
        e = s.value
        ln = s.line
        if e.t != "call":
            self.warn(f"line {ln}: expression statement ignored.")
            return
        fname = e.a[0]
        if fname in ("indicator", "study"):
            raise PineError(ln, f"this is an {fname}() script - only strategy() scripts can be backtested. "
                                "Change it to strategy(...) and add strategy.entry()/strategy.close() calls.")
        if fname == "strategy":
            return self.header(e)
        if not self.header_seen and not fname.startswith("strategy."):
            pass
        if fname in IGNORED_CALLS or fname.startswith(IGNORED_PREFIXES):
            self.note(f"{fname}() ignored (plots, alerts and drawings have no effect on the backtest).")
            return
        if fname == "strategy.entry":
            return self.st_entry(e, conds)
        if fname == "strategy.order":
            self.warn(f"line {ln}: strategy.order() treated as strategy.entry() (no pyramiding).")
            return self.st_entry(e, conds)
        if fname == "strategy.close":
            b = self.bind(e, self.env, ["id", "when", "comment", "qty", "qty_percent", "alert_message",
                                        "immediately", "disable_alert"], 1)
            sid = self.eval(b["id"], self.env)
            if not isinstance(sid, Const) or not isinstance(sid.v, str):
                raise PineError(ln, "strategy.close() id must be a string")
            if "qty" in b or "qty_percent" in b:
                self.warn(f"line {ln}: partial close (qty/qty_percent) ignored - the whole position is closed.")
            self.closes.append((sid.v, self.when(b, conds, ln), ln))
            return
        if fname == "strategy.close_all":
            b = self.bind(e, self.env, ["when", "comment", "alert_message", "immediately", "disable_alert"], 0)
            self.close_all.append((self.when(b, conds, ln), ln))
            return
        if fname == "strategy.exit":
            return self.st_exit(e, conds)
        if fname in ("strategy.cancel", "strategy.cancel_all", "strategy.risk.allow_entry_in",
                     "strategy.risk.max_intraday_filled_orders", "strategy.risk.max_drawdown",
                     "strategy.risk.max_intraday_loss", "strategy.risk.max_position_size",
                     "strategy.risk.max_cons_loss_days"):
            self.note(f"{fname}() ignored.")
            return
        # any other call: evaluate for errors (e.g. forbidden functions) but ignore result
        self.warn(f"line {ln}: statement {fname}(...) ignored.")

    def header(self, e):
        ln = e.line
        if self.header_seen:
            raise PineError(ln, "duplicate strategy() declaration")
        self.header_seen = True
        _, args, kwargs = e.a
        t = kwargs.get("title") or (args[0] if args else None)
        if t is not None:
            v = self.eval(t, self.env)
            if isinstance(v, Const) and isinstance(v.v, str):
                self.title = v.v
        ignored = [k for k in kwargs if k not in ("title", "shorttitle", "overlay")]
        if ignored:
            self.note("strategy() settings ignored (" + ", ".join(sorted(ignored)) +
                      "): sizing uses the configured lots, capital and costs come from the backtest settings.")

    def when(self, b, conds, ln):
        c = Const(True)
        for x in conds:
            c = self.logic("and", c, x, ln)
        if "when" in b:
            c = self.logic("and", c, self.cond(self.eval(b["when"], self.env), ln), ln)
        return c

    def st_entry(self, e, conds):
        ln = e.line
        b = self.bind(e, self.env, ["id", "direction", "qty", "limit", "stop", "oca_name", "oca_type", "comment",
                                    "when", "alert_message", "disable_alert", "long"], 1, "strategy.entry")
        if "long" in b and "direction" not in b:
            b["direction"] = b.pop("long")
        if "direction" not in b:
            raise PineError(ln, "strategy.entry(): missing direction (strategy.long / strategy.short)")
        sid = self.eval(b["id"], self.env)
        if not isinstance(sid, Const) or not isinstance(sid.v, str):
            raise PineError(ln, "strategy.entry() id must be a string")
        d = self.eval(b["direction"], self.env)
        if isinstance(d, Side):
            side = d.s
        elif isinstance(d, Const) and isinstance(d.v, bool):
            side = "long" if d.v else "short"
        else:
            raise PineError(ln, "strategy.entry() direction must be strategy.long or strategy.short")
        if "limit" in b or "stop" in b:
            self.warn(f"line {ln}: entry limit/stop price ignored - entries are market orders at the next minute.")
        if "qty" in b:
            self.note("strategy.entry qty ignored - position size comes from the configured lots.")
        self.entries.append((side, sid.v, self.when(b, conds, ln), ln))

    def st_exit(self, e, conds):
        ln = e.line
        names = ["id", "from_entry", "qty", "qty_percent", "profit", "limit", "loss", "stop", "trail_price",
                 "trail_points", "trail_offset", "oca_name", "comment", "when", "alert_message",
                 "comment_profit", "comment_loss", "comment_trailing", "alert_profit", "alert_loss",
                 "alert_trailing", "disable_alert"]
        try:
            b = self.bind(e, self.env, names, 1, "strategy.exit")
            fe = None
            if "from_entry" in b:
                v = self.eval(b["from_entry"], self.env)
                if isinstance(v, Const) and isinstance(v.v, str) and v.v:
                    fe = v.v
            spec = {}
            tick = 0.05
            for k in ("profit", "loss", "trail_points", "trail_offset"):
                if k in b:
                    v = self.eval(b[k], self.env)
                    if not isinstance(v, Const) or not isinstance(v.v, (int, float)) or isinstance(v.v, bool):
                        raise PineError(ln, f"strategy.exit {k}= must be a constant number of ticks")
                    spec[k] = ("pts", round(float(v.v) * tick, 4))
            for k in ("stop", "limit"):
                if k in b:
                    v = self.eval(b[k], self.env)
                    if not isinstance(v, AvgLin):
                        raise PineError(ln, f"strategy.exit {k}= must be written relative to "
                                            "strategy.position_avg_price, e.g. strategy.position_avg_price * (1 - 0.01)")
                    spec[k] = v
            if "trail_price" in b:
                raise PineError(ln, "strategy.exit trail_price= is not supported (use trail_points/trail_offset)")
            if not spec:
                raise PineError(ln, "strategy.exit() without profit/loss/stop/limit/trail parameters")
            if conds or "when" in b:
                self.note("strategy.exit() conditions ignored - its stop/target levels apply to every trade.")
            self.exits.append((fe, spec, ln))
        except ValueError as ex:
            self.warn(f"{ex} - strategy.exit() skipped.")

    # -------------------------------------------------------------- config assembly
    def legs_for(self, side):
        d = self.defaults
        inst = d.get("instrument", "atm_options")
        lots = int(d.get("lots") or 1)
        expiry = d.get("expiry") or "weekly"
        if inst == "futures":
            typ, s = "FUT", ("BUY" if side == "long" else "SELL")
            if "monthly" not in expiry:
                expiry = "monthly"
        elif inst == "sell_options":
            typ, s = ("PE" if side == "long" else "CE"), "SELL"
        elif inst == "atm_options":
            typ, s = ("CE" if side == "long" else "PE"), "BUY"
        else:
            raise PineError(0, f"unknown instrument {inst!r} (atm_options | sell_options | futures)")
        return [{"side": s, "type": typ, "lots": lots, "expiry": expiry, "strikeMode": "atm", "strikeValue": 0,
                 "sl": 0, "slType": "pct", "tgt": 0, "tgtType": "pct", "trailX": 0, "trailY": 0,
                 "trailType": "pts", "reentries": 0, "reentryMode": "immediate"}]

    @staticmethod
    def to_block(conds):
        """list of Cond/Const -> BLOCK (OR of all)."""
        rules = []
        for c in conds:
            if isinstance(c, Const):
                if c.v:
                    return {"logic": "AND", "rules": [{"lhs": const_op(1), "op": "is_true", "rhs": const_op(0)}]}
                continue
            rules.append(c.c)
        if not rules:
            return None
        if len(rules) == 1:
            r = rules[0]
            return r if ("rules" in r and "logic" in r) else {"logic": "AND", "rules": [r]}
        return {"logic": "OR", "rules": rules}

    def apply_exit(self, leg, spec, side, ln):
        applied = []
        if "loss" in spec:
            leg["sl"], leg["slType"] = spec["loss"][1], "pts"
            applied.append(f"SL {spec['loss'][1]} pts")
        if "profit" in spec:
            leg["tgt"], leg["tgtType"] = spec["profit"][1], "pts"
            applied.append(f"target {spec['profit'][1]} pts")
        for k in ("stop", "limit"):
            if k not in spec:
                continue
            a = spec[k]
            loss_dir = (k == "stop") == (side == "long")  # price below avg for long stop / short limit
            if a.add and a.mult == 1:
                val, typ = (-a.add if loss_dir else a.add), "pts"
            elif not a.add:
                val, typ = ((1 - a.mult) * 100 if loss_dir else (a.mult - 1) * 100), "pct"
            else:
                self.warn(f"line {ln}: strategy.exit {k}= mixes a percentage and points - skipped.")
                continue
            val = round(val, 4)
            if val <= 0:
                self.warn(f"line {ln}: strategy.exit {k}= is on the wrong side of the entry price for a "
                          f"{side} position - skipped.")
                continue
            if k == "stop":
                leg["sl"], leg["slType"] = val, typ
                applied.append(f"SL {val}{'%' if typ == 'pct' else ' pts'}")
            else:
                leg["tgt"], leg["tgtType"] = val, typ
                applied.append(f"target {val}{'%' if typ == 'pct' else ' pts'}")
        if "trail_offset" in spec or "trail_points" in spec:
            off = spec.get("trail_offset", spec.get("trail_points"))[1]
            if off > 0:
                leg["trailX"], leg["trailY"], leg["trailType"] = off, off, "pts"
                if not leg.get("sl"):
                    leg["sl"], leg["slType"] = off, "pts"
                applied.append(f"trail {off} pts")
                self.warn(f"line {ln}: trailing stop approximated as 'every {off} pts in favour, trail SL by "
                          f"{off} pts'.")
        return applied

    def build(self):
        d = self.defaults
        if not self.entries:
            raise PineError(0, "no strategy.entry() calls found - nothing to trade")
        side_of = {}
        by_side = {"long": [], "short": []}
        for side, sid, c, ln in self.entries:
            side_of.setdefault(sid, side)
            if isinstance(c, Const) and not c.v:
                self.warn(f"line {ln}: entry '{sid}' can never trigger (condition is always false).")
                continue
            if isinstance(c, Const):
                self.warn(f"line {ln}: entry '{sid}' is unconditional - it fires on the first candle after "
                          "entryTime and again after every exit (up to maxTradesPerDay).")
            by_side[side].append(c)
        exits = {"long": [], "short": []}
        for sid, c, ln in self.closes:
            if sid not in side_of:
                self.warn(f"line {ln}: strategy.close('{sid}') does not match any strategy.entry id - ignored.")
                continue
            exits[side_of[sid]].append(c)
        for c, ln in self.close_all:
            exits["long"].append(c)
            exits["short"].append(c)

        cfg = {
            "name": self.title or "Pine strategy",
            "exch": d.get("exch", "NFO"), "und": d.get("und", "NIFTY"),
            "start": d.get("start", "2025-06-01"), "end": d.get("end", "2026-06-19"),
            "capital": d.get("capital", 1_000_000), "mode": "intraday",
            "timeframe": int(d.get("timeframe") or 5),
            "entryTime": "09:20", "exitTime": "15:15", "weekdays": [1, 2, 3, 4, 5],
            "maxTradesPerDay": 5, "exitOnOpposite": False, "legs": [],
            "costs": {"enabled": True, "brokerage": 20, "slippagePct": 0.1},
        }
        sides_present = [s for s in ("long", "short") if by_side[s]]
        if not sides_present:
            raise PineError(0, "no strategy.entry() can ever trigger")
        for s in sides_present:
            legs = self.legs_for(s)
            blk = self.to_block(by_side[s])
            xb = self.to_block(exits[s])
            for fe, spec, ln in self.exits:
                if fe is not None and fe not in side_of:
                    self.warn(f"line {ln}: strategy.exit from_entry '{fe}' does not match any entry - skipped.")
                    continue
                if fe is None or side_of[fe] == s:
                    applied = self.apply_exit(legs[0], spec, s, ln)
                    if applied:
                        self.note(f"strategy.exit on {s} side -> per-leg " + ", ".join(applied) + ". In QuantLab "
                                  "these levels apply to the traded option/future premium, not the underlying "
                                  "chart price" + (" (futures track the index closely)." if legs[0]["type"] == "FUT"
                                                   else " - option premiums move far more in % terms, so review them."))
            if s == "long":
                cfg["legs"] = legs
                cfg["entryConds"] = blk
                if xb:
                    cfg["exitConds"] = xb
            else:
                sh = {"legs": legs, "entryConds": blk}
                if xb:
                    sh["exitConds"] = xb
                cfg["short"] = sh
        if len(sides_present) == 2:
            cfg["exitOnOpposite"] = True
            self.note("Long and short entries found: exitOnOpposite is on (Pine reverses the position "
                      "on an opposite entry).")
        inst = d.get("instrument", "atm_options")
        self.note({"atm_options": "Long signals buy an ATM call, short signals buy an ATM put.",
                   "sell_options": "Long signals sell an ATM put, short signals sell an ATM call.",
                   "futures": "Long signals buy the future, short signals sell the future."}.get(inst, ""))
        self.note("Intraday: positions are squared off at 15:15; signals are checked from 09:20, "
                  "up to 5 trades per day.")
        cfg = copy.deepcopy(cfg)
        cfg["meta"] = {"source": "pine", "code": self.code}
        self.notes = [n for n in self.notes if n]
        return {"config": cfg, "notes": self.notes, "warnings": self.warnings}


class _TupleSlot(Binding):
    """Env entry for one element of a destructured tuple; shares the memo of the tuple binding."""

    def __init__(self, shared, index):
        super().__init__(shared.node, shared.env, shared.line, shared.name, index)
        self.shared = shared

    # memo lives on the shared binding
    @property
    def memo(self):
        return self.shared.memo

    @memo.setter
    def memo(self, v):
        if hasattr(self, "shared"):
            self.shared.memo = v


def compile_pine(code: str, defaults: dict) -> dict:
    """Translate a Pine Script strategy into a QuantLab config.
    Returns {"config", "notes", "warnings"}; raises ValueError("line N: ...") on unsupported input."""
    if not isinstance(code, str) or not code.strip():
        raise ValueError("line 1: empty Pine script")
    c = Compiler(code.replace("\r\n", "\n").replace("\t", "    "), defaults or {})
    out = c.run()
    out["config"]["meta"]["code"] = code
    return out
