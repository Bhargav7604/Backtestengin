"""Curated marketplace of ready-to-backtest strategies (popular Indian F&O algos + Bigul templates)."""
from __future__ import annotations

import copy
import json
import os

from .prompt import leg

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
STATS_CACHE = os.path.join(ROOT, "data", "marketplace_stats.json")

COSTS = {"enabled": True, "brokerage": 20, "slippagePct": 0.1}


def cfg(name, und="NIFTY", legs=(), **kw):
    c = {"name": name, "exch": "BFO" if und == "SENSEX" else "NFO", "und": und, "start": "2025-06-01", "end": "2026-06-19",
         "capital": 1_000_000, "mode": "intraday", "timeframe": 5, "entryTime": "09:20", "exitTime": "15:15",
         "weekdays": [1, 2, 3, 4, 5], "maxTradesPerDay": 1, "legs": list(legs), "overall": {}, "costs": COSTS,
         "meta": {"source": "marketplace"}}
    c.update(kw)
    return c


def ind(name, n=None, **kw):
    o = {"kind": "ind", "name": name}
    if n is not None:
        o["n"] = n
    o.update(kw)
    return o


def const(v):
    return {"kind": "const", "value": v}


def rule(lhs, op, rhs):
    return {"lhs": lhs, "op": op, "rhs": rhs}


def AND(*rules):
    return {"logic": "AND", "rules": list(rules)}


def OR(*rules):
    return {"logic": "OR", "rules": list(rules)}


ATM_BUY_CE = leg("BUY", "CE", sl=30, tgt=60)
ATM_BUY_PE = leg("BUY", "PE", sl=30, tgt=60)

STRATEGIES = [
    # ------------------------------------------------------------------ neutral / option selling
    dict(id="920-straddle", name="9:20 Short Straddle", category="Neutral", risk="High", style="Intraday",
         tags=["option selling", "theta", "classic"],
         description="The famous 9:20 AM ATM straddle sell on NIFTY with 25% SL on each leg. Exits at 3:15 PM.",
         config=cfg("9:20 Short Straddle", legs=[leg("SELL", "CE", sl=25), leg("SELL", "PE", sl=25)])),
    dict(id="straddle-reentry", name="Straddle + Re-entry at Cost", category="Neutral", risk="High", style="Intraday",
         tags=["option selling", "re-entry"],
         description="ATM straddle with 30% SL; a stopped-out leg re-enters when price comes back to cost (up to 2x).",
         config=cfg("Straddle re-entry", entryTime="09:30",
                    legs=[leg("SELL", "CE", sl=30, reentries=2, reentryMode="cost"),
                          leg("SELL", "PE", sl=30, reentries=2, reentryMode="cost")], overall={"sl": 9000})),
    dict(id="expiry-strangle", name="0-DTE Premium Strangle", category="Neutral", risk="High", style="Expiry day",
         tags=["expiry", "premium based", "option selling"],
         description="On NIFTY expiry day, sell the CE and PE closest to ₹20 premium at 9:30 with 50% SL.",
         config=cfg("0-DTE strangle", entryTime="09:30", dteMin=0, dteMax=0,
                    legs=[leg("SELL", "CE", strikeMode="premium", strikeValue=20, sl=50),
                          leg("SELL", "PE", strikeMode="premium", strikeValue=20, sl=50)])),
    dict(id="delta-strangle-lock", name="20-Delta Strangle with Profit Lock", category="Neutral", risk="Medium",
         style="Intraday", tags=["delta", "profit lock", "SENSEX"],
         description="SENSEX 20-delta strangle; locks ₹1,000 once MTM hits ₹3,000 and trails ₹500 per ₹1,000.",
         config=cfg("SENSEX delta strangle", und="SENSEX",
                    legs=[leg("SELL", "CE", strikeMode="delta", strikeValue=20, sl=40),
                          leg("SELL", "PE", strikeMode="delta", strikeValue=20, sl=40)],
                    overall={"sl": 8000, "lockAt": 3000, "lockProfit": 1000, "trailEvery": 1000, "trailBy": 500})),
    dict(id="weekly-iron-condor", name="Weekly Iron Condor (Positional)", category="Neutral", risk="Low",
         style="Positional", tags=["hedged", "defined risk", "positional"],
         description="Every Tuesday sell 3-strike OTM CE/PE, buy 8-strike wings; hold to expiry-day 3:00 PM.",
         config=cfg("Weekly iron condor", mode="positional", exitTime="15:00", weekdays=[2],
                    legs=[leg("SELL", "CE", strikeValue=3), leg("SELL", "PE", strikeValue=3),
                          leg("BUY", "CE", strikeValue=8), leg("BUY", "PE", strikeValue=8)])),
    dict(id="iron-fly-hedged", name="Hedged Iron Butterfly", category="Neutral", risk="Low", style="Intraday",
         tags=["hedged", "margin efficient"],
         description="Sell ATM straddle, buy 5-strike OTM wings for margin benefit; overall SL ₹6,000.",
         config=cfg("Iron butterfly", legs=[leg("SELL", "CE", sl=35), leg("SELL", "PE", sl=35),
                                           leg("BUY", "CE", strikeValue=5), leg("BUY", "PE", strikeValue=5)],
                    overall={"sl": 6000})),
    # ------------------------------------------------------------------ directional (indicator)
    dict(id="ema-rsi-momentum", name="EMA Cross + RSI Momentum", category="Directional", risk="Medium",
         style="Intraday", tags=["indicator", "long & short", "EMA", "RSI"],
         description="5-min 9/21 EMA crossover filtered by RSI(14) — buys ATM CE on bullish, ATM PE on bearish.",
         config=cfg("EMA RSI momentum", maxTradesPerDay=3, entryTime="09:30", lastEntryTime="14:30", exitOnOpposite=True,
                    legs=[ATM_BUY_CE],
                    entryConds=AND(rule(ind("EMA", 9), "crosses_above", ind("EMA", 21)), rule(ind("RSI", 14), ">", const(55))),
                    short={"legs": [ATM_BUY_PE],
                           "entryConds": AND(rule(ind("EMA", 9), "crosses_below", ind("EMA", 21)), rule(ind("RSI", 14), "<", const(45)))})),
    dict(id="supertrend-futures", name="Supertrend Futures Rider", category="Directional", risk="High",
         style="Intraday", tags=["futures", "trend following", "supertrend"],
         description="15-min Supertrend(10,3) flips drive long/short NIFTY futures, reversing on opposite signal.",
         config=cfg("Supertrend futures", timeframe=15, maxTradesPerDay=4, entryTime="09:30", exitOnOpposite=True,
                    legs=[leg("BUY", "FUT", expiry="monthly")],
                    entryConds=AND(rule(ind("SupertrendDir", 10, n2=3), "crosses_above", const(0))),
                    short={"legs": [leg("SELL", "FUT", expiry="monthly")],
                           "entryConds": AND(rule(ind("SupertrendDir", 10, n2=3), "crosses_below", const(0)))})),
    dict(id="orb-breakout", name="Opening Range Breakout", category="Directional", risk="Medium", style="Intraday",
         tags=["ORB", "breakout", "options buying"],
         description="Buys ATM CE on a break of the first-15-min high, ATM PE on a break of the low. One trade a day.",
         config=cfg("ORB", entryTime="09:30", lastEntryTime="13:00",
                    legs=[leg("BUY", "CE", sl=30, tgt=70, trailX=20, trailY=10)],
                    entryConds=AND(rule(ind("Close"), "crosses_above", ind("ORHigh", 3))),
                    short={"legs": [leg("BUY", "PE", sl=30, tgt=70, trailX=20, trailY=10)],
                           "entryConds": AND(rule(ind("Close"), "crosses_below", ind("ORLow", 3)))})),
    dict(id="vwap-reversion", name="VWAP Mean Reversion", category="Directional", risk="Medium", style="Intraday",
         tags=["VWAP", "mean reversion", "BANKNIFTY"],
         description="BANKNIFTY: fade 0.4% stretches from VWAP when RSI is extreme; exit on VWAP touch or 60 min.",
         config=cfg("VWAP reversion", und="BANKNIFTY", maxTradesPerDay=2, entryTime="10:00", lastEntryTime="14:00",
                    legs=[leg("BUY", "CE", expiry="monthly", sl=25)],
                    entryConds=AND(rule(ind("Close"), "<", {"kind": "expr", "op": "*", "args": [ind("VWAP"), const(0.996)]}),
                                   rule(ind("RSI", 14), "<", const(30))),
                    exitConds=OR(rule(ind("Close"), ">=", ind("VWAP")), rule({"kind": "pos", "field": "MinsInTrade"}, ">", const(60))),
                    short={"legs": [leg("BUY", "PE", expiry="monthly", sl=25)],
                           "entryConds": AND(rule(ind("Close"), ">", {"kind": "expr", "op": "*", "args": [ind("VWAP"), const(1.004)]}),
                                             rule(ind("RSI", 14), ">", const(70))),
                           "exitConds": OR(rule(ind("Close"), "<=", ind("VWAP")), rule({"kind": "pos", "field": "MinsInTrade"}, ">", const(60)))})),
    dict(id="bb-squeeze", name="Bollinger Breakout + ADX", category="Directional", risk="Medium", style="Intraday",
         tags=["bollinger", "ADX", "breakout"],
         description="Close breaks the upper/lower Bollinger band while ADX(14) > 20 — sells the opposite-side ATM option.",
         config=cfg("BB breakout", maxTradesPerDay=2, entryTime="09:45",
                    legs=[leg("SELL", "PE", sl=30, tgt=50)],
                    entryConds=AND(rule(ind("Close"), "crosses_above", ind("UpperBB", 20, n2=2)), rule(ind("ADX", 14), ">", const(20))),
                    short={"legs": [leg("SELL", "CE", sl=30, tgt=50)],
                           "entryConds": AND(rule(ind("Close"), "crosses_below", ind("LowerBB", 20, n2=2)), rule(ind("ADX", 14), ">", const(20)))})),
    dict(id="pdh-breakout", name="Previous-Day High/Low Break", category="Bullish", risk="Medium", style="Intraday",
         tags=["price action", "PDH"],
         description="Buy ATM CE when NIFTY crosses above yesterday's high after 9:30; SL 30%, trailing 15/10.",
         config=cfg("PDH breakout", entryTime="09:30", lastEntryTime="14:00",
                    legs=[leg("BUY", "CE", sl=30, trailX=15, trailY=10)],
                    entryConds=AND(rule(ind("Close"), "crosses_above", ind("PrevDayHigh"))))),
    # ------------------------------------------------------------------ Bigul templates (bullish / bearish)
    dict(id="bull-call-spread", name="Bull Call Spread", category="Bullish", risk="Low", style="Intraday",
         tags=["spread", "defined risk"],
         description="Buy ATM call, sell 3-strike OTM call. Profits from a moderate rise; capped risk and reward.",
         config=cfg("Bull call spread", legs=[leg("BUY", "CE"), leg("SELL", "CE", strikeValue=3)], overall={"sl": 4000})),
    dict(id="bull-put-spread", name="Bull Put Spread", category="Bullish", risk="Low", style="Intraday",
         tags=["spread", "credit"],
         description="Sell ATM put, buy 3-strike OTM put. Collects premium when the market holds up.",
         config=cfg("Bull put spread", legs=[leg("SELL", "PE", sl=40), leg("BUY", "PE", strikeValue=3)])),
    dict(id="bear-put-spread", name="Bear Put Spread", category="Bearish", risk="Low", style="Intraday",
         tags=["spread", "defined risk"],
         description="Buy ATM put, sell 3-strike OTM put. Profits from a moderate fall.",
         config=cfg("Bear put spread", legs=[leg("BUY", "PE"), leg("SELL", "PE", strikeValue=3)], overall={"sl": 4000})),
    dict(id="bear-call-spread", name="Bear Call Spread", category="Bearish", risk="Low", style="Intraday",
         tags=["spread", "credit"],
         description="Sell ATM call, buy 3-strike OTM call. Collects premium when the market stays below.",
         config=cfg("Bear call spread", legs=[leg("SELL", "CE", sl=40), leg("BUY", "CE", strikeValue=3)])),
    dict(id="long-straddle-event", name="Long Straddle (Volatility)", category="Neutral", risk="Medium",
         style="Intraday", tags=["long vol", "options buying"],
         description="Buy ATM CE + PE at 9:20 with 20% SL each — profits on large directional days.",
         config=cfg("Long straddle", legs=[leg("BUY", "CE", sl=20), leg("BUY", "PE", sl=20)])),
    dict(id="calendar-call", name="Call Calendar", category="Neutral", risk="Low", style="Intraday",
         tags=["calendar", "theta"],
         description="Sell current-week ATM call, buy next-week ATM call; benefits from faster near-term decay.",
         config=cfg("Call calendar", legs=[leg("SELL", "CE"), leg("BUY", "CE", expiry="next_weekly")], overall={"sl": 4000})),
]


def _stats_cache():
    try:
        with open(STATS_CACHE) as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return {}


def save_stats(sid: str, stats: dict):
    c = _stats_cache()
    keep = ("netPnl", "returnPct", "cagr", "winRate", "maxDD", "maxDDPct", "sharpe", "profitFactor", "trades")
    c[sid] = {k: stats.get(k) for k in keep}
    os.makedirs(os.path.dirname(STATS_CACHE), exist_ok=True)
    with open(STATS_CACHE, "w") as fh:
        json.dump(c, fh)


def listing():
    cache = _stats_cache()
    out = []
    for s in STRATEGIES:
        x = copy.deepcopy(s)
        x["config"]["meta"] = {"source": "marketplace", "marketplaceId": s["id"]}
        if s["id"] in cache:
            x["stats"] = cache[s["id"]]
        out.append(x)
    return out
