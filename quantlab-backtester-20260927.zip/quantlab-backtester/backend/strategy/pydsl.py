"""QuantLab Python DSL -> canonical strategy config (docs/STRATEGY_SCHEMA.md).

The DSL is *declarative*: a script is executed once, in a locked-down namespace, to build an
expression tree (operator-overloaded `Series` / `Condition` objects) that is serialised to the
JSON config the engine runs. No user Python runs per bar.

Security model (this runs on a server):
  * size caps (code length, tokens per statement, bracket depth, AST node count, AST depth);
  * `ast` whitelist - no imports (except the stripped `from quantlab import *`), no def/class/
    lambda/loops/if/with/comprehensions/f-strings/dicts/slices; every name, attribute and keyword
    starting with `_` is rejected and attribute access is limited to a fixed set of DSL fields;
  * every binary operator is rewritten to a guarded helper so plain numbers can't be used for
    huge-int / huge-string / list-repetition blow-ups;
  * executed with `{"__builtins__": {}}` plus the DSL namespace only;
  * expression trees are size/depth-capped so shared sub-trees can't explode on serialisation.

Public API: `compile_python(code, defaults) -> {"config", "notes", "warnings"}`, `DSL_REFERENCE`,
`EXAMPLE`. Errors raise `ValueError("line N: message")`.
"""
import ast
import io
import json
import math
import operator
import re
import sys
import tokenize
from datetime import date

MAX_CODE = 20_000
MAX_NODES = 5_000
MAX_AST_DEPTH = 60
MAX_TOKENS_PER_STMT = 400
MAX_BRACKET_DEPTH = 20
MAX_OPERAND_DEPTH = 64
MAX_TREE_SIZE = 4_000
FILENAME = "<strategy>"

FIELDS = ("Open", "High", "Low", "Close", "Volume", "HL2", "HLC3", "OHLC4")
SOURCE_INDICATORS = {"SMA", "EMA", "RMA", "WMA", "HMA", "DEMA", "TEMA", "VWMA", "RSI", "MACD", "MACDSignal",
                     "MACDHist", "UpperBB", "LowerBB", "MidBB", "Stdev", "Zscore", "ROC", "Momentum",
                     "Highest", "Lowest", "Change", "ChangePct", "CCI"}
TIMEFRAMES = (1, 3, 5, 10, 15, 30, 60)
EXPIRIES = ("weekly", "next_weekly", "far_weekly", "monthly", "next_monthly", "far_monthly")
REENTRY_MODES = ("immediate", "same_strike", "cost")
ALLOWED_ATTRS = {"line", "signal", "hist", "upper", "mid", "lower", "k", "d", "direction", "shift"}


class DSLError(Exception):
    """User-facing error; line number is attached by the compiler."""


def _user_line():
    """Line of the innermost user-script frame on the current stack (or None)."""
    f = sys._getframe(1)
    while f is not None:
        if f.f_code.co_filename == FILENAME:
            return f.f_lineno
        f = f.f_back
    return None


# ============================================================================ expression objects

def _is_num(x):
    return isinstance(x, (int, float)) and not isinstance(x, bool)


def _const(v):
    v = float(v)
    if not math.isfinite(v):
        raise DSLError("number is not finite (overflow or division by zero)")
    if v.is_integer() and abs(v) < 1e15:
        v = int(v)
    return {"kind": "const", "value": v}


_TIME_RE = re.compile(r"^([01]?\d|2[0-3]):([0-5]\d)$")


def _operand(x, what="value"):
    """Python value -> (operand dict, depth, size)."""
    if isinstance(x, Series):
        return x._op, x._depth, x._size
    if isinstance(x, Condition):
        raise DSLError(f"a condition can't be used as a {what}; compare series to get conditions, "
                       "combine conditions with & | ~")
    if isinstance(x, bool):
        raise DSLError(f"True/False can't be used as a {what}")
    if _is_num(x):
        return _const(x), 1, 1
    if isinstance(x, str) and _TIME_RE.match(x):
        h, m = map(int, x.split(":"))
        return _const(h * 100 + m), 1, 1
    raise DSLError(f"expected a number or series for {what}, got {type(x).__name__}")


def _mk(op, depth, size):
    if depth > MAX_OPERAND_DEPTH:
        raise DSLError("expression is nested too deeply")
    if size > MAX_TREE_SIZE:
        raise DSLError("expression is too large")
    return Series(op, depth, size)


_FOLD = {"+": operator.add, "-": operator.sub, "*": operator.mul, "/": operator.truediv, "pow": operator.pow,
         "max": max, "min": min, "neg": operator.neg, "abs": abs, "sqrt": math.sqrt, "log": math.log}


def _expr(fn, *args):
    ops = [_operand(a) for a in args]
    if any(o[0]["kind"] == "pos" for o in ops):
        raise DSLError("position fields (pnl, pnl_pct, minutes_in_trade) can't be used in arithmetic; "
                       "compare them directly, e.g. pnl() < -3000")
    if all(o[0]["kind"] == "const" for o in ops):
        try:
            return _mk(_const(_FOLD[fn](*[o[0]["value"] for o in ops])), 1, 1)
        except (ValueError, ZeroDivisionError, OverflowError):
            raise DSLError(f"invalid constant arithmetic ({fn})")
    return _mk({"kind": "expr", "op": fn, "args": [o[0] for o in ops], "offset": 0},
               1 + max(o[1] for o in ops), 1 + sum(o[2] for o in ops))


def _paren_hint(other):
    if isinstance(other, (bool, int, float)):
        return DSLError("& / | bind tighter than comparisons - wrap each comparison in parentheses: "
                        "(a > b) & (c < d)")
    return None


class Series:
    """A per-candle numeric series (compiles to an OPERAND)."""

    def __init__(self, op, depth=1, size=1):
        self._op = op
        self._depth = depth
        self._size = size

    # arithmetic
    def __add__(self, o): return _expr("+", self, o)
    def __radd__(self, o): return _expr("+", o, self)
    def __sub__(self, o): return _expr("-", self, o)
    def __rsub__(self, o): return _expr("-", o, self)
    def __mul__(self, o): return _expr("*", self, o)
    def __rmul__(self, o): return _expr("*", o, self)
    def __truediv__(self, o): return _expr("/", self, o)
    def __rtruediv__(self, o): return _expr("/", o, self)
    def __pow__(self, o): return _expr("pow", self, o)
    def __rpow__(self, o): return _expr("pow", o, self)
    def __neg__(self): return _expr("neg", self)
    def __pos__(self): return self
    def __abs__(self): return _expr("abs", self)

    # comparisons -> Condition
    def __gt__(self, o): return _cmp(self, ">", o)
    def __ge__(self, o): return _cmp(self, ">=", o)
    def __lt__(self, o): return _cmp(self, "<", o)
    def __le__(self, o): return _cmp(self, "<=", o)
    def __eq__(self, o): return _cmp(self, "==", o)
    def __ne__(self, o): return _cmp(self, "!=", o)
    __hash__ = None

    # a bare series used as a condition means "non-zero"
    def __and__(self, o): return _as_cond(self) & o
    def __rand__(self, o): raise (_paren_hint(o) or DSLError("& combines conditions"))
    def __or__(self, o): return _as_cond(self) | o
    def __ror__(self, o): raise (_paren_hint(o) or DSLError("| combines conditions"))
    def __invert__(self): return ~_as_cond(self)

    def __bool__(self):
        raise DSLError("a series has no True/False value here - use comparisons combined with & | ~ "
                       "(not `and`/`or`/`not`/`if`)")

    def __getitem__(self, k):
        return self.shift(k)

    def shift(self, k=1):
        if not _is_num(k) or int(k) != k or not 0 <= k <= 1000:
            raise DSLError("offset must be an integer between 0 and 1000, e.g. close[1]")
        k = int(k)
        op = self._op
        if k == 0 or op["kind"] == "const":
            return self
        if op["kind"] == "pos":
            raise DSLError("position fields can't be offset")
        if op["kind"] in ("ind", "expr"):
            return _mk({**op, "offset": int(op.get("offset") or 0) + k}, self._depth, self._size)
        # dt: wrap so the offset sits on a schema-sanctioned operand kind
        return _mk({"kind": "expr", "op": "+", "args": [op, {"kind": "const", "value": 0}], "offset": k},
                   self._depth + 1, self._size + 2)

    def __repr__(self):
        return "Series(%s)" % json.dumps(self._op)


class Multi(Series):
    """Indicator with several outputs; the object itself acts as its primary output."""

    def __init__(self, primary, **outs):
        super().__init__(primary._op, primary._depth, primary._size)
        for k, v in outs.items():
            object.__setattr__(self, k, v)


def _uses_pos(node):
    return '"kind": "pos"' in json.dumps(node, sort_keys=True)


class Condition:
    """Boolean per-candle condition (compiles to a RULE or BLOCK)."""

    def __init__(self, node, size=1):
        if size > MAX_TREE_SIZE:
            raise DSLError("condition is too large")
        self._node = node
        self._size = size

    def _combine(self, other, logic):
        if isinstance(other, Series):
            other = _as_cond(other)
        if not isinstance(other, Condition):
            raise (_paren_hint(other) or DSLError(f"can't combine a condition with {type(other).__name__}"))
        rules = []
        for n in (self._node, other._node):
            if "rules" in n and n.get("logic") == logic:
                rules.extend(n["rules"])
            else:
                rules.append(n)
        return Condition({"logic": logic, "rules": rules}, self._size + other._size + 1)

    def __and__(self, o): return self._combine(o, "AND")
    def __or__(self, o): return self._combine(o, "OR")

    def __rand__(self, o):
        if isinstance(o, Series):
            return _as_cond(o) & self
        raise (_paren_hint(o) or DSLError("& combines conditions"))

    def __ror__(self, o):
        if isinstance(o, Series):
            return _as_cond(o) | self
        raise (_paren_hint(o) or DSLError("| combines conditions"))

    def __invert__(self):
        n = self._node
        if "not" in n:
            return Condition(n["not"], self._size)
        if n.get("op") in ("is_true", "is_false"):
            return Condition({**n, "op": "is_false" if n["op"] == "is_true" else "is_true"}, self._size)
        return Condition({"not": n}, self._size + 1)

    def __bool__(self):
        raise DSLError("conditions can't be combined with Python `and`/`or`/`not` or used in `if` - "
                       "use & (and), | (or), ~ (not) with parentheses: (a > b) & ~(c < d)")

    __hash__ = None

    def __repr__(self):
        return "Condition(%s)" % json.dumps(self._node)


def _as_cond(x):
    if isinstance(x, Condition):
        return x
    if isinstance(x, Series):
        if x._op["kind"] == "pos":
            raise DSLError("compare position fields to a value, e.g. pnl() > 1000")
        return Condition({"lhs": x._op, "op": "is_true", "rhs": {"kind": "const", "value": 0}}, x._size + 1)
    if isinstance(x, bool):
        raise DSLError("pass a condition, not True/False")
    raise DSLError(f"expected a condition, got {type(x).__name__}")


def _cmp(a, op, b):
    la, _, sa = _operand(a, "comparison operand")
    rb, _, sb = _operand(b, "comparison operand")
    if la["kind"] == "const" and rb["kind"] == "const":
        raise DSLError("comparison between two constants is always true or false")
    return Condition({"lhs": la, "op": op, "rhs": rb}, sa + sb + 1)


def _cross(a, b, op, name):
    la, _, sa = _operand(a, f"{name}() argument")
    rb, _, sb = _operand(b, f"{name}() argument")
    if la["kind"] == "const" and rb["kind"] == "const":
        raise DSLError(f"{name}() needs at least one series")
    for o in (la, rb):
        if o["kind"] == "pos" and o["field"] != "PnL":
            raise DSLError(f"{name}() only supports pnl() among position fields")
    return Condition({"lhs": la, "op": op, "rhs": rb}, sa + sb + 1)


# ============================================================================ indicators

def _field(name):
    return Series({"kind": "ind", "name": name, "n": 0, "src": "Close", "n2": 0, "n3": 0, "offset": 0})


def _num(x, fn, what, lo=None, hi=None, integer=False):
    if not _is_num(x):
        raise DSLError(f"{fn}(): {what} must be a number")
    if not math.isfinite(x):
        raise DSLError(f"{fn}(): {what} must be finite")
    if integer:
        if int(x) != x:
            raise DSLError(f"{fn}(): {what} must be a whole number")
        x = int(x)
    if lo is not None and x < lo or hi is not None and x > hi:
        raise DSLError(f"{fn}(): {what} must be between {lo} and {hi}")
    return x


def _ind(name, src=None, n=0, n2=0, n3=0):
    op = {"kind": "ind", "name": name, "n": n, "src": "Close", "n2": n2, "n3": n3, "offset": 0}
    depth, size = 1, 1
    if src is not None:
        if not isinstance(src, Series):
            raise DSLError(f"source for {name} must be a series (e.g. close, hl2, rsi(close, 14))")
        s = src._op
        if s["kind"] == "pos":
            raise DSLError("position fields can't be indicator sources")
        if s["kind"] == "ind" and s["name"] in FIELDS and not s.get("offset") and not s.get("of"):
            op["src"] = s["name"]
        elif s["kind"] == "const":
            raise DSLError(f"source for {name} can't be a constant")
        else:
            if name not in SOURCE_INDICATORS:
                raise DSLError(f"{name} can't take a custom source")
            op["of"] = s
            depth, size = src._depth + 1, src._size + 1
    return _mk(op, depth, size)


def _src_len(fn, args, kw, default_n=None, lo=1, hi=5000):
    """Parse the common (src?, n) signature: ema(close, 9) / ema(9) / ema(src=hl2, n=9)."""
    kw = dict(kw)
    src = kw.pop("src", None)
    n = kw.pop("n", kw.pop("length", None))
    if kw:
        raise DSLError(f"{fn}() got unexpected argument(s): {', '.join(kw)}")
    args = list(args)
    if args and isinstance(args[0], (Series, Condition)):
        if src is not None:
            raise DSLError(f"{fn}(): source given twice")
        src = args.pop(0)
    if args:
        if n is not None:
            raise DSLError(f"{fn}(): length given twice")
        n = args.pop(0)
    if args:
        raise DSLError(f"{fn}(): too many arguments")
    if n is None:
        if default_n is None:
            raise DSLError(f"{fn}() needs a length, e.g. {fn}(close, 20)")
        n = default_n
    return src, _num(n, fn, "length", lo, hi, integer=True)


def _ma(name, fn):
    def f(*args, **kw):
        src, n = _src_len(fn, args, kw)
        return _ind(name, src, n)
    f.__name__ = fn
    return f


def _src_ind(name, fn, default_n=None):
    def f(*args, **kw):
        src, n = _src_len(fn, args, kw, default_n)
        return _ind(name, src, n)
    f.__name__ = fn
    return f


def rsi(*args, **kw):
    src, n = _src_len("rsi", args, kw, 14)
    return _ind("RSI", src, n)


def _split_src(args):
    args = list(args)
    src = args.pop(0) if args and isinstance(args[0], (Series, Condition)) else None
    return src, args


def macd(*args, src=None, fast=None, slow=None, signal=None):
    s0, rest = _split_src(args)
    src = s0 if s0 is not None else src
    if len(rest) > 3:
        raise DSLError("macd(): too many arguments - macd(src, fast, slow, signal)")
    vals = dict(zip(("fast", "slow", "signal"), rest))
    f = _num(vals.get("fast", fast if fast is not None else 12), "macd", "fast", 1, 1000, True)
    s = _num(vals.get("slow", slow if slow is not None else 26), "macd", "slow", 1, 1000, True)
    g = _num(vals.get("signal", signal if signal is not None else 9), "macd", "signal", 1, 1000, True)
    line = _ind("MACD", src, f, s, g)
    return Multi(line, line=line, signal=_ind("MACDSignal", src, f, s, g), hist=_ind("MACDHist", src, f, s, g))


def bbands(*args, src=None, n=None, mult=None):
    s0, rest = _split_src(args)
    src = s0 if s0 is not None else src
    if len(rest) > 2:
        raise DSLError("bbands(): too many arguments - bbands(src, n, mult)")
    vals = dict(zip(("n", "mult"), rest))
    n = _num(vals.get("n", n if n is not None else 20), "bbands", "length", 1, 5000, True)
    k = _num(vals.get("mult", mult if mult is not None else 2), "bbands", "mult", 0.01, 100)
    mid = _ind("MidBB", src, n, k)
    return Multi(mid, upper=_ind("UpperBB", src, n, k), mid=mid, lower=_ind("LowerBB", src, n, k))


def highest(*args, **kw):
    src, n = _src_len("highest", args, kw)
    return _ind("HighestHigh", None, n) if src is None else _ind("Highest", src, n)


def lowest(*args, **kw):
    src, n = _src_len("lowest", args, kw)
    return _ind("LowestLow", None, n) if src is None else _ind("Lowest", src, n)


def change(src=None):
    return _ind("Change", src, 1)


def change_pct(src=None):
    return _ind("ChangePct", src, 1)


def atr(n=14):
    return _ind("ATR", None, _num(n, "atr", "length", 1, 5000, True))


def supertrend(n=10, mult=3):
    n = _num(n, "supertrend", "length", 1, 5000, True)
    m = _num(mult, "supertrend", "mult", 0.01, 100)
    line = _ind("Supertrend", None, n, m)
    return Multi(line, line=line, direction=_ind("SupertrendDir", None, n, m))


def adx(n=14, smoothing=None):
    n = _num(n, "adx", "length", 1, 5000, True)
    sm = 0 if smoothing is None else _num(smoothing, "adx", "smoothing", 1, 5000, True)
    return _ind("ADX", None, n, sm)


def plus_di(n=14):
    return _ind("PlusDI", None, _num(n, "plus_di", "length", 1, 5000, True))


def minus_di(n=14):
    return _ind("MinusDI", None, _num(n, "minus_di", "length", 1, 5000, True))


def stoch(n=14, k=3, d=3):
    n = _num(n, "stoch", "length", 1, 5000, True)
    k = _num(k, "stoch", "k smoothing", 1, 500, True)
    d = _num(d, "stoch", "d smoothing", 1, 500, True)
    ks = _ind("StochK", None, n, k)
    return Multi(ks, k=ks, d=_ind("StochD", None, n, k, d))


def cci(*args, **kw):
    src, n = _src_len("cci", args, kw, 20)
    return _ind("CCI", src, n)


def williams_r(n=14):
    return _ind("WilliamsR", None, _num(n, "williams_r", "length", 1, 5000, True))


def obv():
    return _ind("OBV")


def vwap():
    return _ind("VWAP")


def vix():
    return _ind("VIX")


def _day(name):
    def f():
        return _ind(name)
    return f


def or_high(n=1):
    return _ind("ORHigh", None, _num(n, "or_high", "candles", 1, 375, True))


def or_low(n=1):
    return _ind("ORLow", None, _num(n, "or_low", "candles", 1, 375, True))


def _dt(field):
    def f():
        return Series({"kind": "dt", "field": field})
    return f


def _pos(field):
    def f():
        return Series({"kind": "pos", "field": field})
    return f


def crossover(a, b): return _cross(a, b, "crosses_above", "crossover")
def crossunder(a, b): return _cross(a, b, "crosses_below", "crossunder")
def cross(a, b): return _cross(a, b, "crosses", "cross")


def _abs(x):
    return abs(x) if _is_num(x) else _expr("abs", x)


def max_(a, b, *more):
    out = _expr("max", a, b)
    for m in more:
        out = _expr("max", out, m)
    return out


def min_(a, b, *more):
    out = _expr("min", a, b)
    for m in more:
        out = _expr("min", out, m)
    return out


def sqrt(x): return _expr("sqrt", x)
def log(x): return _expr("log", x)


# ============================================================================ legs / strategy helpers

class Strike:
    def __init__(self, mode, value):
        self._mode, self._value = mode, value

    def __repr__(self):
        return f"Strike({self._mode}, {self._value})"


class Level:
    def __init__(self, typ, value):
        self._type, self._value = typ, value

    def __repr__(self):
        return f"{self._type}({self._value})"


def OTM(n=1): return Strike("atm", _num(n, "OTM", "steps", 0, 50, True))
def ITM(n=1): return Strike("atm", -_num(n, "ITM", "steps", 0, 50, True))
def premium(x): return Strike("premium", _num(x, "premium", "price", 0.05, 1e6))
def premium_gte(x): return Strike("premium_gte", _num(x, "premium_gte", "price", 0.05, 1e6))
def premium_lte(x): return Strike("premium_lte", _num(x, "premium_lte", "price", 0.05, 1e6))
def delta(x): return Strike("delta", _num(x, "delta", "delta", 1, 100))
def pct_otm(x): return Strike("pct", _num(x, "pct_otm", "percent", -50, 50))
def pct(x): return Level("pct", _num(x, "pct", "value", 0, 1e6))
def pts(x): return Level("pts", _num(x, "pts", "value", 0, 1e7))


def _level(x, fn, what):
    if x is None:
        return None
    if isinstance(x, Level):
        return x
    if _is_num(x):
        return Level("pct", _num(x, fn, what, 0, 1e6))
    raise DSLError(f"{fn}(): {what} must be pct(x) or pts(x)")


def _time(s, what):
    if not isinstance(s, str) or not _TIME_RE.match(s):
        raise DSLError(f"{what} must be a 'HH:MM' string")
    h, m = map(int, s.split(":"))
    if not (9 * 60 + 15 <= h * 60 + m <= 15 * 60 + 30):
        raise DSLError(f"{what} must be within market hours 09:15-15:30")
    return "%02d:%02d" % (h, m)


def _date(s, what):
    try:
        return date.fromisoformat(s).isoformat()
    except (TypeError, ValueError):
        raise DSLError(f"{what} must be a 'YYYY-MM-DD' string")


class _State:
    def __init__(self):
        self.strat = None
        self.cond = {}      # key -> (Condition, line)
        self.legs = []
        self.short_legs = []
        self.short_leg_line = None
        self.opposite = None
        self.overall = None
        self.costs = None
        self.notes = []
        self.warnings = []


def _namespace(st: _State, defaults: dict):
    def strategy(name=None, underlying=None, exchange=None, timeframe=None, start=None, end=None, capital=None,
                 mode=None, entry_time=None, exit_time=None, last_entry_time=None, max_trades_per_day=None,
                 weekdays=None, dte=None, reenter_after_exit=None, exit_days_before_expiry=None,
                 exit_all_on_leg_sl=None):
        if st.strat is not None:
            raise DSLError("strategy() can only be called once")
        s = {}
        if name is not None:
            if not isinstance(name, str) or len(name) > 120:
                raise DSLError("strategy name must be a string (max 120 chars)")
            s["name"] = name
        if underlying is not None:
            if not isinstance(underlying, str) or not re.match(r"^[A-Z0-9&\-_]{1,30}$", underlying.upper()):
                raise DSLError("underlying must be a symbol string like 'NIFTY'")
            s["und"] = underlying.upper()
        if exchange is not None:
            if not isinstance(exchange, str) or exchange.upper() not in ("NFO", "BFO"):
                raise DSLError("exchange must be 'NFO' or 'BFO'")
            s["exch"] = exchange.upper()
        if timeframe is not None:
            if timeframe not in TIMEFRAMES or isinstance(timeframe, bool):
                raise DSLError(f"timeframe must be one of {', '.join(map(str, TIMEFRAMES))} (minutes)")
            s["timeframe"] = int(timeframe)
        if start is not None:
            s["start"] = _date(start, "start")
        if end is not None:
            s["end"] = _date(end, "end")
        if capital is not None:
            s["capital"] = _num(capital, "strategy", "capital", 1000, 1e11)
        if mode is not None:
            if mode not in ("intraday", "positional"):
                raise DSLError("mode must be 'intraday' or 'positional'")
            s["mode"] = mode
        if entry_time is not None:
            s["entryTime"] = _time(entry_time, "entry_time")
        if exit_time is not None:
            s["exitTime"] = _time(exit_time, "exit_time")
        if last_entry_time is not None:
            s["lastEntryTime"] = _time(last_entry_time, "last_entry_time")
        if max_trades_per_day is not None:
            s["maxTradesPerDay"] = _num(max_trades_per_day, "strategy", "max_trades_per_day", 1, 100, True)
        if weekdays is not None:
            if not isinstance(weekdays, (list, tuple)) or not weekdays or \
                    any(not _is_num(w) or w not in range(1, 8) for w in weekdays):
                raise DSLError("weekdays must be a list like [MON, TUE, WED, THU, FRI]")
            s["weekdays"] = sorted(set(int(w) for w in weekdays))
        if dte is not None:
            if not isinstance(dte, (list, tuple)) or len(dte) != 2:
                raise DSLError("dte must be a (min, max) pair, e.g. dte=(0, 7); use None for open ends")
            lo, hi = (None if v is None else _num(v, "strategy", "dte", 0, 400, True) for v in dte)
            if lo is not None and hi is not None and lo > hi:
                raise DSLError("dte min is greater than max")
            s["dteMin"], s["dteMax"] = lo, hi
        if reenter_after_exit is not None:
            s["reenterAfterExit"] = bool(reenter_after_exit is True)
        if exit_days_before_expiry is not None:
            s["exitDaysBeforeExpiry"] = _num(exit_days_before_expiry, "strategy", "exit_days_before_expiry",
                                             0, 30, True)
        if exit_all_on_leg_sl is not None:
            s["exitAllOnLegSl"] = exit_all_on_leg_sl is True
        st.strat = s

    def _setter(key, entry):
        def f(cond):
            if key in st.cond:
                raise DSLError(f"{key}() already called - combine conditions with & or | in one call")
            c = _as_cond(cond)
            if entry and _uses_pos(c._node):
                raise DSLError("pnl(), pnl_pct() and minutes_in_trade() are only allowed in exit conditions")
            st.cond[key] = (c, _user_line())
        f.__name__ = key
        return f

    def _leg(side, type, strike=None, expiry=None, lots=None, sl=None, target=None, trail=None, reentries=0,
             reentry="immediate", fn="leg"):
        sd = str(side).upper() if isinstance(side, str) else None
        if sd not in ("BUY", "SELL"):
            raise DSLError(f"{fn}(): side must be BUY or SELL")
        ty = str(type).upper() if isinstance(type, str) else None
        if ty not in ("CE", "PE", "FUT"):
            raise DSLError(f"{fn}(): type must be CE, PE or FUT")
        if strike is None:
            strike = Strike("atm", 0)
        if not isinstance(strike, Strike):
            raise DSLError(f"{fn}(): strike must be ATM, OTM(n), ITM(n), premium(x), premium_gte(x), "
                           "premium_lte(x), delta(x) or pct_otm(x)")
        exp = expiry if expiry is not None else (defaults.get("expiry") or "weekly")
        if not isinstance(exp, str) or exp.lower() not in EXPIRIES:
            raise DSLError(f"{fn}(): expiry must be one of WEEKLY, NEXT_WEEKLY, FAR_WEEKLY, MONTHLY, "
                           "NEXT_MONTHLY, FAR_MONTHLY")
        exp = exp.lower()
        if ty == "FUT" and exp.endswith("weekly"):
            if expiry is not None:
                st.notes.append(f"line {_user_line()}: futures have monthly expiries - using MONTHLY")
            exp = "monthly"
        lots = defaults.get("lots") or 1 if lots is None else lots
        lots = _num(lots, fn, "lots", 1, 1000, True)
        slv, tgv = _level(sl, fn, "sl"), _level(target, fn, "target")
        out = {"side": sd, "type": ty, "lots": lots, "expiry": exp,
               "strikeMode": strike._mode if ty != "FUT" else "atm",
               "strikeValue": strike._value if ty != "FUT" else 0,
               "sl": slv._value if slv else 0, "slType": slv._type if slv else "pct",
               "tgt": tgv._value if tgv else 0, "tgtType": tgv._type if tgv else "pct",
               "trailX": 0, "trailY": 0, "trailType": "pct",
               "reentries": _num(reentries, fn, "reentries", 0, 20, True),
               "reentryMode": reentry}
        if ty == "FUT" and (strike._mode != "atm" or strike._value != 0):
            st.warnings.append(f"line {_user_line()}: strike is ignored for futures legs")
        if trail is not None:
            if not isinstance(trail, (tuple, list)) or len(trail) != 2:
                raise DSLError(f"{fn}(): trail must be (every, by), e.g. trail=(pct(10), pct(5))")
            x, y = _level(trail[0], fn, "trail"), _level(trail[1], fn, "trail")
            if x._type != y._type:
                raise DSLError(f"{fn}(): both trail values must use the same unit (pct or pts)")
            out.update(trailX=x._value, trailY=y._value, trailType=x._type)
            if not slv:
                st.warnings.append(f"line {_user_line()}: trail has no effect without an sl")
        if reentry not in REENTRY_MODES:
            raise DSLError(f"{fn}(): reentry must be one of {', '.join(REENTRY_MODES)}")
        return out

    def leg(side, type, strike=None, expiry=None, lots=None, sl=None, target=None, trail=None, reentries=0,
            reentry="immediate"):
        if len(st.legs) >= 8:
            raise DSLError("at most 8 legs")
        st.legs.append(_leg(side, type, strike, expiry, lots, sl, target, trail, reentries, reentry))

    def short_leg(side, type, strike=None, expiry=None, lots=None, sl=None, target=None, trail=None,
                  reentries=0, reentry="immediate"):
        if len(st.short_legs) >= 8:
            raise DSLError("at most 8 short legs")
        st.short_leg_line = st.short_leg_line or _user_line()
        st.short_legs.append(_leg(side, type, strike, expiry, lots, sl, target, trail, reentries, reentry,
                                  fn="short_leg"))

    def exit_on_opposite(flag=True):
        st.opposite = flag is True

    def overall(stop_loss=None, target=None, lock_at=None, lock_profit=None, trail_every=None, trail_by=None,
                sl_pct_capital=None):
        o = {}
        for k, v, hi in (("sl", stop_loss, 1e9), ("tgt", target, 1e9), ("lockAt", lock_at, 1e9),
                         ("lockProfit", lock_profit, 1e9), ("trailEvery", trail_every, 1e9),
                         ("trailBy", trail_by, 1e9), ("slPctCapital", sl_pct_capital, 100)):
            if v is not None:
                o[k] = abs(_num(v, "overall", k, -1e9, hi))
        if ("lockAt" in o) != ("lockProfit" in o):
            st.warnings.append(f"line {_user_line()}: lock_at and lock_profit work together - set both")
        if ("trailEvery" in o) != ("trailBy" in o):
            st.warnings.append(f"line {_user_line()}: trail_every and trail_by work together - set both")
        st.overall = o

    def costs(brokerage=20, slippage_pct=0.1, enabled=True):
        st.costs = {"enabled": enabled is True, "brokerage": _num(brokerage, "costs", "brokerage", 0, 10000),
                    "slippagePct": _num(slippage_pct, "costs", "slippage_pct", 0, 10)}

    ns = {
        # config
        "strategy": strategy, "leg": leg, "short_leg": short_leg, "overall": overall, "costs": costs,
        "long_when": _setter("long_when", True), "short_when": _setter("short_when", True),
        "long_exit_when": _setter("long_exit_when", False), "short_exit_when": _setter("short_exit_when", False),
        "exit_on_opposite": exit_on_opposite,
        "BUY": "BUY", "SELL": "SELL", "CE": "CE", "PE": "PE", "FUT": "FUT",
        "WEEKLY": "weekly", "NEXT_WEEKLY": "next_weekly", "FAR_WEEKLY": "far_weekly",
        "MONTHLY": "monthly", "NEXT_MONTHLY": "next_monthly", "FAR_MONTHLY": "far_monthly",
        "MON": 1, "TUE": 2, "WED": 3, "THU": 4, "FRI": 5, "SAT": 6, "SUN": 7,
        "ATM": Strike("atm", 0), "OTM": OTM, "ITM": ITM, "premium": premium, "premium_gte": premium_gte,
        "premium_lte": premium_lte, "delta": delta, "pct_otm": pct_otm, "pct": pct, "pts": pts,
        # price
        "open": _field("Open"), "high": _field("High"), "low": _field("Low"), "close": _field("Close"),
        "volume": _field("Volume"), "hl2": _field("HL2"), "hlc3": _field("HLC3"), "ohlc4": _field("OHLC4"),
        # indicators
        "sma": _ma("SMA", "sma"), "ema": _ma("EMA", "ema"), "rma": _ma("RMA", "rma"), "wma": _ma("WMA", "wma"),
        "hma": _ma("HMA", "hma"), "dema": _ma("DEMA", "dema"), "tema": _ma("TEMA", "tema"),
        "vwma": _ma("VWMA", "vwma"), "rsi": rsi, "macd": macd, "bbands": bbands,
        "stdev": _src_ind("Stdev", "stdev"), "zscore": _src_ind("Zscore", "zscore"),
        "roc": _src_ind("ROC", "roc"), "momentum": _src_ind("Momentum", "momentum"),
        "highest": highest, "lowest": lowest, "change": change, "change_pct": change_pct,
        "atr": atr, "supertrend": supertrend, "adx": adx, "plus_di": plus_di, "minus_di": minus_di,
        "stoch": stoch, "cci": cci, "williams_r": williams_r, "obv": obv, "vwap": vwap, "vix": vix,
        "day_open": _day("DayOpen"), "day_high": _day("DayHigh"), "day_low": _day("DayLow"),
        "prev_day_high": _day("PrevDayHigh"), "prev_day_low": _day("PrevDayLow"),
        "prev_day_close": _day("PrevDayClose"), "or_high": or_high, "or_low": or_low,
        "time_of_day": _dt("Time"), "hour": _dt("Hour"), "minute": _dt("Minute"), "weekday": _dt("WeekDay"),
        "crossover": crossover, "crossunder": crossunder, "cross": cross,
        "pnl": _pos("PnL"), "pnl_pct": _pos("PnLpct"), "minutes_in_trade": _pos("MinsInTrade"),
        "abs": _abs, "max_": max_, "min_": min_, "max": max_, "min": min_, "sqrt": sqrt, "log": log,
        "True": True, "False": False, "None": None,
    }
    return ns


# ============================================================================ sandbox

_BINOPS = {ast.Add: "+", ast.Sub: "-", ast.Mult: "*", ast.Div: "/", ast.Pow: "**", ast.BitAnd: "&",
           ast.BitOr: "|"}
_PYOPS = {"+": operator.add, "-": operator.sub, "*": operator.mul, "/": operator.truediv, "**": operator.pow,
          "&": operator.and_, "|": operator.or_}
_ALLOWED = (ast.Module, ast.Expr, ast.Assign, ast.Pass, ast.Call, ast.Name, ast.Constant, ast.BinOp,
            ast.UnaryOp, ast.Compare, ast.Subscript, ast.Attribute, ast.Tuple, ast.List, ast.keyword,
            ast.Load, ast.Store, ast.ImportFrom, ast.alias,
            ast.UAdd, ast.USub, ast.Invert, ast.Eq, ast.NotEq, ast.Lt, ast.LtE, ast.Gt, ast.GtE) + \
    tuple(_BINOPS)
_FRIENDLY = {
    ast.BoolOp: "use & | ~ instead of and / or / not (with parentheses around comparisons)",
    ast.If: "`if` isn't supported - build conditions with & | ~ and pass them to long_when()/short_when()",
    ast.IfExp: "`x if c else y` isn't supported - build conditions with & | ~",
    ast.For: "loops aren't supported - the DSL is declarative",
    ast.While: "loops aren't supported - the DSL is declarative",
    ast.FunctionDef: "defining functions isn't supported - assign expressions to variables instead",
    ast.Lambda: "lambda isn't supported - assign expressions to variables instead",
    ast.ClassDef: "classes aren't supported",
    ast.Import: "only `from quantlab import *` is allowed",
    ast.AugAssign: "augmented assignment (+=) isn't supported - write x = x + 1",
    ast.Dict: "dicts aren't supported",
    ast.Slice: "slices aren't supported - use x[1] for the previous candle",
    ast.JoinedStr: "f-strings aren't supported",
    ast.Starred: "*args aren't supported",
    ast.With: "`with` isn't supported",
    ast.Try: "`try` isn't supported",
}


def _pysafe_binop(sym, a, b):
    """All user binary operators route here: DSL objects use their overloads; plain values must be
    finite numbers (no big-int / string / list blow-ups)."""
    dsl = (Series, Condition)
    if isinstance(a, dsl) or isinstance(b, dsl):
        return _PYOPS[sym](a, b)
    if sym in ("&", "|"):
        raise DSLError("& and | combine conditions - wrap each comparison in parentheses: (a > b) & (c < d)")
    if not (_is_num(a) and _is_num(b)):
        raise DSLError(f"`{sym}` needs numbers or series, got {type(a).__name__} and {type(b).__name__}")
    try:
        r = _PYOPS[sym](float(a), float(b))
    except ZeroDivisionError:
        raise DSLError("division by zero")
    except OverflowError:
        raise DSLError("number too large")
    if isinstance(r, complex) or not math.isfinite(r):
        raise DSLError("invalid arithmetic result")
    return int(r) if r.is_integer() and isinstance(a, int) and isinstance(b, int) and abs(r) < 1e15 else r


class _Rewrite(ast.NodeTransformer):
    def visit_BinOp(self, node):
        self.generic_visit(node)
        call = ast.Call(func=ast.Name(id="__ql_binop__", ctx=ast.Load()),
                        args=[ast.Constant(value=_BINOPS[type(node.op)]), node.left, node.right], keywords=[])
        return ast.copy_location(call, node)


def _err(line, msg):
    return ValueError(f"line {line or 1}: {msg}")


def _prescan(code):
    if not isinstance(code, str):
        raise _err(1, "code must be a string")
    if len(code) > MAX_CODE:
        raise _err(1, f"script too long ({len(code)} chars, max {MAX_CODE})")
    if "\x00" in code:
        raise _err(1, "invalid character")
    depth, ntok = 0, 0
    try:
        for tok in tokenize.generate_tokens(io.StringIO(code).readline):
            if tok.type in (tokenize.NEWLINE, tokenize.ENDMARKER):
                ntok = 0
                continue
            ntok += 1
            if ntok > MAX_TOKENS_PER_STMT:
                raise _err(tok.start[0], "statement too long - split it across variables")
            if tok.type == tokenize.OP:
                if tok.string in "([{":
                    depth += 1
                    if depth > MAX_BRACKET_DEPTH:
                        raise _err(tok.start[0], "brackets nested too deeply")
                elif tok.string in ")]}":
                    depth = max(0, depth - 1)
    except (tokenize.TokenError, IndentationError, SyntaxError):
        pass  # ast.parse below produces the proper syntax error


def _validate(tree):
    n = 0
    for _ in ast.walk(tree):
        n += 1
        if n > MAX_NODES:
            raise _err(1, f"script too complex (more than {MAX_NODES} syntax nodes)")

    def chk(node, line, depth):
        line = getattr(node, "lineno", None) or line
        if depth > MAX_AST_DEPTH:
            raise _err(line, "expression nested too deeply - split it across variables")
        t = type(node)
        if t in _FRIENDLY:
            raise _err(line, _FRIENDLY[t])
        if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.Not):
            raise _err(line, "use ~ instead of `not` (e.g. ~(a > b))")
        if not isinstance(node, _ALLOWED):
            name = t.__name__
            if isinstance(node, ast.operator):
                raise _err(line, f"operator {name} isn't supported (use + - * / **)")
            raise _err(line, f"{name} syntax isn't supported in the strategy DSL")
        if isinstance(node, ast.ImportFrom):
            if node.module != "quantlab" or node.level or [a.name for a in node.names] != ["*"]:
                raise _err(line, "only `from quantlab import *` is allowed")
            return
        if isinstance(node, ast.Name) and node.id.startswith("_"):
            raise _err(line, f"names starting with '_' aren't allowed ({node.id})")
        if isinstance(node, ast.Attribute):
            if node.attr.startswith("_") or node.attr not in ALLOWED_ATTRS:
                raise _err(line, f"attribute '.{node.attr}' isn't allowed "
                                 f"(available: {', '.join(sorted(ALLOWED_ATTRS))})")
        if isinstance(node, ast.keyword) and (node.arg is None or node.arg.startswith("_")):
            raise _err(line, "**kwargs and '_' keywords aren't allowed")
        if isinstance(node, ast.Call) and not isinstance(node.func, (ast.Name, ast.Attribute)):
            raise _err(line, "only named functions can be called")
        if isinstance(node, ast.Compare) and len(node.ops) > 1:
            raise _err(line, "chained comparisons aren't supported - write (a < b) & (b < c); "
                             "remember & binds tighter than > so wrap comparisons in parentheses")
        if isinstance(node, ast.Subscript):
            s = node.slice
            if isinstance(s, ast.Slice):
                raise _err(line, _FRIENDLY[ast.Slice])
            if not (isinstance(s, ast.Constant) and isinstance(s.value, int) and not isinstance(s.value, bool)):
                raise _err(line, "offsets must be a constant integer, e.g. close[1]")
        if isinstance(node, ast.Assign):
            for tg in node.targets:
                elts = tg.elts if isinstance(tg, (ast.Tuple, ast.List)) else [tg]
                if not all(isinstance(e, ast.Name) for e in elts):
                    raise _err(line, "assign only to plain variable names")
        if isinstance(node, ast.Constant) and not isinstance(node.value, (int, float, str, bool, type(None))):
            raise _err(line, f"{type(node.value).__name__} literals aren't supported")
        if isinstance(node, ast.Constant) and isinstance(node.value, str) and len(node.value) > 500:
            raise _err(line, "string too long")
        for child in ast.iter_child_nodes(node):
            chk(child, line, depth + 1)

    chk(tree, 1, 0)
    tree.body = [s for s in tree.body if not isinstance(s, ast.ImportFrom)]


def _exc_line(exc):
    line, tb = None, exc.__traceback__
    while tb is not None:
        if tb.tb_frame.f_code.co_filename == FILENAME:
            line = tb.tb_lineno
        tb = tb.tb_next
    return line


def _run(code, ns):
    _prescan(code)
    try:
        tree = ast.parse(code, filename=FILENAME, mode="exec")
    except SyntaxError as e:
        raise _err(e.lineno, f"syntax error: {e.msg}")
    except (RecursionError, MemoryError, ValueError):
        raise _err(1, "script too complex to parse")
    _validate(tree)
    tree = ast.fix_missing_locations(_Rewrite().visit(tree))
    glb = {"__builtins__": {}, "__ql_binop__": _pysafe_binop}
    glb.update(ns)
    try:
        exec(compile(tree, FILENAME, "exec"), glb)  # noqa: S102 - sandboxed, see module docstring
    except DSLError as e:
        raise _err(_exc_line(e), str(e))
    except NameError as e:
        m = re.search(r"name '([^']+)'", str(e))
        raise _err(_exc_line(e), f"unknown name '{m.group(1) if m else e}'")
    except AttributeError as e:
        m = re.search(r"attribute '([^']+)'", str(e))
        raise _err(_exc_line(e), f"no attribute '.{m.group(1) if m else '?'}' here "
                                 "(macd: .line .signal .hist, bbands: .upper .mid .lower, "
                                 "supertrend: .line .direction, stoch: .k .d)")
    except TypeError as e:
        raise _err(_exc_line(e), f"invalid call or operation: {e}")
    except (IndexError, ValueError, ZeroDivisionError, OverflowError) as e:
        raise _err(_exc_line(e), str(e) or type(e).__name__)
    except RecursionError:
        raise _err(1, "script too complex")


# ============================================================================ compile

def _block(c: Condition):
    n = c._node
    return n if "rules" in n else {"logic": "AND", "rules": [n]}


def _default_leg(instrument, side, defaults):
    lots = int(defaults.get("lots") or 1)
    exp = defaults.get("expiry") or "weekly"
    if exp not in EXPIRIES:
        exp = "weekly"
    base = {"lots": lots, "expiry": exp, "strikeMode": "atm", "strikeValue": 0, "sl": 0, "slType": "pct",
            "tgt": 0, "tgtType": "pct", "trailX": 0, "trailY": 0, "trailType": "pct", "reentries": 0,
            "reentryMode": "immediate"}
    if instrument == "futures":
        return {**base, "side": "BUY" if side == "long" else "SELL", "type": "FUT", "expiry": "monthly"}
    if instrument == "sell_options":
        return {**base, "side": "SELL", "type": "PE" if side == "long" else "CE"}
    return {**base, "side": "BUY", "type": "CE" if side == "long" else "PE"}


def _describe_leg(l):
    if l["type"] == "FUT":
        return f"{l['side']} FUT {l['expiry']} x{l['lots']}"
    sm, sv = l["strikeMode"], l["strikeValue"]
    k = ("ATM" if sv == 0 else (f"OTM{sv}" if sv > 0 else f"ITM{-sv}")) if sm == "atm" else f"{sm} {sv}"
    return f"{l['side']} {k} {l['type']} {l['expiry']} x{l['lots']}"


def compile_python(code: str, defaults: dict) -> dict:
    """Compile a QuantLab Python DSL script to the canonical strategy config."""
    defaults = dict(defaults or {})
    st = _State()
    _run(code, _namespace(st, defaults))

    s = st.strat or {}
    if st.strat is None:
        st.notes.append("no strategy(...) call - using the current defaults for underlying, dates and capital")
    notes, warns = st.notes, st.warnings
    long_e, long_x = st.cond.get("long_when"), st.cond.get("long_exit_when")
    short_e, short_x = st.cond.get("short_when"), st.cond.get("short_exit_when")
    signal = bool(long_e or short_e)
    instrument = defaults.get("instrument") or "atm_options"

    legs = list(st.legs)
    short_legs = list(st.short_legs)
    if long_e and not legs:
        legs = [_default_leg(instrument, "long", defaults)]
        notes.append(f"no leg() given - long signal trades {_describe_leg(legs[0])} ({instrument})")
    if short_e and not short_legs:
        short_legs = [_default_leg(instrument, "short", defaults)]
        notes.append(f"no short_leg() given - short signal trades {_describe_leg(short_legs[0])} ({instrument})")
    if not signal and not legs:
        if short_legs:
            raise _err(st.short_leg_line, "short_leg() needs a short_when(...) signal; for time-based "
                                          "entries use leg(...)")
        raise _err(1, "nothing to trade - add leg(...) for a time-based entry, or long_when(...)/short_when(...)")
    if short_legs and not short_e:
        warns.append("short_leg() ignored - there is no short_when(...) signal")
        short_legs = []
    if legs and signal and not long_e:
        warns.append("leg() ignored - there is no long_when(...) signal (only short_when)")
        legs = []
    if long_x and not long_e and signal:
        warns.append("long_exit_when() has no effect without long_when()")
    if short_x and not short_e:
        warns.append("short_exit_when() has no effect without short_when()")
    if st.opposite and not (long_e and short_e):
        warns.append("exit_on_opposite() needs both long_when() and short_when()")

    tf = s.get("timeframe") or defaults.get("timeframe") or 5
    try:
        tf = int(tf)
    except (TypeError, ValueError):
        tf = 5
    if tf not in TIMEFRAMES:
        tf = 5
    cfg = {
        "name": s.get("name") or "Python strategy",
        "exch": s.get("exch") or defaults.get("exch") or "NFO",
        "und": s.get("und") or defaults.get("und") or "NIFTY",
        "start": s.get("start") or defaults.get("start") or "2025-02-01",
        "end": s.get("end") or defaults.get("end") or "2026-06-19",
        "capital": s.get("capital") or defaults.get("capital") or 1_000_000,
        "mode": s.get("mode") or "intraday",
        "timeframe": tf,
        "entryTime": s.get("entryTime") or "09:20",
        "exitTime": s.get("exitTime") or "15:15",
        "weekdays": s.get("weekdays") or [1, 2, 3, 4, 5],
        "dteMin": s.get("dteMin"), "dteMax": s.get("dteMax"),
        "maxTradesPerDay": s.get("maxTradesPerDay") or (5 if signal else 1),
        "reenterAfterExit": s.get("reenterAfterExit", False),
        "exitDaysBeforeExpiry": s.get("exitDaysBeforeExpiry", 0),
        "exitAllOnLegSl": s.get("exitAllOnLegSl", False),
        "exitOnOpposite": bool(st.opposite and long_e and short_e),
        "legs": legs,
    }
    if "lastEntryTime" in s:
        cfg["lastEntryTime"] = s["lastEntryTime"]
    if cfg["start"] > cfg["end"]:
        raise _err(1, "start date is after end date")
    if cfg["entryTime"] >= cfg["exitTime"]:
        raise _err(1, "entry_time must be before exit_time")
    if cfg.get("lastEntryTime") and not signal:
        notes.append("last_entry_time only applies to signal entries (and reenter_after_exit)")
    if long_e:
        cfg["entryConds"] = _block(long_e[0])
    if long_x and long_e or long_x and not signal:
        cfg["exitConds"] = _block(long_x[0])
    if short_e:
        cfg["short"] = {"legs": short_legs, "entryConds": _block(short_e[0]),
                        "exitConds": _block(short_x[0]) if short_x else {"logic": "AND", "rules": []}}
    cfg["overall"] = st.overall or {}
    cfg["costs"] = st.costs or {"enabled": True, "brokerage": 20, "slippagePct": 0.1}
    cfg["meta"] = {"source": "python", "code": code}

    if signal:
        sides = " and ".join(x for x, c in (("long", long_e), ("short", short_e)) if c)
        notes.append(f"signal-based entries ({sides}) evaluated on {tf}-min candle closes from "
                     f"{cfg['entryTime']}, filled next minute")
    else:
        notes.append(f"time-based entry at {cfg['entryTime']}: " + ", ".join(_describe_leg(l) for l in legs))
    if cfg["mode"] == "positional" and not signal and cfg["reenterAfterExit"]:
        warns.append("reenter_after_exit is intended for intraday time-based strategies")

    # detach shared sub-trees and guarantee JSON-safety
    try:
        cfg = json.loads(json.dumps(cfg, allow_nan=False))
    except (ValueError, RecursionError):
        raise _err(1, "strategy produced an invalid or overly complex config")
    return {"config": cfg, "notes": notes, "warnings": warns}


# ============================================================================ docs

EXAMPLE = '''from quantlab import *

# NIFTY 5-min EMA momentum: buy ATM calls on bullish crosses, ATM puts on bearish ones
strategy("NIFTY EMA momentum", underlying="NIFTY", exchange="NFO", timeframe=5,
         start="2025-06-01", end="2026-06-19", capital=1_000_000,
         mode="intraday", entry_time="09:30", exit_time="15:15", last_entry_time="14:30",
         max_trades_per_day=3, weekdays=[MON, TUE, WED, THU, FRI], dte=(0, 7))

fast, slow = ema(close, 9), ema(close, 21)
trend_up = (close > vwap()) & (adx(14) > 20)

long_when(crossover(fast, slow) & trend_up & (rsi(close, 14) > 55))
long_exit_when(crossunder(fast, slow) | (minutes_in_trade() > 90) | (pnl() < -3000))

short_when(crossunder(fast, slow) & ~trend_up & (rsi(close, 14) < 45))
short_exit_when(crossover(fast, slow) | (minutes_in_trade() > 90))
exit_on_opposite(True)

leg(BUY, CE, strike=ATM, expiry=WEEKLY, lots=1, sl=pct(25), target=pct(50), trail=(pct(10), pct(5)))
short_leg(BUY, PE, strike=ATM, expiry=WEEKLY, lots=1, sl=pct(25), target=pct(50))

overall(stop_loss=5000, target=10000, lock_at=3000, lock_profit=1000)
costs(brokerage=20, slippage_pct=0.1)
'''

DSL_REFERENCE = r'''# QuantLab Python DSL

Declarative: your script runs **once** to describe the strategy; it compiles to the standard JSON
config and the engine evaluates it on every candle close. Start with `from quantlab import *`.

## Setup
```python
strategy("Name", underlying="NIFTY", exchange="NFO", timeframe=5,   # 1 3 5 10 15 30 60
         start="2025-06-01", end="2026-06-19", capital=1_000_000,
         mode="intraday",              # or "positional"
         entry_time="09:20", exit_time="15:15", last_entry_time="14:30",
         max_trades_per_day=3, weekdays=[MON, TUE, WED, THU, FRI], dte=(0, 7),
         reenter_after_exit=False, exit_days_before_expiry=0, exit_all_on_leg_sl=False)
```
Omitted fields use the current form defaults.

## Series & conditions
- Prices: `open high low close volume hl2 hlc3 ohlc4`
- Math: `+ - * / **`, unary `-`, `abs(x)`, `max_(a, b)`, `min_(a, b)`, `sqrt(x)`, `log(x)`
- Previous candles: `close[1]` or `close.shift(1)`
- Compare `> >= < <= == !=` → condition. Combine with `&` (and), `|` (or), `~` (not).
  **Wrap comparisons in parentheses**: `(rsi(14) > 60) & (close > vwap())`.
  Python `and / or / not / if` are not allowed.
- `crossover(a, b)`, `crossunder(a, b)`, `cross(a, b)`; numbers work as either side.

## Indicators (`src` optional → `close`)
| | |
|---|---|
| Moving averages | `sma ema rma wma hma dema tema vwma (src, n)` |
| Oscillators | `rsi(src, 14)`, `cci(20)`, `williams_r(14)`, `roc(src, n)`, `momentum(src, n)` |
| MACD | `m = macd(src, 12, 26, 9)` → `m.line m.signal m.hist` |
| Bollinger | `bb = bbands(src, 20, 2)` → `bb.upper bb.mid bb.lower` |
| Stats | `stdev(src, n)`, `zscore(src, n)`, `highest(src, n)`, `lowest(src, n)` (`highest(n)` = highest high), `change(src)`, `change_pct(src)` |
| Trend / vol | `atr(14)`, `st = supertrend(10, 3)` → `st.line st.direction` (+1 up, -1 down), `adx(14)`, `plus_di(14)`, `minus_di(14)` |
| Stochastic | `s = stoch(14, 3, 3)` → `s.k s.d` |
| Volume | `obv()`, `vwap()` (session) |
| Volatility regime | `vix()` — India VIX, e.g. `vix() < 15` |
| Day levels | `day_open() day_high() day_low() prev_day_high() prev_day_low() prev_day_close()` |
| Opening range | `or_high(n)`, `or_low(n)` — first *n* candles of the session |
| Time | `time_of_day()` (HHMM, e.g. `time_of_day() < 1100` or `< "11:00"`), `hour()`, `minute()`, `weekday()` (1=Mon) |

Indicators can take other series as source: `ema(rsi(close, 14), 9)`, `sma(close - open, 5)`.

## Signals
```python
long_when(cond)            short_when(cond)
long_exit_when(cond)       short_exit_when(cond)
exit_on_opposite(True)     # flip on the opposite signal
```
Exit-only fields: `pnl()` (₹), `pnl_pct()`, `minutes_in_trade()` — compare directly, e.g. `pnl() < -3000`.
No `long_when/short_when` → **time-based** entry at `entry_time` (straddles etc.).

## Legs
```python
leg(SELL, CE, strike=ATM, expiry=WEEKLY, lots=1, sl=pct(30), target=pct(50),
    trail=(pct(10), pct(5)), reentries=2, reentry="immediate")   # traded on long / time entry
short_leg(BUY, PE, strike=OTM(1), expiry=WEEKLY, lots=1, sl=pts(20))   # traded on short signal
```
- side `BUY SELL` · type `CE PE FUT`
- strike `ATM OTM(n) ITM(n) premium(100) premium_gte(50) premium_lte(80) delta(30) pct_otm(1.5)`
- expiry `WEEKLY NEXT_WEEKLY FAR_WEEKLY MONTHLY NEXT_MONTHLY FAR_MONTHLY` (futures: monthly)
- `sl / target`: `pct(x)` or `pts(x)` of entry premium · `trail=(every, by)` needs an `sl`
- `reentry`: `"immediate" | "same_strike" | "cost"`
- Signals without legs use the form's default instrument.

## Risk & costs (₹)
```python
overall(stop_loss=5000, target=10000, lock_at=3000, lock_profit=1000,
        trail_every=1000, trail_by=500, sl_pct_capital=2)
costs(brokerage=20, slippage_pct=0.1)      # default; costs(enabled=False) to disable
```
'''
