"""Pine -> QuantLab transpiler tests.  Run:  cd backend && PYTHONPATH=. ../.venv/bin/python strategy/test_pine.py"""
import json
import sys
import time

import engine
from strategy.pine import compile_pine

DEF = {"exch": "NFO", "und": "NIFTY", "start": "2026-03-02", "end": "2026-03-06", "capital": 1000000,
       "timeframe": 5, "instrument": "atm_options", "lots": 1, "expiry": "weekly"}

EMA_V5 = """//@version=5
strategy("EMA Cross", overlay=true, default_qty_type=strategy.percent_of_equity, default_qty_value=10)
fastLen = input.int(9, "Fast", minval=1)
slowLen = input.int(21, title="Slow")
fast = ta.ema(close, fastLen)
slow = ta.ema(close, slowLen)
longCond = ta.crossover(fast, slow)
shortCond = ta.crossunder(fast, slow)
if longCond
    strategy.entry("Long", strategy.long)
if shortCond
    strategy.entry("Short", strategy.short)
plot(fast, color=color.green)
plot(slow, color=color.red)
"""

RSI_V4 = """//@version=4
strategy("RSI MR", overlay=false)
len = input(14, title="RSI Length")
src = input(close, title="Source", type=input.source)
os = input(30)
ob = input(defval=70, title="OB")
r = rsi(src, len)
strategy.entry("L", strategy.long, when=crossover(r, os))
strategy.close("L", when=crossover(r, ob) or r > 80)
plot(r)
hline(os)
"""

MACD = """//@version=5
strategy("MACD tuple")
[macdLine, signalLine, hist] = ta.macd(close, 12, 26, 9)
bull = ta.crossover(macdLine, signalLine) and hist > 0
bear = ta.crossunder(macdLine, signalLine)
if bull and strategy.position_size == 0
    strategy.entry("B", strategy.long)
if bear
    strategy.close("B")
"""

SUPERTREND = """//@version=5
strategy("Supertrend", overlay=true)
atrPeriod = input.int(10, "ATR Length")
factor = input.float(3.0, "Factor", step = 0.01)
[supertrend, direction] = ta.supertrend(factor, atrPeriod)
if ta.change(direction) < 0
    strategy.entry("Up", strategy.long)
if ta.change(direction) > 0
    strategy.entry("Down", strategy.short)
upTrend = plot(direction < 0 ? supertrend : na, "Up Trend", color = color.green)
"""

BB = """//@version=5
strategy("BB breakout", overlay=true)
length = input.int(20)
mult = input.float(2.0)
[basis, upper, lower] = ta.bb(close, length, mult)
slPct = input.float(1.5, "SL %") / 100
tpPct = input.float(3.0, "TP %") / 100
if close > upper and close[1] <= upper[1]
    strategy.entry("BBL", strategy.long)
if strategy.position_size > 0
    strategy.exit("XL", "BBL", stop=strategy.position_avg_price * (1 - slPct), limit=strategy.position_avg_price * (1 + tpPct))
if ta.crossunder(close, basis)
    strategy.close("BBL")
"""

DMI = """//@version=5
strategy("DMI ADX filter")
[diplus, diminus, adx] = ta.dmi(14, 14)
trending = adx > 20
if trending and ta.crossover(diplus, diminus)
    strategy.entry("L", strategy.long)
if trending and ta.crossover(diminus, diplus)
    strategy.entry("S", strategy.short)
strategy.exit("xl", "L", profit = 400, loss = 200)
"""

TIMEF = """//@version=5
strategy("Time filter ORB")
inSession = (hour > 9 or (hour == 9 and minute >= 30)) and hour < 14
notMonday = dayofweek != dayofweek.monday
hh = ta.highest(high, 6)[1]
ll = ta.lowest(6)[1]
if inSession and notMonday
    if close > hh
        strategy.entry("L", strategy.long)
    else if close < ll
        strategy.entry("S", strategy.short)
if hour >= 15
    strategy.close_all()
"""

INPUTS_MIX = """//@version=5
// kitchen-sink: inputs, ternary on constant, math, v4-style nested ifs, stoch smoothing, vwap, cci, roc
strategy(title = "Kitchen sink",
     overlay = true, initial_capital = 100000)
useFast = input.bool(true, "Use fast MA")
maLen = useFast ? 10 : 30
src = input.source(hl2, "Source")
ma = ta.sma(src, maLen)
k = ta.sma(ta.stoch(close, high, low, 14), 3)
d = ta.sma(k, 3)
spread = math.abs(close - ta.vwap) / close * 100
mom = ta.roc(close, 5)
c = ta.cci(hlc3, 20)
var float lvl = 50.0
lvl := 55
longOk = close > ma and k > d and not (spread > 1) and mom > 0 and c > -100 and ta.rsi(close, 14) > lvl
exitOk = ta.crossunder(k, d) or ta.falling(close, 3)
if longOk
    if volume > ta.sma(volume, 20) * 1.2
        strategy.entry("LE", strategy.long, comment="go")
if exitOk
    strategy.close("LE")
bgcolor(longOk ? color.new(color.green, 90) : na)
alertcondition(longOk, "Long")
"""

SCRIPTS = {"ema_v5": EMA_V5, "rsi_v4": RSI_V4, "macd": MACD, "supertrend": SUPERTREND, "bb_exit": BB,
           "dmi": DMI, "time_filter": TIMEF, "inputs_mix": INPUTS_MIX}


def rules_of(block):
    out = []

    def walk(r):
        if "rules" in r:
            for x in r["rules"]:
                walk(x)
        elif "not" in r:
            walk(r["not"])
        else:
            out.append(r)
    if block:
        walk(block)
    return out


def ops_named(block):
    names = set()

    def walk_op(o):
        if o.get("kind") == "ind":
            names.add(o["name"])
        for a in o.get("args") or []:
            walk_op(a)
        if o.get("of"):
            walk_op(o["of"])
    for r in rules_of(block):
        walk_op(r["lhs"])
        walk_op(r["rhs"])
    return names


def check_errors():
    bad = {
        "indicator": ('//@version=5\nindicator("x")\nplot(close)\n', "line 2", "strategy"),
        "loop": ('//@version=5\nstrategy("x")\nfor i = 0 to 10\n    x = i\n', "line 3", "loop"),
        "security": ('//@version=5\nstrategy("x")\ns = request.security(syminfo.tickerid, "D", close)\n'
                     'strategy.entry("L", strategy.long, when=close > s)\n', "line 3", "security"),
        "array": ('//@version=5\nstrategy("x")\na = array.new_float(0)\n', "line 3", "array"),
        "tern": ('//@version=5\nstrategy("x")\nm = close > open ? ta.sma(close, 5) : ta.ema(close, 5)\n'
                 'strategy.entry("L", strategy.long, when=close > m)\n', "line 3", "ternary"),
        "varmut": ('//@version=5\nstrategy("x")\nvar float hi = na\nhi := math.max(high, 1)\n', "line 4", "reassign"),
        "noentry": ('//@version=5\nstrategy("x")\nplot(close)\n', "line 1", "strategy.entry"),
        "time": ('//@version=5\nstrategy("x")\nt = time(timeframe.period, "0930-1500")\n', "line 3", "time"),
        "undeclared": ('//@version=5\nstrategy("x")\nstrategy.entry("L", strategy.long, when=foo > 1)\n', "line 3", "foo"),
        "udf": ('//@version=5\nstrategy("x")\nf(x) => x * 2\n', "line 3", "user-defined"),
    }
    for k, (code, where, frag) in bad.items():
        try:
            compile_pine(code, DEF)
        except ValueError as e:
            msg = str(e)
            assert msg.startswith(where), (k, msg)
            assert frag.lower() in msg.lower(), (k, msg)
            print(f"  error ok  {k:10s} -> {msg}")
        else:
            raise AssertionError(f"{k}: expected ValueError")


def main():
    t0 = time.time()
    out = {k: compile_pine(v, DEF) for k, v in SCRIPTS.items()}
    for k, r in out.items():
        cfg = r["config"]
        assert cfg["meta"]["source"] == "pine" and cfg["meta"]["code"] == SCRIPTS[k]
        assert cfg["mode"] == "intraday" and cfg["maxTradesPerDay"] == 5 and cfg["costs"]["brokerage"] == 20

    # --- structural checks
    c = out["ema_v5"]["config"]
    assert c["name"] == "EMA Cross" and c["exitOnOpposite"] is True
    r = c["entryConds"]["rules"][0]
    assert r["op"] == "crosses_above" and r["lhs"]["name"] == "EMA" and r["lhs"]["n"] == 9 and r["rhs"]["n"] == 21
    assert c["short"]["entryConds"]["rules"][0]["op"] == "crosses_below"
    assert c["legs"][0]["type"] == "CE" and c["short"]["legs"][0]["type"] == "PE"
    assert any("default_qty" in n for n in out["ema_v5"]["notes"])

    c = out["rsi_v4"]["config"]
    assert c["entryConds"]["rules"][0]["lhs"]["name"] == "RSI" and c["entryConds"]["rules"][0]["rhs"]["value"] == 30
    assert c["exitConds"]["logic"] == "OR" and len(c["exitConds"]["rules"]) == 2 and "short" not in c

    c = out["macd"]["config"]
    assert ops_named(c["entryConds"]) == {"MACD", "MACDSignal", "MACDHist"}
    assert c["entryConds"]["logic"] == "AND" and len(c["entryConds"]["rules"]) == 2  # position_size dropped
    assert c["exitConds"]["rules"][0]["op"] == "crosses_below"

    c = out["supertrend"]["config"]
    lr = c["entryConds"]["rules"][0]
    assert lr["lhs"]["name"] == "Change" and lr["lhs"]["of"]["op"] == "neg" and \
        lr["lhs"]["of"]["args"][0]["name"] == "SupertrendDir" and lr["lhs"]["of"]["args"][0]["n2"] == 3.0

    c = out["bb_exit"]["config"]
    L = c["legs"][0]
    assert (L["sl"], L["slType"], L["tgt"], L["tgtType"]) == (1.5, "pct", 3.0, "pct"), L
    assert ops_named(c["entryConds"]) >= {"UpperBB", "Close"}
    assert any(rr["rhs"].get("offset") == 1 for rr in rules_of(c["entryConds"]))
    assert any("premium" in n for n in out["bb_exit"]["notes"])

    c = out["dmi"]["config"]
    assert ops_named(c["entryConds"]) == {"ADX", "PlusDI", "MinusDI"}
    assert (c["legs"][0]["tgt"], c["legs"][0]["sl"], c["legs"][0]["slType"]) == (20.0, 10.0, "pts")
    assert c["short"]["legs"][0]["sl"] == 0  # exit only from "L"

    c = out["time_filter"]["config"]
    js = json.dumps(c["entryConds"])
    assert '"Hour"' in js and '"Minute"' in js and '"WeekDay"' in js and "HighestHigh" in js
    assert '"LowestLow"' in json.dumps(c["short"]["entryConds"])
    # dayofweek != monday -> ISO weekday in 2..5
    assert '{"lhs": {"kind": "dt", "field": "WeekDay", "offset": 0}, "op": ">=", "rhs": {"kind": "const", "value": 2}}' in js
    # else-if -> short entry carries not(close > hh)
    assert '"not"' in json.dumps(c["short"]["entryConds"])
    assert c["exitConds"] == c["short"]["exitConds"]

    c = out["inputs_mix"]["config"]
    names = ops_named(c["entryConds"])
    assert {"SMA", "StochK", "StochD", "VWAP", "ROC", "CCI", "RSI", "Volume"} <= names, names
    js = json.dumps(c["entryConds"])
    assert '"name": "SMA", "n": 10' in js and '"of": {"kind": "ind", "name": "HL2"' in js
    stk = [o for r in rules_of(c["entryConds"]) for o in (r["lhs"], r["rhs"]) if o.get("name") == "StochK"][0]
    assert (stk["n"], stk["n2"]) == (14, 3)
    assert '"value": 55' in js  # lvl := 55 (constant reassignment)
    assert c["name"] == "Kitchen sink"

    # --- engine validation of every config (constructor compiles every operand)
    for k, r in out.items():
        bt = engine.Backtest({**r["config"], "start": "2026-03-02", "end": "2026-03-06"})
        for side in bt.sides.values():
            for rr in rules_of(side["entry"]) + rules_of(side["exit"]):
                for o in (rr["lhs"], rr["rhs"]):
                    a = engine.series(o, bt.C)
                    assert len(a) == bt.C.n
        print(f"  engine ok {k:12s} sides={list(bt.sides)} notes={len(r['notes'])} warnings={len(r['warnings'])}")

    check_errors()

    # --- full backtests (1 week NIFTY)
    for k in ("ema_v5", "bb_exit"):
        t1 = time.time()
        res = engine.run_backtest({**out[k]["config"], "start": "2026-03-02", "end": "2026-03-06"})
        n = len(res["trades"])
        print(f"  backtest  {k:12s} trades={n} net={res['stats'].get('netPnl')} ({time.time() - t1:.1f}s)")
        assert n > 0, (k, res.get("skipped"), res.get("warnings"))

    print("\nsample notes (bb_exit):")
    for n in out["bb_exit"]["notes"]:
        print("  -", n)
    print(f"\nALL PINE TESTS PASSED ({time.time() - t0:.1f}s)")


if __name__ == "__main__":
    sys.exit(main())
