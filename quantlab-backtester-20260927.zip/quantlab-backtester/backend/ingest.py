"""Convert raw QuantLab S3 dumps (tab-separated .csv.gz, 1-minute bars) into a
partitioned Parquet store the backtest engine can query in milliseconds.

    data/deriv/exch=NFO/und=NIFTY/ym=2025-12/*.parquet   options + futures
    data/cash/exch=NSE/sym=-1/ym=2025-12/*.parquet       indices (by code) + F&O stocks
    data/meta.json                                       index code map, lot sizes, calendar

Usage:  python backend/ingest.py /path/to/quantlab-s3-data
"""
import glob
import json
import math
import os
import shutil
import sys
import time

import duckdb

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.environ.get("QL_DATA_OUT") or os.path.join(ROOT, "data")  # QL_DATA_OUT: build into a fresh dir, then swap

# vendor symbols that don't match exchange underlying codes
UND_FIX = "CASE p.und WHEN 'Nifty Next 50' THEN 'NIFTYNXT50' ELSE p.und END"

MIN_DAYS = int(os.environ.get("QL_MIN_DAYS", 20))  # overlap needed to accept an index spot mapping

SESSION = "CAST(TIME AS TIME) BETWEEN TIME '09:15:00' AND TIME '15:30:00'"


def con():
    c = duckdb.connect()
    c.execute("SET threads=8")
    c.execute("SET preserve_insertion_order=false")
    c.execute(f"SET temp_directory='{os.path.join(DATA, '.tmp')}'")
    return c


def is_empty(path):
    return os.path.getsize(path) < 200


def ingest_deriv(c, files):
    out = os.path.join(DATA, "deriv")
    for i, f in enumerate(sorted(files)):
        if is_empty(f):
            continue
        t = time.time()
        # SYMBOL = KIND_UND_EXCH_EXPIRY[_STRIKE_CE|PE]
        c.execute(f"""
        COPY (
          WITH r AS (
            SELECT SYMBOL, TIME, OPEN, HIGH, LOW, CLOSE, VOLUME, VWAP, OPEN_INTEREST, TOTAL_OPEN_INTEREST,
                   regexp_extract(SYMBOL, '^(OPTIDX|OPTSTK|FUTIDX|FUTSTK)_(.+)_(NFO|BFO)_(\\d{{4}}-\\d{{2}}-\\d{{2}})(?:_([0-9.]+)_(CE|PE))?$',
                                  ['kind','und','exch','expiry','strike','opt']) p
            FROM read_csv('{f}', delim='\t', header=true, compression='gzip', auto_detect=true,
                          types={{'SYMBOL':'VARCHAR','TIME':'TIMESTAMP'}})
            WHERE {SESSION} AND CLOSE > 0
          )
          SELECT p.exch AS exch, {UND_FIX} AS und, strftime(TIME, '%Y-%m') AS ym,
                 CAST(p.expiry AS DATE) AS expiry,
                 CASE WHEN p.kind LIKE 'FUT%' THEN 'FUT' ELSE p.opt END AS typ,
                 TRY_CAST(NULLIF(p.strike, '') AS DOUBLE) AS strike,
                 TIME AS ts, OPEN::DOUBLE AS o, HIGH::DOUBLE AS h, LOW::DOUBLE AS l, CLOSE::DOUBLE AS c,
                 VOLUME::DOUBLE AS v, TOTAL_OPEN_INTEREST::DOUBLE AS oi,
                 VWAP::DOUBLE AS vwap, OPEN_INTEREST::DOUBLE AS moi
          FROM r
          WHERE p.und <> '' AND p.und NOT LIKE '%TEST%'
          ORDER BY und, expiry, typ, strike, ts
        ) TO '{out}' (FORMAT parquet, COMPRESSION zstd, PARTITION_BY (exch, und, ym),
                      OVERWRITE_OR_IGNORE, FILENAME_PATTERN 'p_{os.path.basename(f).split('.')[0]}_{{i}}')
        """)
        print(f"  deriv {os.path.basename(f)}  {time.time()-t:.1f}s", flush=True)


def ingest_cash(c, files, fno_stocks):
    out = os.path.join(DATA, "cash")
    stocks = ",".join("'" + s.replace("'", "''") + "'" for s in sorted(fno_stocks)) or "''"
    for f in sorted(files):
        if is_empty(f):
            continue
        t = time.time()
        c.execute(f"""
        COPY (
          WITH r AS (
            SELECT TIME, OPEN, HIGH, LOW, CLOSE, VOLUME, VWAP,
                   regexp_extract(SYMBOL, '^(IDX|STK)_(.+?)(?:_EQ)?_(NSE|BSE)$', ['kind','sym','exch']) p
            FROM read_csv('{f}', delim='\t', header=true, compression='gzip', auto_detect=true,
                          types={{'SYMBOL':'VARCHAR','TIME':'TIMESTAMP'}})
            WHERE {SESSION} AND CLOSE > 0
          )
          SELECT p.exch AS exch, p.sym AS sym, strftime(TIME, '%Y-%m') AS ym,
                 p.kind AS kind, TIME AS ts, OPEN::DOUBLE AS o, HIGH::DOUBLE AS h, LOW::DOUBLE AS l, CLOSE::DOUBLE AS c, VOLUME::DOUBLE AS v,
                 VWAP::DOUBLE AS vwap
          FROM r
          WHERE p.kind = 'IDX' OR (p.kind = 'STK' AND p.sym IN ({stocks}))
          ORDER BY sym, ts
        ) TO '{out}' (FORMAT parquet, COMPRESSION zstd, PARTITION_BY (exch, sym, ym),
                      OVERWRITE_OR_IGNORE, FILENAME_PATTERN 'p_{os.path.basename(f).split('.')[0]}_{{i}}')
        """)
        print(f"  cash  {os.path.basename(f)}  {time.time()-t:.1f}s", flush=True)


def build_meta(c):
    d = os.path.join(DATA, "deriv", "**", "*.parquet")
    k = os.path.join(DATA, "cash", "**", "*.parquet")
    c.execute(f"CREATE VIEW deriv AS SELECT * FROM read_parquet('{d}', hive_partitioning=true, union_by_name=true)")
    c.execute(f"CREATE VIEW cash AS SELECT * FROM read_parquet('{k}', hive_partitioning=true, union_by_name=true)")

    unds = c.execute("""
        SELECT exch, und, bool_or(typ <> 'FUT') has_opt,
               bool_or(typ = 'FUT') has_fut, min(ts)::DATE, max(ts)::DATE
        FROM deriv GROUP BY 1, 2 ORDER BY 1, 2""").fetchall()

    # Index spot codes: pick the IDX code whose daily close tracks the near-month future best
    # (stable basis = low dispersion of future/spot). Daily closes work even for illiquid futures (BANKEX).
    c.execute("""CREATE TEMP TABLE idx_close AS
        SELECT exch, sym, ts::DATE d, arg_max(c, ts) c FROM cash WHERE kind='IDX' GROUP BY ALL""")
    idx_und = [(e, u) for e, u, *_ in unds if u in INDEX_NAMES]
    index_map = {}
    for exch, und in idx_und:
        cash_exch = "NSE" if exch == "NFO" else "BSE"
        rows = c.execute(f"""
          WITH f AS (
            SELECT d, arg_min(cd, expiry) c FROM (
              SELECT ts::DATE d, expiry, arg_max(c, ts) cd FROM deriv
              WHERE exch='{exch}' AND und='{und}' AND typ='FUT' AND expiry >= ts::DATE GROUP BY 1, 2)
            GROUP BY 1
          ), j AS (
            SELECT s.sym, f.c / s.c r FROM f JOIN idx_close s USING (d) WHERE s.exch='{cash_exch}'
          ), m AS (SELECT sym, median(r) mr, count(*) n FROM j GROUP BY 1)
          SELECT j.sym, median(abs(j.r - m.mr)) err, any_value(m.n) n, any_value(m.mr) mr
          FROM j JOIN m USING (sym) WHERE m.mr BETWEEN 0.97 AND 1.04 AND m.n > {MIN_DAYS}
          GROUP BY 1 ORDER BY err LIMIT 1""").fetchall()
        if rows and rows[0][1] < 0.02:  # futures basis decays over the month; wrong indices are off by >> 2%
            index_map[f"{exch}:{und}"] = {"exch": cash_exch, "sym": rows[0][0], "err": rows[0][1]}
        print(f"  index {exch}:{und} -> {rows[:1]}", flush=True)
    # India VIX: the NSE index whose level lives in the 8..40 band
    named = {}
    vix = c.execute("""SELECT sym FROM idx_close WHERE exch='NSE' GROUP BY sym
                       HAVING median(c) BETWEEN 8 AND 40 AND max(c) < 100 ORDER BY count(*) DESC LIMIT 1""").fetchall()
    if vix:
        named["INDIAVIX"] = {"exch": "NSE", "sym": vix[0][0]}
    for k, v in index_map.items():
        named[k.split(":")[1]] = {"exch": v["exch"], "sym": v["sym"]}

    # Lot size per (und, expiry) = GCD of traded 1-min volumes (volumes are in units).
    lots = {}
    rows = c.execute("""
        WITH mv AS (SELECT exch, und, expiry, typ, strike, min(v) mv FROM deriv WHERE v > 0 GROUP BY ALL)
        SELECT exch, und, expiry, mode(mv) FROM mv GROUP BY ALL""").fetchall()
    for exch, und, expiry, mv in rows:
        lots.setdefault(f"{exch}:{und}", {})[str(expiry)] = int(mv)

    # sessions = days with a real NIFTY session (>= 50 traded minutes; Muhurat trading has ~60).
    # Early-2025 vendor files contain only a handful of stray minutes per day - those are excluded.
    cal = [str(r[0]) for r in c.execute("""
        SELECT d FROM (SELECT ts::DATE d, count(DISTINCT ts) m FROM deriv WHERE exch='NFO' AND und='NIFTY' GROUP BY 1)
        WHERE m >= 50 ORDER BY 1""").fetchall()]

    meta = {
        "underlyings": [
            # clamp to real sessions: stray early rows must not advertise a start date we can't backtest
            {"exch": e, "und": u, "options": bool(o), "futures": bool(fu),
             "from": max(str(a), cal[0]) if cal else str(a), "to": str(b), "index": u in INDEX_NAMES}
            for e, u, o, fu, a, b in unds if not cal or str(b) >= cal[0]
        ],
        "index_map": index_map,
        "named_indices": named,
        "lots": lots,
        "calendar": cal,
    }
    with open(os.path.join(DATA, "meta.json"), "w") as fh:
        json.dump(meta, fh, indent=1, default=str)
    print(f"meta: {len(unds)} underlyings, {len(index_map)} index maps, {len(cal)} sessions")


INDEX_NAMES = {"NIFTY", "BANKNIFTY", "FINNIFTY", "MIDCPNIFTY", "NIFTYNXT50", "SENSEX", "BANKEX", "SENSEX50"}


def main(src):
    t0 = time.time()
    os.makedirs(DATA, exist_ok=True)
    only_meta = "--meta" in sys.argv
    c = con()
    if not only_meta:
        for sub in ("deriv", "cash"):
            shutil.rmtree(os.path.join(DATA, sub), ignore_errors=True)
        deriv = glob.glob(os.path.join(src, "all_nfo*", "*.csv.gz")) + glob.glob(os.path.join(src, "all_bfo*", "*.csv.gz"))
        cashf = glob.glob(os.path.join(src, "all_nse*", "*.csv.gz")) + glob.glob(os.path.join(src, "all_bse*", "*.csv.gz"))
        print(f"{len(deriv)} derivative files, {len(cashf)} cash files", flush=True)
        ingest_deriv(c, deriv)
        stocks = {r[0] for r in c.execute(
            f"SELECT DISTINCT und FROM read_parquet('{os.path.join(DATA, 'deriv', '**', '*.parquet')}', hive_partitioning=true)"
        ).fetchall()} - INDEX_NAMES
        ingest_cash(c, cashf, stocks)
    build_meta(c)
    shutil.rmtree(os.path.join(DATA, ".tmp"), ignore_errors=True)
    print(f"done in {time.time()-t0:.0f}s")


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 and not sys.argv[1].startswith("--") else
         "/Users/bhargavmoparthi/Downloads/quantlab-s3-data")
