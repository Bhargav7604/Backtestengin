"""Background backtest / optimisation jobs with progress + cancellation.

A single worker thread runs jobs in order (DuckDB access is serialised anyway), so a
long optimisation never starves the process; the UI polls GET /api/jobs/{id}.
"""
from __future__ import annotations

import copy
import itertools
import queue
import threading
import time
import traceback
import uuid

import analytics
import engine

MAX_COMBOS = 36
_jobs: dict = {}
_q: "queue.Queue[str]" = queue.Queue()


def _set_path(cfg, path, value):
    """'legs.0.sl' / 'overall.sl' / 'short.legs.0.sl' / 'entryConds.rules.1.rhs.value' -> set in place."""
    parts = path.split(".")
    cur = cfg
    for p in parts[:-1]:
        cur = cur[int(p)] if isinstance(cur, list) else cur.setdefault(p, {})
    last = parts[-1]
    if isinstance(cur, list):
        cur[int(last)] = value
    else:
        cur[last] = value


def submit(kind, payload):
    jid = uuid.uuid4().hex[:12]
    _jobs[jid] = {"id": jid, "kind": kind, "status": "queued", "progress": 0.0, "message": "Queued",
                  "payload": payload, "cancel": False, "created": time.time()}
    _q.put(jid)
    _gc()
    return jid


def get(jid):
    j = _jobs.get(jid)
    if not j:
        return None
    return {k: v for k, v in j.items() if k not in ("payload", "cancel")}


def cancel(jid):
    j = _jobs.get(jid)
    if j and j["status"] in ("queued", "running"):
        j["cancel"] = True
        if j["status"] == "queued":
            j["status"], j["message"] = "cancelled", "Cancelled"
    return j is not None


def _gc():
    cutoff = time.time() - 3600
    for k in [k for k, j in _jobs.items() if j["created"] < cutoff and j["status"] not in ("queued", "running")]:
        _jobs.pop(k, None)


def run_single(cfg, progress=None, cancelled=None):
    t = time.time()
    res = engine.Backtest(cfg, progress=progress, should_cancel=cancelled).run()
    res = analytics.enrich(res, cfg)
    res["elapsed"] = round(time.time() - t, 2)
    res["config"] = cfg
    return res


def _run(j):
    p = j["payload"]
    cancelled = lambda: j["cancel"]
    if j["kind"] == "backtest":
        def prog(i, n):
            j["progress"], j["message"] = i / max(n, 1), f"Simulating session {i}/{n}"
        return run_single(p["config"], prog, cancelled)
    # optimise
    base = p["config"]
    params = p.get("params") or []
    metric = p.get("metric", "netPnl")
    if not params or len(params) > 2:
        raise ValueError("Choose 1 or 2 parameters to optimise")
    combos = list(itertools.product(*[prm["values"] for prm in params]))
    if len(combos) > MAX_COMBOS:
        raise ValueError(f"{len(combos)} combinations — keep it to {MAX_COMBOS} or fewer")
    grid = []
    for ci, vals in enumerate(combos):
        c = copy.deepcopy(base)
        for prm, v in zip(params, vals):
            _set_path(c, prm["path"], v)

        def prog(i, n, ci=ci):
            j["progress"] = (ci + i / max(n, 1)) / len(combos)
            j["message"] = f"Combination {ci + 1}/{len(combos)}"
        try:
            r = engine.Backtest(c, progress=prog, should_cancel=cancelled).run()
            grid.append({"values": list(vals), "stats": r["stats"]})
        except engine.Cancelled:
            raise
        except ValueError as e:
            grid.append({"values": list(vals), "stats": None, "error": str(e)})
    ok = [g for g in grid if g["stats"] and g["stats"].get(metric) is not None]
    # every metric is "higher is better" (maxDD / maxDDPct are negative numbers)
    best = max(ok, key=lambda g: g["stats"][metric]) if ok else None
    return {"metric": metric, "params": params, "grid": grid, "best": best}


def _worker():
    while True:
        jid = _q.get()
        j = _jobs.get(jid)
        if not j or j["status"] == "cancelled":
            continue
        j["status"], j["message"], j["started"] = "running", "Loading market data", time.time()
        try:
            j["result"] = _run(j)
            j["status"], j["progress"], j["message"] = "done", 1.0, "Done"
        except engine.Cancelled:
            j["status"], j["message"] = "cancelled", "Cancelled"
        except ValueError as e:
            j["status"], j["error"] = "error", str(e)
        except Exception as e:
            traceback.print_exc()
            j["status"], j["error"] = "error", f"{type(e).__name__}: {e}"
        finally:
            j.pop("payload", None)


threading.Thread(target=_worker, daemon=True, name="backtest-worker").start()
