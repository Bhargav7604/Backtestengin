"""Minute-level F&O backtest engine over real NFO/BFO data.

Fill model
----------
* "Price at minute X" = OPEN of the contract's 1-min bar starting at X; if the
  contract did not trade in that minute, the last CLOSE before X (stale-price
  carry-forward). A contract that has never traded that session is unfillable.
* Time-based entries fill at the entry-time minute. Indicator signals are
  evaluated on the CLOSE of a candle and fill at the first minute after it.
* Stop-loss / target / trailing checks use each 1-min bar's HIGH/LOW after the
  entry minute. A gap through the level fills at the bar OPEN (worse price).
  If SL and target are both inside one bar, SL is assumed first (conservative).
* Strategy-level MTM stop / target are checked on 1-min closes and exit all legs
  at the next minute.
* Slippage is applied against you on every fill; statutory charges follow the
  exchange schedule in effect on the trade date.
"""
from __future__ import annotations

import json
import math
import os
import threading
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta

import duckdb
import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, "data")
MINUTES = 376  # 09:15 .. 15:30 inclusive
OPEN_MIN = 9 * 60 + 15
RISK_FREE = 0.065

_lock = threading.Lock()
_con = None
_meta = None
_cache: dict = {}


def con():
    global _con
    if _con is None:
        c = duckdb.connect()
        c.execute("SET threads=8")
        d = os.path.join(DATA, "deriv", "**", "*.parquet")
        k = os.path.join(DATA, "cash", "**", "*.parquet")
        # union_by_name: some partitions were written with BIGINT prices; without it the view takes the
        # first file's schema and silently rounds every option price to whole rupees.
        c.execute(f"CREATE VIEW deriv AS SELECT * FROM read_parquet('{d}', hive_partitioning=true, union_by_name=true)")
        c.execute(f"CREATE VIEW cash AS SELECT * FROM read_parquet('{k}', hive_partitioning=true, union_by_name=true)")
        _con = c
    return _con


def meta():
    global _meta
    if _meta is None:
        with open(os.path.join(DATA, "meta.json")) as fh:
            _meta = json.load(fh)
    return _meta


def q(sql, params=None):
    with _lock:
        return con().execute(sql, params or []).fetchnumpy()


def qrows(sql, params=None):
    with _lock:
        return con().execute(sql, params or []).fetchall()


def hhmm(m: int) -> str:
    t = OPEN_MIN + m
    return f"{t // 60:02d}:{t % 60:02d}"


def to_min(s: str) -> int:
    h, m = s.split(":")[:2]
    return max(0, min(MINUTES - 1, int(h) * 60 + int(m) - OPEN_MIN))


# ----------------------------------------------------------------------------- data access

def expiry_table(exch, und):
    """{date: {'all': [expiries], 'fut': [monthly expiries]}} for every session."""
    key = ("exp", exch, und)
    if key not in _cache:
        rows = qrows("""
            SELECT ts::DATE d, expiry, bool_or(typ='FUT') fut, bool_or(typ<>'FUT') opt
            FROM deriv WHERE exch=? AND und=? GROUP BY 1, 2 ORDER BY 1, 2""", [exch, und])
        tab: dict = {}
        for d, e, fut, opt in rows:
            if e < d:
                continue
            t = tab.setdefault(d, {"opt": [], "fut": []})
            if opt:
                t["opt"].append(e)
            if fut:
                t["fut"].append(e)
        _cache[key] = tab
    return _cache[key]


_month_lru: "dict" = {}
MONTH_LRU_MAX = 24


def month_bars(exch, und, ym, exps):
    """All bars of the given expiries for one underlying-month. Reads the partition directory directly
    (avoids globbing the whole store) and keeps an LRU so re-runs / optimiser sweeps are instant."""
    exps = frozenset(exps)
    for (k_exch, k_und, k_ym, k_exps), r in _month_lru.items():
        if (k_exch, k_und, k_ym) == (exch, und, ym) and exps <= k_exps:
            _month_lru[(k_exch, k_und, k_ym, k_exps)] = _month_lru.pop((k_exch, k_und, k_ym, k_exps))  # touch
            if exps == k_exps:
                return r
            keep = np.isin(r["expiry"].astype("datetime64[D]"), np.array(sorted(exps), dtype="datetime64[D]"))
            return {k: v[keep] for k, v in r.items()}
    part = os.path.join(DATA, "deriv", f"exch={exch}", f"und={und}", f"ym={ym}")
    cols = {"d": np.array([], "datetime64[D]"), "expiry": np.array([], "datetime64[D]"), "typ": np.array([], object),
            "strike": np.array([]), "ts": np.array([], "datetime64[us]"), **{c: np.array([]) for c in "ohlcv"}, "oi": np.array([])}
    if not exps or not os.path.isdir(part):
        return cols
    ph = ",".join("?" * len(exps))
    r = q(f"""SELECT ts::DATE d, expiry, typ, coalesce(strike, 0) strike, ts, o::DOUBLE o, h::DOUBLE h,
                     l::DOUBLE l, c::DOUBLE c, v::DOUBLE v, oi::DOUBLE oi
              FROM read_parquet('{os.path.join(part, "*.parquet")}', union_by_name=true)
              WHERE expiry IN ({ph}) ORDER BY d, expiry, typ, strike, ts""", sorted(exps))
    _month_lru[(exch, und, ym, exps)] = r
    while len(_month_lru) > MONTH_LRU_MAX:
        _month_lru.pop(next(iter(_month_lru)))
    return r


def vix_for(C):
    """India VIX close at each candle's close (last print at or before it), or None if unavailable."""
    v = meta().get("named_indices", {}).get("INDIAVIX")
    if not v:
        return None
    key = ("vix",)
    if key not in _cache:
        r = q("SELECT ts, c FROM cash WHERE exch=? AND sym=? AND kind='IDX' ORDER BY ts", [v["exch"], v["sym"]])
        _cache[key] = (r["ts"].astype("datetime64[m]"), r["c"].astype(float))
    ts, c = _cache[key]
    if not len(ts):
        return None
    at = C.day.astype("datetime64[m]") + (OPEN_MIN + C.end_min.astype(int) - 1).astype("timedelta64[m]")
    i = np.searchsorted(ts, at, side="right") - 1
    return np.where(i >= 0, c[np.maximum(i, 0)], np.nan)


def spot_series(exch, und):
    """Continuous 1-min underlying series. Index -> mapped IDX code; stock -> cash equity;
    fallback -> nearest-month future (continuous, rolled on expiry)."""
    key = ("spot", exch, und)
    if key in _cache:
        return _cache[key]
    m = meta()["index_map"].get(f"{exch}:{und}")
    src = None
    if m:
        r = q("SELECT ts, o, h, l, c, v FROM cash WHERE exch=? AND sym=? ORDER BY ts", [m["exch"], m["sym"]])
        src = "index"
    else:
        cash_exch = "NSE" if exch == "NFO" else "BSE"
        r = q("SELECT ts, o, h, l, c, v FROM cash WHERE exch=? AND sym=? AND kind='STK' ORDER BY ts", [cash_exch, und])
        src = "equity"
    if len(r["ts"]) == 0:
        r = q("""SELECT ts, arg_min(o, expiry) o, arg_min(h, expiry) h, arg_min(l, expiry) l,
                        arg_min(c, expiry) c, arg_min(v, expiry) v
                 FROM deriv WHERE exch=? AND und=? AND typ='FUT' AND expiry >= ts::DATE
                 GROUP BY ts ORDER BY ts""", [exch, und])
        src = "future"
    # future volume for VWAP (spot indices have no volume)
    fv = q("""SELECT ts, arg_min(c, expiry) c, arg_min(v, expiry) v FROM deriv
              WHERE exch=? AND und=? AND typ='FUT' AND expiry >= ts::DATE GROUP BY ts ORDER BY ts""", [exch, und])
    # sessions missing from the spot series -> fill with near-month future bars
    have = set(np.unique(r["ts"].astype("datetime64[D]")).tolist())
    fd = fv["ts"].astype("datetime64[D]")
    miss = np.array([x not in have for x in fd.tolist()], bool) if len(fd) else np.zeros(0, bool)
    if miss.any() and src != "future":
        fb = q("""SELECT ts, arg_min(o, expiry) o, arg_min(h, expiry) h, arg_min(l, expiry) l, arg_min(c, expiry) c
                  FROM deriv WHERE exch=? AND und=? AND typ='FUT' AND expiry >= ts::DATE GROUP BY ts ORDER BY ts""", [exch, und])
        fm = np.array([x not in have for x in fb["ts"].astype("datetime64[D]").tolist()], bool)
        r = {k: np.concatenate([np.asarray(r[k]), np.asarray(fb[k])[fm]]) for k in ("ts", "o", "h", "l", "c")}
        order = np.argsort(r["ts"], kind="stable")
        r = {k: v[order] for k, v in r.items()}
    ts = r["ts"].astype("datetime64[m]")
    s = {"ts": ts, "o": r["o"].astype(float), "h": r["h"].astype(float), "l": r["l"].astype(float),
         "c": r["c"].astype(float), "src": src}
    fts = fv["ts"].astype("datetime64[m]")
    idx = np.searchsorted(fts, ts)
    ok = (idx < len(fts)) & (fts[np.minimum(idx, len(fts) - 1)] == ts)
    s["v"] = np.where(ok, fv["v"][np.minimum(idx, len(fts) - 1)], 0.0).astype(float)
    s["fut"] = np.where(ok, fv["c"][np.minimum(idx, len(fts) - 1)], np.nan).astype(float)
    _cache[key] = s
    return s


class Day:
    """All option/future bars of one underlying for one session, for a set of expiries."""

    def __init__(self, exch, und, d: date, expiries, r=None):
        self.d = d
        self.dense = {}
        self.keys = {}
        start = datetime.combine(d, datetime.min.time())
        if r is None:
            if not expiries:
                return
            ym = d.strftime("%Y-%m")
            ph = ",".join("?" * len(expiries))
            r = q(f"""SELECT expiry, typ, coalesce(strike, 0) strike, ts, o, h, l, c, v, oi FROM deriv
                      WHERE exch=? AND und=? AND ym=? AND ts>=? AND ts<? AND expiry IN ({ph})
                      ORDER BY expiry, typ, strike, ts""",
                  [exch, und, ym, start, start + timedelta(days=1), *expiries])
        n = len(r["ts"])
        self.r = r
        mins = ((r["ts"].astype("datetime64[m]") - np.datetime64(start, "m")).astype(int) - OPEN_MIN) if n else np.array([], int)
        self.mins = mins
        self.keys = {}
        if n:
            exp = r["expiry"].astype("datetime64[D]")
            typ = r["typ"]
            k = np.stack([exp.astype(int), np.select([typ == "CE", typ == "PE"], [0, 1], 2), r["strike"].astype(float)], 1)
            change = np.ones(n, bool)
            change[1:] = np.any(k[1:] != k[:-1], axis=1)
            starts = np.flatnonzero(change)
            ends = np.append(starts[1:], n)
            for s0, e0 in zip(starts, ends):
                key = (str(exp[s0]), str(typ[s0]), float(r["strike"][s0]))
                self.keys[key] = (s0, e0)

    def strikes(self, expiry, typ):
        return sorted(k[2] for k in self.keys if k[0] == expiry and k[1] == typ)

    def bars(self, key):
        """Dense per-minute arrays: o,h,l,c with NaN where no trade, px = fill price series."""
        if key in self.dense:
            return self.dense[key]
        if key not in self.keys:
            return None
        s0, e0 = self.keys[key]
        m = self.mins[s0:e0]
        ok = (m >= 0) & (m < MINUTES)
        m = m[ok]
        arr = {}
        for f in ("o", "h", "l", "c", "v", "oi"):
            a = np.full(MINUTES, np.nan)
            a[m] = self.r[f][s0:e0][ok]
            if f in ("o", "h", "l"):
                a[a <= 0] = np.nan
            arr[f] = a
        # carry-forward last close; fill price at minute X = open(X) or last close before X
        last = np.full(MINUTES, np.nan)
        cur = np.nan
        for i in range(MINUTES):
            last[i] = cur
            if not math.isnan(arr["c"][i]):
                cur = arr["c"][i]
        arr["prev_close"] = last
        arr["px"] = np.where(np.isnan(arr["o"]), last, arr["o"])
        arr["mark"] = np.where(np.isnan(arr["c"]), last, arr["c"])  # mark at end of minute
        self.dense[key] = arr
        return arr

    def price_at(self, key, m):
        b = self.bars(key)
        if b is None:
            return float("nan")
        return float(b["px"][m])


# ----------------------------------------------------------------------------- indicators

def _ema(x, n):
    out = np.full(len(x), np.nan)
    if n <= 0 or len(x) == 0:
        return out
    a = 2 / (n + 1)
    v = np.nan
    for i, xi in enumerate(x):
        if math.isnan(xi):
            out[i] = v
            continue
        v = xi if math.isnan(v) else a * xi + (1 - a) * v
        out[i] = v
    out[: min(n - 1, len(x))] = np.nan
    return out


def _rma(x, n):
    out = np.full(len(x), np.nan)
    v = np.nan
    for i, xi in enumerate(x):
        if math.isnan(xi):
            out[i] = v
            continue
        v = xi if math.isnan(v) else (v * (n - 1) + xi) / n
        out[i] = v
    out[: min(n, len(x))] = np.nan
    return out


def _roll(x, n, fn):
    out = np.full(len(x), np.nan)
    if n <= 0 or len(x) < n:
        return out
    w = np.lib.stride_tricks.sliding_window_view(np.asarray(x, float), n)
    out[n - 1:] = fn(w, axis=1)
    return out


def _wma(x, n):
    wts = np.arange(1, n + 1)
    return _roll(x, n, lambda w, axis: (w * wts).sum(axis=axis) / wts.sum())


FIELDS = ("Open", "High", "Low", "Close", "Volume", "HL2", "HLC3", "OHLC4")

# Indicators that accept an arbitrary source series via operand "of".
SOURCE_INDICATORS = {"SMA", "EMA", "RMA", "WMA", "HMA", "DEMA", "TEMA", "VWMA", "RSI", "MACD", "MACDSignal",
                     "MACDHist", "UpperBB", "LowerBB", "MidBB", "Stdev", "Zscore", "ROC", "Momentum",
                     "Highest", "Lowest", "Change", "ChangePct", "CCI"}


class Candles:
    """Underlying resampled to a timeframe (aligned to 09:15 each session)."""

    def __init__(self, s, tf: int):
        ts = s["ts"]
        day = ts.astype("datetime64[D]")
        mins = (ts - day).astype(int) - OPEN_MIN
        keep = (mins >= 0) & (mins < MINUTES)
        ts, day, mins = ts[keep], day[keep], mins[keep]
        bucket = mins // tf
        gid = day.astype(int) * 1000 + bucket
        change = np.ones(len(gid), bool)
        change[1:] = gid[1:] != gid[:-1]
        st = np.flatnonzero(change)
        en = np.append(st[1:], len(gid))
        o, h, l, c, v = (s[k][keep] for k in ("o", "h", "l", "c", "v"))
        self.day = day[st]
        # candle is "known" at the close of its last minute -> actionable at next minute
        self.end_min = np.minimum((bucket[st] + 1) * tf, MINUTES - 1)
        self.o = o[st]
        self.h = np.maximum.reduceat(h, st)
        self.l = np.minimum.reduceat(l, st)
        self.c = c[en - 1]
        self.v = np.add.reduceat(v, st)
        self.n = len(st)
        self._cache = {}
        # session boundaries
        dchange = np.ones(self.n, bool)
        dchange[1:] = self.day[1:] != self.day[:-1]
        self.sess_id = np.cumsum(dchange) - 1
        self.day_first = np.flatnonzero(dchange)

    def field(self, name):
        if name == "HL2":
            return (self.h + self.l) / 2
        if name == "HLC3":
            return (self.h + self.l + self.c) / 3
        if name == "OHLC4":
            return (self.o + self.h + self.l + self.c) / 4
        return {"Open": self.o, "High": self.h, "Low": self.l, "Close": self.c, "Volume": self.v}[name]

    def ind(self, name, n=14, src="Close", n2=0, n3=0, x=None, xkey=None):
        """Indicator series. `x` overrides the source series (indicator-of-indicator); `xkey`
        identifies it for caching."""
        key = (name, n, src, n2, n3, xkey)
        if key in self._cache:
            return self._cache[key]
        if x is None:
            x = self.field(src) if src in FIELDS else self.c
        n = int(n or 14)
        if name in FIELDS:
            out = self.field(name)
        elif name == "SMA":
            out = _roll(x, n, np.mean)
        elif name == "EMA":
            out = _ema(x, n)
        elif name == "RMA":
            out = _rma(x, n)
        elif name == "WMA":
            out = _wma(x, n)
        elif name == "HMA":
            out = _wma(2 * _wma(x, max(n // 2, 1)) - _wma(x, n), max(int(math.sqrt(n)), 1))
        elif name == "DEMA":
            e1 = _ema(x, n)
            out = 2 * e1 - _ema(e1, n)
        elif name == "TEMA":
            e1 = _ema(x, n)
            e2 = _ema(e1, n)
            out = 3 * e1 - 3 * e2 + _ema(e2, n)
        elif name == "VWMA":
            out = _roll(x * self.v, n, np.sum) / np.where(_roll(self.v, n, np.sum) > 0, _roll(self.v, n, np.sum), np.nan)
        elif name == "Highest":
            out = _roll(x, n, np.max)
        elif name == "Lowest":
            out = _roll(x, n, np.min)
        elif name in ("ADX", "PlusDI", "MinusDI"):
            up = np.diff(self.h, prepend=np.nan)
            dn = -np.diff(self.l, prepend=np.nan)
            pdm = np.where((up > dn) & (up > 0), up, 0.0)
            mdm = np.where((dn > up) & (dn > 0), dn, 0.0)
            atr = self.ind("ATR", n)
            with np.errstate(all="ignore"):
                pdi = 100 * _rma(pdm, n) / atr
                mdi = 100 * _rma(mdm, n) / atr
                dx = 100 * np.abs(pdi - mdi) / (pdi + mdi)
            sm = int(n2 or n)
            out = {"PlusDI": pdi, "MinusDI": mdi, "ADX": _rma(np.nan_to_num(dx), sm)}[name]
            if name == "ADX":
                out[: 2 * n] = np.nan
        elif name in ("StochK", "StochD"):
            hh, ll = _roll(self.h, n, np.max), _roll(self.l, n, np.min)
            with np.errstate(all="ignore"):
                raw = 100 * (self.c - ll) / (hh - ll)
            k = _roll(raw, int(n2 or 3), np.mean)
            out = k if name == "StochK" else _roll(k, int(n3 or 3), np.mean)
        elif name == "CCI":
            tp = self.field("HLC3") if src == "Close" and xkey is None else x
            m = _roll(tp, n, np.mean)
            md = _roll(tp, n, lambda w, axis: np.abs(w - w.mean(axis=axis, keepdims=True)).mean(axis=axis))
            with np.errstate(all="ignore"):
                out = (tp - m) / (0.015 * md)
        elif name == "WilliamsR":
            hh, ll = _roll(self.h, n, np.max), _roll(self.l, n, np.min)
            with np.errstate(all="ignore"):
                out = -100 * (hh - self.c) / (hh - ll)
        elif name == "VIX":
            if getattr(self, "vix", None) is None:
                raise ValueError("India VIX data is not available")
            out = self.vix
        elif name == "OBV":
            out = np.cumsum(np.sign(np.nan_to_num(np.diff(self.c, prepend=np.nan))) * self.v)
        elif name == "RSI":
            d = np.diff(x, prepend=np.nan)
            up, dn = _rma(np.where(d > 0, d, 0.0), n), _rma(np.where(d < 0, -d, 0.0), n)
            out = 100 - 100 / (1 + up / np.where(dn == 0, np.nan, dn))
            out = np.where((dn == 0) & (up > 0), 100.0, out)
        elif name in ("MACD", "MACDSignal", "MACDHist"):
            f, sl, sg = n or 12, int(n2 or 26), int(n3 or 9)
            macd = _ema(x, f) - _ema(x, sl)
            sig = _ema(np.nan_to_num(macd, nan=0.0), sg)
            sig[np.isnan(macd)] = np.nan
            out = {"MACD": macd, "MACDSignal": sig, "MACDHist": macd - sig}[name]
        elif name in ("UpperBB", "LowerBB", "MidBB"):
            k = float(n2 or 2)
            m, sd = _roll(x, n, np.mean), _roll(x, n, np.std)
            out = {"UpperBB": m + k * sd, "LowerBB": m - k * sd, "MidBB": m}[name]
        elif name == "Stdev":
            out = _roll(x, n, np.std)
        elif name == "Zscore":
            out = (x - _roll(x, n, np.mean)) / _roll(x, n, np.std)
        elif name == "ROC":
            out = np.full(self.n, np.nan)
            out[n:] = (x[n:] / x[:-n] - 1) * 100
        elif name == "Momentum":
            out = np.full(self.n, np.nan)
            out[n:] = x[n:] - x[:-n]
        elif name == "HighestHigh":
            out = _roll(self.h, n, np.max)
        elif name == "LowestLow":
            out = _roll(self.l, n, np.min)
        elif name == "ATR":
            pc = np.roll(self.c, 1)
            pc[0] = np.nan
            tr = np.nanmax(np.stack([self.h - self.l, np.abs(self.h - pc), np.abs(self.l - pc)]), axis=0)
            out = _rma(tr, n)
        elif name in ("Supertrend", "SupertrendDir"):
            mult = float(n2 or 3)
            atr = self.ind("ATR", n)
            hl2 = (self.h + self.l) / 2
            ub, lb = hl2 + mult * atr, hl2 - mult * atr
            st = np.full(self.n, np.nan)
            dr = np.zeros(self.n)
            fu, fl = np.nan, np.nan
            for i in range(self.n):
                if math.isnan(atr[i]):
                    continue
                fu = ub[i] if (math.isnan(fu) or ub[i] < fu or self.c[i - 1] > fu) else fu
                fl = lb[i] if (math.isnan(fl) or lb[i] > fl or self.c[i - 1] < fl) else fl
                prev = dr[i - 1] if i else 1
                d_ = 1 if self.c[i] > fu else (-1 if self.c[i] < fl else (prev or 1))
                dr[i] = d_
                st[i] = fl if d_ == 1 else fu
            out = st if name == "Supertrend" else dr
        elif name == "VWAP":
            tp = (self.h + self.l + self.c) / 3
            out = np.full(self.n, np.nan)
            for a, b in zip(self.day_first, np.append(self.day_first[1:], self.n)):
                vv = self.v[a:b]
                cv = np.cumsum(vv)
                out[a:b] = np.where(cv > 0, np.cumsum(tp[a:b] * vv) / np.where(cv > 0, cv, 1), np.nan)
        elif name in ("DayOpen", "DayHigh", "DayLow", "PrevDayHigh", "PrevDayLow", "PrevDayClose",
                      "ORHigh", "ORLow"):
            out = np.full(self.n, np.nan)
            bounds = list(zip(self.day_first, np.append(self.day_first[1:], self.n)))
            prev = None
            for a, b in bounds:
                if name == "DayOpen":
                    out[a:b] = self.o[a]
                elif name == "DayHigh":
                    out[a:b] = np.maximum.accumulate(self.h[a:b])
                elif name == "DayLow":
                    out[a:b] = np.minimum.accumulate(self.l[a:b])
                elif name.startswith("Prev") and prev is not None:
                    pa, pb = prev
                    out[a:b] = {"PrevDayHigh": self.h[pa:pb].max(), "PrevDayLow": self.l[pa:pb].min(),
                                "PrevDayClose": self.c[pb - 1]}[name]
                elif name in ("ORHigh", "ORLow"):
                    # opening range of first n candles; known only after it completes
                    k = min(n, b - a)
                    v = self.h[a:a + k].max() if name == "ORHigh" else self.l[a:a + k].min()
                    out[a + k - 1:b] = v
                prev = (a, b)
        elif name == "Change":
            out = np.full(self.n, np.nan)
            out[1:] = x[1:] - x[:-1]
        elif name == "ChangePct":
            out = np.full(self.n, np.nan)
            out[1:] = (x[1:] / x[:-1] - 1) * 100
        else:
            raise ValueError(f"unknown indicator {name}")
        self._cache[key] = out
        return out


# ----------------------------------------------------------------------------- conditions

EXPR_OPS = {
    "+": lambda a, b: a + b, "-": lambda a, b: a - b, "*": lambda a, b: a * b,
    "/": lambda a, b: a / np.where(b == 0, np.nan, b), "pow": lambda a, b: np.power(a, b),
    "max": np.fmax, "min": np.fmin,
}
EXPR_UNARY = {"neg": lambda a: -a, "abs": np.abs, "sqrt": lambda a: np.sqrt(np.where(a < 0, np.nan, a)),
              "log": lambda a: np.log(np.where(a <= 0, np.nan, a))}


def series(op, C: Candles):
    """Compile a market operand (ind / const / dt / expr) to a per-candle float array.

    Operand shapes:
      {"kind":"const","value":1.5}
      {"kind":"ind","name":"EMA","n":20,"src":"Close","n2":0,"n3":0,"offset":0,"of":<operand>?}
      {"kind":"dt","field":"Time|Hour|Minute|WeekDay"}
      {"kind":"expr","op":"+|-|*|/|pow|max|min|neg|abs|sqrt|log","args":[<operand>, ...],"offset":0}
    `offset` k reads the value k candles back (Pine's x[k]).
    """
    k = op.get("kind", "ind")
    ck = ("S", json.dumps(op, sort_keys=True))
    if ck in C._cache:
        return C._cache[ck]
    if k == "const":
        out = np.full(C.n, float(op.get("value", 0)))
    elif k == "dt":
        f = op.get("field", "Time")
        t = OPEN_MIN + C.end_min.astype(int)
        if f == "Time":
            out = ((t // 60) * 100 + t % 60).astype(float)
        elif f == "Hour":
            out = (t // 60).astype(float)
        elif f == "Minute":
            out = (t % 60).astype(float)
        elif f == "WeekDay":
            out = ((C.day.astype("datetime64[D]").astype(int) + 3) % 7 + 1).astype(float)  # 1970-01-01 = Thu
        else:
            raise ValueError(f"unknown dt field {f}")
    elif k == "expr":
        fn = op.get("op")
        args = [series(a, C) for a in op.get("args") or []]
        with np.errstate(all="ignore"):
            if fn in EXPR_UNARY and len(args) == 1:
                out = EXPR_UNARY[fn](args[0])
            elif fn in EXPR_OPS and len(args) >= 2:
                out = args[0]
                for a in args[1:]:
                    out = EXPR_OPS[fn](out, a)
            else:
                raise ValueError(f"bad expression op {fn} with {len(args)} args")
        out = np.asarray(out, float)
    elif k == "ind":
        name = op.get("name", "Close")
        of = op.get("of")
        x = xkey = None
        if of:
            if name not in SOURCE_INDICATORS:
                raise ValueError(f"{name} cannot take a custom source")
            x, xkey = series(of, C), json.dumps(of, sort_keys=True)
        out = C.ind(name, int(op.get("n") or 14), op.get("src", "Close"),
                    float(op.get("n2") or 0), float(op.get("n3") or 0), x=x, xkey=xkey)
    elif k == "pos":
        raise ValueError("position fields (PnL, MinsInTrade…) can only be used directly in exit rules")
    else:
        raise ValueError(f"unknown operand kind {k}")
    shift = int(op.get("offset") or 0)
    if shift > 0:
        sh = np.full(C.n, np.nan)
        sh[shift:] = out[:-shift] if shift < C.n else []
        out = sh
    C._cache[ck] = out
    return out


def eval_operand(op, C: Candles, ci: int, ctx):
    """Return (value_now, value_prev) for an operand at candle index ci."""
    if op.get("kind") == "pos":
        f = op.get("field", "PnL")
        return ctx.get(f, float("nan")), ctx.get("prev_" + f, float("nan"))
    a = series(op, C)
    cur = a[ci] if ci >= 0 else np.nan
    prv = a[ci - 1] if ci - 1 >= 0 else np.nan
    return float(cur), float(prv)


def eval_rule(r, C, ci, ctx):
    if "rules" in r:
        v = eval_block(r, C, ci, ctx)
        return bool(v)
    if "not" in r:
        return not eval_rule(r["not"], C, ci, ctx)
    zero = {"kind": "const", "value": 0}
    l, lp = eval_operand(r.get("lhs") or zero, C, ci, ctx)
    rv, rp = eval_operand(r.get("rhs") or zero, C, ci, ctx)
    op = r.get("op", ">")
    if op in ("is_true", "is_false"):  # lhs as boolean series (non-zero = true)
        return (not math.isnan(l) and l != 0) == (op == "is_true")
    if op == "!=":
        return not any(math.isnan(x) for x in (l, rv)) and abs(l - rv) >= 1e-9
    if op == "crosses":
        return eval_rule({**r, "op": "crosses_above"}, C, ci, ctx) or eval_rule({**r, "op": "crosses_below"}, C, ci, ctx)
    if any(math.isnan(x) for x in (l, rv)):
        return False
    if op == ">":
        return l > rv
    if op == ">=":
        return l >= rv
    if op == "<":
        return l < rv
    if op == "<=":
        return l <= rv
    if op == "==":
        return abs(l - rv) < 1e-9
    if op in ("crosses_above", "crosses_below"):
        if math.isnan(lp) or math.isnan(rp):
            return False
        return (lp <= rp and l > rv) if op == "crosses_above" else (lp >= rp and l < rv)
    raise ValueError(op)


def eval_block(block, C, ci, ctx):
    """{"logic":"AND|OR","rules":[rule | block | {"not": rule}]} -> bool, or None if empty."""
    rules = (block or {}).get("rules") or []
    if not rules:
        return None
    if block.get("logic", "AND") == "AND":
        return all(eval_rule(r, C, ci, ctx) for r in rules)
    return any(eval_rule(r, C, ci, ctx) for r in rules)


def block_uses_pos(block):
    """True if any rule references a position field (needs a live position to evaluate)."""
    return '"kind": "pos"' in json.dumps(block or {}, sort_keys=True)


def validate_conditions(block, C):
    """Compile every market operand once so bad configs fail fast with a clear message."""
    def walk(r):
        if "rules" in r:
            for x in r["rules"]:
                walk(x)
        elif "not" in r:
            walk(r["not"])
        else:
            for side in ("lhs", "rhs"):
                o = r.get(side) or {"kind": "const", "value": 0}
                if o.get("kind") != "pos":
                    series(o, C)
    if block and block.get("rules"):
        walk(block)


# ----------------------------------------------------------------------------- pricing helpers

def _ncdf(x):
    return 0.5 * (1 + math.erf(x / math.sqrt(2)))


def bs_price(S, K, T, sig, cp):
    if T <= 0 or sig <= 0:
        return max(0.0, (S - K) if cp == "CE" else (K - S))
    d1 = (math.log(S / K) + (RISK_FREE + sig * sig / 2) * T) / (sig * math.sqrt(T))
    d2 = d1 - sig * math.sqrt(T)
    if cp == "CE":
        return S * _ncdf(d1) - K * math.exp(-RISK_FREE * T) * _ncdf(d2)
    return K * math.exp(-RISK_FREE * T) * _ncdf(-d2) - S * _ncdf(-d1)


def implied_vol(P, S, K, T, cp):
    intrinsic = max(0.0, (S - K) if cp == "CE" else (K - S))
    if T <= 0 or P <= intrinsic + 1e-6:
        return float("nan")
    lo, hi = 1e-3, 5.0
    for _ in range(60):
        mid = (lo + hi) / 2
        if bs_price(S, K, T, mid, cp) > P:
            hi = mid
        else:
            lo = mid
    return (lo + hi) / 2


def bs_delta(S, K, T, sig, cp):
    if T <= 0 or not sig or math.isnan(sig):
        return float("nan")
    d1 = (math.log(S / K) + (RISK_FREE + sig * sig / 2) * T) / (sig * math.sqrt(T))
    return _ncdf(d1) if cp == "CE" else _ncdf(d1) - 1


def years_to_expiry(d: date, m: int, expiry: date):
    mins = (expiry - d).days * 1440 + (MINUTES - 1 - m)
    return max(mins, 1) / (365 * 1440)


# ----------------------------------------------------------------------------- charges

def charges(exch, typ, side, price, qty, d: date, cfg):
    turnover = price * qty
    opt = typ != "FUT"
    brokerage = float(cfg.get("brokerage", 20.0))
    if cfg.get("brokeragePct"):
        brokerage = min(brokerage, turnover * float(cfg["brokeragePct"]) / 100)
    stt = 0.0
    if side == "SELL":
        # STT: Oct-2024 rates; Finance Act 2026 revision from 1-Apr-2026
        if d >= date(2026, 4, 1):
            stt = turnover * (0.0015 if opt else 0.0005)
        else:
            stt = turnover * (0.001 if opt else 0.0002)
    if exch == "NFO":
        txn = turnover * (0.0003503 if opt else 0.0000173)
    else:
        txn = turnover * (0.000325 if opt else 0.0)
    sebi = turnover * 1e-6
    stamp = turnover * (0.00003 if opt else 0.00002) if side == "BUY" else 0.0
    gst = 0.18 * (brokerage + txn + sebi)
    if not cfg.get("enabled", True):
        return 0.0
    return brokerage + stt + txn + sebi + stamp + gst


# ----------------------------------------------------------------------------- strategy

@dataclass
class Leg:
    cfg: dict
    idx: int
    key: tuple = None
    side: str = "SELL"
    qty: int = 0
    entry_px: float = 0.0
    entry_min: int = 0
    entry_day: date = None
    sl: float = float("nan")
    tgt: float = float("nan")
    best: float = float("nan")
    exit_px: float = float("nan")
    exit_min: int = -1
    exit_day: date = None
    reason: str = ""
    open: bool = True
    reentries_left: int = 0
    spot_in: float = float("nan")
    iv_in: float = float("nan")
    delta_in: float = float("nan")
    fees: float = 0.0
    parent: int = -1
    mae: float = 0.0
    mfe: float = 0.0

    @property
    def sign(self):
        return 1 if self.side == "BUY" else -1

    def pnl(self, mark):
        return self.sign * (mark - self.entry_px) * self.qty


class Cancelled(Exception):
    pass


class Backtest:
    def __init__(self, cfg: dict, progress=None, should_cancel=None):
        self.cfg = cfg
        self.progress = progress
        self.should_cancel = should_cancel
        self.exch = cfg.get("exch", "NFO")
        self.und = cfg["und"]
        self.m = meta()
        self.lots_tab = self.m["lots"].get(f"{self.exch}:{self.und}", {})
        self.exp_tab = expiry_table(self.exch, self.und)
        self.spot = spot_series(self.exch, self.und)
        self.tf = int(cfg.get("timeframe", 1))
        self.C = Candles(self.spot, self.tf)
        self.C.vix = vix_for(self.C)
        self.costs = cfg.get("costs", {})
        self.slip = float(self.costs.get("slippagePct", 0.0)) / 100
        self.trades = []
        self.warnings = []
        self.skipped = {}
        # spot minute lookup per day
        sday = self.spot["ts"].astype("datetime64[D]")
        self.spot_day_bounds = {}
        ch = np.ones(len(sday), bool)
        ch[1:] = sday[1:] != sday[:-1]
        st = np.flatnonzero(ch)
        for a, b in zip(st, np.append(st[1:], len(sday))):
            self.spot_day_bounds[sday[a].astype(object)] = (a, b)
        # candle index lookup: (day, end_min) -> candle idx
        self.candle_by_day = {}
        for a, b in zip(self.C.day_first, np.append(self.C.day_first[1:], self.C.n)):
            self.candle_by_day[self.C.day[a].astype(object)] = (a, b)
        # signal sides: "long" uses the top-level legs/conditions, optional "short" block mirrors it
        self.sides = {"long": {"legs": cfg.get("legs") or [], "entry": cfg.get("entryConds") or {},
                               "exit": cfg.get("exitConds") or {}}}
        sh = cfg.get("short") or {}
        if sh.get("legs") and (sh.get("entryConds") or {}).get("rules"):
            self.sides["short"] = {"legs": sh["legs"], "entry": sh["entryConds"], "exit": sh.get("exitConds") or {}}
        self.all_legs = [lc for s in self.sides.values() for lc in s["legs"]]
        for s in self.sides.values():
            if block_uses_pos(s["entry"]):
                raise ValueError("Entry rules cannot use position fields (PnL, MinsInTrade)")
            validate_conditions(s["entry"], self.C)
            validate_conditions(s["exit"], self.C)

    def load_day(self, d, need):
        """Day object, served from a per-month bulk load (one query per month)."""
        ym = d.strftime("%Y-%m")
        mc = getattr(self, "_month", None)
        if mc is None or mc["ym"] != ym or not need <= mc["exps"]:
            exps = set(need)
            for x in self.exp_tab:
                if x.strftime("%Y-%m") == ym:
                    for lc in self.all_legs:
                        e = self.pick_expiry(x, lc.get("expiry", "weekly"), lc.get("type", "CE"))
                        if e:
                            exps.add(e)
            if mc is not None and mc["ym"] == ym:
                exps |= mc["exps"]
            r = month_bars(self.exch, self.und, ym, exps)
            dd = r["d"].astype("datetime64[D]")
            bounds = {}
            if len(dd):
                ch = np.ones(len(dd), bool)
                ch[1:] = dd[1:] != dd[:-1]
                st = np.flatnonzero(ch)
                for a, b in zip(st, np.append(st[1:], len(dd))):
                    bounds[dd[a].astype(object)] = (a, b)
            mc = self._month = {"ym": ym, "exps": exps, "r": r, "bounds": bounds}
        if d not in mc["bounds"]:
            return Day(self.exch, self.und, d, [], r={k: v[:0] for k, v in mc["r"].items()})
        a, b = mc["bounds"][d]
        sub = {k: v[a:b] for k, v in mc["r"].items()}
        keep = np.isin(sub["expiry"].astype("datetime64[D]"), np.array(sorted(need), dtype="datetime64[D]")) if need else np.zeros(b - a, bool)
        return Day(self.exch, self.und, d, [], r={k: v[keep] for k, v in sub.items()})

    def skip(self, why):
        self.skipped[why] = self.skipped.get(why, 0) + 1

    # -- underlying minute array for a day
    def spot_day(self, d):
        if d not in self.spot_day_bounds:
            return None
        a, b = self.spot_day_bounds[d]
        ts = self.spot["ts"][a:b]
        mins = (ts - ts.astype("datetime64[D]")).astype(int) - OPEN_MIN
        ok = (mins >= 0) & (mins < MINUTES)
        arr = np.full(MINUTES, np.nan)
        arr[mins[ok]] = self.spot["o"][a:b][ok]
        # carry forward
        last = np.nan
        for i in range(MINUTES):
            if math.isnan(arr[i]):
                arr[i] = last
            else:
                last = arr[i]
        return arr

    # -- expiry resolution
    def pick_expiry(self, d, rule, typ):
        t = self.exp_tab.get(d)
        if not t:
            return None
        opt, fut = t["opt"], t["fut"]
        if typ == "FUT":
            i = {"monthly": 0, "next_monthly": 1, "far_monthly": 2}.get(rule, 0)
            return fut[i] if len(fut) > i else None
        if rule in ("weekly", "next_weekly", "far_weekly"):
            i = {"weekly": 0, "next_weekly": 1, "far_weekly": 2}[rule]
            return opt[i] if len(opt) > i else None
        monthlies = [e for e in fut if e in opt] or self._month_ends(opt)
        i = {"monthly": 0, "next_monthly": 1, "far_monthly": 2}.get(rule, 0)
        return monthlies[i] if len(monthlies) > i else None

    @staticmethod
    def _month_ends(exps):
        out = {}
        for e in exps:
            out[(e.year, e.month)] = max(out.get((e.year, e.month), e), e)
        return sorted(out.values())

    # -- strike resolution
    def pick_strike(self, day: Day, d, m, leg_cfg, expiry, typ, spot):
        es = str(expiry)
        strikes = day.strikes(es, typ)
        if not strikes:
            return None
        arr = np.array(strikes)
        diffs = np.diff(arr[(arr > spot * 0.9) & (arr < spot * 1.1)])
        step = float(np.median(diffs)) if len(diffs) else (float(np.median(np.diff(arr))) if len(arr) > 1 else 1.0)
        if leg_cfg.get("strikeStep"):
            step = float(leg_cfg["strikeStep"])
        mode = leg_cfg.get("strikeMode", "atm")
        val = float(leg_cfg.get("strikeValue", 0) or 0)

        def tradable(k):
            p = day.price_at((es, typ, float(k)), m)
            return not math.isnan(p) and p > 0

        if mode == "atm" or mode == "pct":
            if mode == "pct":
                target = spot * (1 + val / 100) if typ == "CE" else spot * (1 - val / 100)
            else:
                atm = round(spot / step) * step
                off = int(val)
                target = atm + off * step if typ == "CE" else atm - off * step
            cand = sorted(strikes, key=lambda k: abs(k - target))
            for k in cand[:6]:
                if tradable(k):
                    if abs(k - target) > step * 0.51:
                        self.skip("strike substituted (nearest traded)")
                    return float(k)
            return None
        # premium / delta based: scan strikes within +-20%
        best, bestd = None, float("inf")
        T = years_to_expiry(d, m, expiry)
        for k in strikes:
            if not (spot * 0.8 < k < spot * 1.2):
                continue
            p = day.price_at((es, typ, float(k)), m)
            if math.isnan(p) or p <= 0:
                continue
            if mode == "premium":
                dist = abs(p - val)
            elif mode == "premium_gte":
                dist = p - val if p >= val else float("inf")
            elif mode == "premium_lte":
                dist = val - p if p <= val else float("inf")
            elif mode == "delta":
                iv = implied_vol(p, spot, k, T, typ)
                de = bs_delta(spot, k, T, iv, typ)
                if math.isnan(de):
                    continue
                dist = abs(abs(de) * 100 - abs(val))
            else:
                raise ValueError(mode)
            if dist < bestd:
                best, bestd = float(k), dist
        return best

    def lot_size(self, expiry):
        v = self.lots_tab.get(str(expiry))
        return int(v) if v else int(self.cfg.get("lotSizeFallback", 1))

    # -- fills
    def fill(self, side, px):
        return px * (1 + self.slip) if side == "BUY" else px * (1 - self.slip)

    def open_leg(self, lc, i, day, d, m, spot, parent=-1, key=None):
        typ = lc.get("type", "CE")
        if key is None:
            expiry = self.pick_expiry(d, lc.get("expiry", "weekly"), typ)
            if expiry is None:
                self.skip("no expiry available")
                return None
            if typ == "FUT":
                key = (str(expiry), "FUT", 0.0)
            else:
                k = self.pick_strike(day, d, m, lc, expiry, typ, spot)
                if k is None:
                    self.skip("no tradable strike")
                    return None
                key = (str(expiry), typ, k)
        px = day.price_at(key, m)
        if math.isnan(px) or px <= 0:
            self.skip("contract not traded at entry")
            return None
        side = lc.get("side", "SELL")
        exp_d = date.fromisoformat(key[0])
        L = Leg(cfg=lc, idx=i, key=key, side=side)
        L.qty = int(lc.get("lots", 1)) * int(self.cfg.get("lotMultiplier", 1)) * self.lot_size(exp_d)
        L.entry_px = self.fill(side, px)
        L.entry_min, L.entry_day = m, d
        L.spot_in = spot
        L.best = L.entry_px
        if typ != "FUT":
            T = years_to_expiry(d, m, exp_d)
            L.iv_in = implied_vol(px, spot, key[2], T, typ)
            L.delta_in = bs_delta(spot, key[2], T, L.iv_in, typ)
        L.parent = parent
        L.reentries_left = int(lc.get("reentries", 0)) if parent < 0 else 0
        self.set_levels(L)
        L.fees += charges(self.exch, typ, side, L.entry_px, L.qty, d, self.costs)
        return L

    def set_levels(self, L: Leg):
        lc, e, s = L.cfg, L.entry_px, L.sign
        slv, slt = float(lc.get("sl") or 0), lc.get("slType", "pct")
        tv, tt = float(lc.get("tgt") or 0), lc.get("tgtType", "pct")
        dist = lambda v, t: (e * v / 100) if t == "pct" else v
        L.sl = e - s * dist(slv, slt) if slv > 0 else float("nan")
        L.tgt = e + s * dist(tv, tt) if tv > 0 else float("nan")
        if s == 1 and not math.isnan(L.sl):
            L.sl = max(L.sl, 0.05)
        if s == -1 and not math.isnan(L.tgt):
            L.tgt = max(L.tgt, 0.05)

    def trail(self, L: Leg, b, m):
        lc = L.cfg
        x, y = float(lc.get("trailX") or 0), float(lc.get("trailY") or 0)
        if x <= 0 or y <= 0 or math.isnan(L.sl):
            return
        pct = lc.get("trailType", "pct") == "pct"
        X = L.entry_px * x / 100 if pct else x
        Y = L.entry_px * y / 100 if pct else y
        fav = b["l"][m] if L.sign == -1 else b["h"][m]
        if math.isnan(fav):
            return
        L.best = min(L.best, fav) if L.sign == -1 else max(L.best, fav)
        moved = (L.entry_px - L.best) if L.sign == -1 else (L.best - L.entry_px)
        steps = math.floor(moved / X) if X > 0 else 0
        if steps <= 0:
            return
        base = self._base_sl(L)
        new = base - steps * Y if L.sign == -1 else base + steps * Y
        L.sl = min(L.sl, new) if L.sign == -1 else max(L.sl, new)

    def _base_sl(self, L):
        lc, e = L.cfg, L.entry_px
        v, t = float(lc.get("sl") or 0), lc.get("slType", "pct")
        d = e * v / 100 if t == "pct" else v
        return e + d if L.sign == -1 else e - d

    def close_leg(self, L: Leg, px, m, d, reason):
        L.exit_px = self.fill("SELL" if L.side == "BUY" else "BUY", px)
        L.exit_min, L.exit_day, L.reason, L.open = m, d, reason, False
        L.fees += charges(self.exch, L.key[1], "SELL" if L.side == "BUY" else "BUY", L.exit_px, L.qty, d, self.costs)

    # -- main loop
    def run(self):
        cfg = self.cfg
        start = date.fromisoformat(cfg["start"])
        end = date.fromisoformat(cfg["end"])
        sessions = set(self.m.get("calendar") or [])
        days = sorted(d for d in self.exp_tab if start <= d <= end and (not sessions or str(d) in sessions))
        if not days:
            raise ValueError("No data in selected range for this underlying")
        weekdays = set(cfg.get("weekdays") or [1, 2, 3, 4, 5])
        positional = cfg.get("mode", "intraday") == "positional"
        entry_m = to_min(cfg.get("entryTime", "09:20"))
        exit_m = to_min(cfg.get("exitTime", "15:15"))
        last_entry_m = to_min(cfg.get("lastEntryTime", cfg.get("exitTime", "15:15")))
        max_trades = int(cfg.get("maxTradesPerDay", 1))
        dte_min, dte_max = cfg.get("dteMin"), cfg.get("dteMax")
        ov = cfg.get("overall", {})
        # signal mode: any side with entry rules; sides without rules never trade in signal mode
        signal_sides = [k for k, s in self.sides.items() if (s["entry"] or {}).get("rules")]
        has_entry_conds = bool(signal_sides)
        exit_on_opp = bool(cfg.get("exitOnOpposite")) and len(signal_sides) > 1
        exit_days_before = int(cfg.get("exitDaysBeforeExpiry", 0))
        legs_cfg = self.sides["long"]["legs"] or self.all_legs
        if not legs_cfg:
            raise ValueError("Add at least one leg")

        pos = None  # open position spanning days (positional)
        for di, d in enumerate(days):
            if self.should_cancel and self.should_cancel():
                raise Cancelled()
            if self.progress and di % 5 == 0:
                self.progress(di, len(days))
            if d.isoweekday() not in weekdays and pos is None:
                continue
            spot = self.spot_day(d)
            if spot is None:
                self.skip("no underlying data")
                continue
            # expiries needed today
            need = set()
            for lc in self.all_legs:
                e = self.pick_expiry(d, lc.get("expiry", "weekly"), lc.get("type", "CE"))
                if e:
                    need.add(e)
            if pos:
                need |= {date.fromisoformat(L.key[0]) for L in pos["legs"] if L.open}
            day = self.load_day(d, need)
            c_bounds = self.candle_by_day.get(d)
            trades_today = 0
            # dte filter based on first leg's expiry
            e0 = self.pick_expiry(d, legs_cfg[0].get("expiry", "weekly"), legs_cfg[0].get("type", "CE"))
            dte = (e0 - d).days if e0 else None
            dte_ok = e0 is not None and (dte_min in (None, "") or dte >= int(dte_min)) and \
                (dte_max in (None, "") or dte <= int(dte_max))
            entry_allowed_today = d.isoweekday() in weekdays and dte_ok
            if not dte_ok and pos is None:
                self.skip("DTE filter")
            # candle index at each minute (last completed candle)
            cand_at = np.full(MINUTES, -1)
            if c_bounds:
                a, b = c_bounds
                for ci in range(a, b):
                    em = int(self.C.end_min[ci])
                    cand_at[min(em, MINUTES - 1):] = ci
                # a candle is complete at end_min -> usable to act at minute end_min
            m = 0
            prev_pnl = 0.0
            for m in range(MINUTES):
                sp = spot[m]
                if math.isnan(sp):
                    continue
                ci = cand_at[m]
                new_candle = ci >= 0 and self.C.end_min[ci] == m and (self.tf == 1 or True)
                # ---------------- manage open position
                if pos:
                    legs = [L for L in pos["legs"] if L.open]
                    for L in legs:
                        b = day.bars(L.key)
                        if b is None:
                            continue
                        if m <= L.entry_min and L.entry_day == d:
                            continue
                        o, h, l = b["o"][m], b["h"][m], b["l"][m]
                        if math.isnan(h):
                            continue
                        hit_sl = not math.isnan(L.sl) and ((h >= L.sl) if L.sign == -1 else (l <= L.sl))
                        hit_tg = not math.isnan(L.tgt) and ((l <= L.tgt) if L.sign == -1 else (h >= L.tgt))
                        if hit_sl:
                            px = max(L.sl, o) if L.sign == -1 else min(L.sl, o)
                            trailed = abs(L.sl - self._base_sl(L)) > 1e-9
                            self.close_leg(L, px, m, d, "trail_sl" if trailed else "leg_sl")
                            self.after_leg_sl(pos, L, day, d, m, sp, exit_m)
                        elif hit_tg:
                            px = min(L.tgt, o) if L.sign == -1 else max(L.tgt, o)
                            self.close_leg(L, px, m, d, "leg_target")
                        else:
                            self.trail(L, b, m)
                    # re-entry on cost
                    for pend in list(pos.get("pending", [])):
                        L0 = pend["leg"]
                        b = day.bars(L0.key)
                        if b is None or m <= L0.exit_min or m > last_entry_m:
                            continue
                        lvl = pend["level"]
                        lo, hi = b["l"][m], b["h"][m]
                        if not math.isnan(lo) and lo <= lvl <= hi:
                            nl = self.open_leg(L0.cfg, L0.idx, day, d, m, sp, parent=L0.idx, key=L0.key)
                            if nl:
                                nl.entry_px = self.fill(nl.side, lvl)
                                self.set_levels(nl)
                                nl.best = nl.entry_px
                                pos["legs"].append(nl)
                                pend["left"] -= 1
                                pos["pending"].remove(pend)
                                if pend["left"] > 0:
                                    nl.reentries_left = pend["left"]
                    # MTM
                    mtm = self.mtm(pos, day, m)
                    pos["mae"] = min(pos["mae"], mtm)
                    pos["mfe"] = max(pos["mfe"], mtm)
                    self.overall_lock(pos, mtm, ov)
                    reason = None
                    if ov.get("sl") and mtm <= -abs(float(ov["sl"])):
                        reason = "overall_sl"
                    elif ov.get("tgt") and mtm >= abs(float(ov["tgt"])):
                        reason = "overall_target"
                    elif pos.get("lock") is not None and mtm <= pos["lock"]:
                        reason = "profit_lock"
                    elif ov.get("slPctCapital") and mtm <= -abs(float(ov["slPctCapital"])) / 100 * float(cfg.get("capital", 1e6)):
                        reason = "overall_sl"
                    # exit conditions (on completed candle)
                    side_exit = self.sides[pos["side"]]["exit"]
                    if reason is None and new_candle and (side_exit or {}).get("rules"):
                        ctx = {"PnL": mtm, "prev_PnL": prev_pnl,
                               "PnLpct": mtm / max(pos["premium"], 1e-9) * 100,
                               "MinsInTrade": self.mins_in(pos, d, m)}
                        if eval_block(side_exit, self.C, ci, ctx):
                            reason = "exit_signal"
                    if reason is None and exit_on_opp and new_candle:
                        opp = "short" if pos["side"] == "long" else "long"
                        if eval_block(self.sides[opp]["entry"], self.C, ci, {}):
                            reason = "opposite_signal"
                    prev_pnl = mtm
                    # time exit
                    expiry_exit = False
                    if positional:
                        exps = [date.fromisoformat(L.key[0]) for L in pos["legs"] if L.open]
                        if exps and (min(exps) - d).days <= exit_days_before and m >= exit_m:
                            expiry_exit = True
                    if reason is None and ((not positional and m >= exit_m) or expiry_exit):
                        reason = "time_exit" if not positional else "expiry_exit"
                    if reason is None and not any(L.open for L in pos["legs"]) and not pos.get("pending"):
                        reason = "all_legs_closed"
                    if reason is None and cfg.get("exitAllOnLegSl") and pos.get("any_sl"):
                        reason = "leg_sl_exit_all"
                    if reason:
                        # fill next minute (or now if last minute)
                        fm = min(m + 1, MINUTES - 1) if reason not in ("time_exit", "expiry_exit") else m
                        for L in pos["legs"]:
                            if L.open:
                                p = day.price_at(L.key, fm)
                                if math.isnan(p):
                                    p = self.mark(day, L, m)
                                self.close_leg(L, p, fm, d, reason)
                        self.finish(pos)
                        pos = None
                        if reason in ("time_exit", "expiry_exit"):
                            pass
                # ---------------- entries
                if pos is None and entry_allowed_today and trades_today < max_trades and m < exit_m:
                    go = False
                    fill_m = m
                    side = "long"
                    if has_entry_conds:
                        if m >= entry_m and m <= last_entry_m and new_candle:
                            for sk in signal_sides:
                                if eval_block(self.sides[sk]["entry"], self.C, ci, {}):
                                    go, fill_m, side = True, min(m + 1, MINUTES - 1), sk
                                    break
                    else:
                        if m == entry_m or (trades_today > 0 and cfg.get("reenterAfterExit") and m <= last_entry_m
                                            and m > self._last_exit_min):
                            go = True
                    if go and fill_m < exit_m:
                        pos = self.enter(self.sides[side]["legs"] if has_entry_conds else legs_cfg, day, d, fill_m,
                                         spot[fill_m] if not math.isnan(spot[fill_m]) else sp)
                        if pos:
                            pos["side"] = side
                            trades_today += 1
                            prev_pnl = 0.0
            # end of session: intraday positions must be flat
            if pos and not positional:
                for L in pos["legs"]:
                    if L.open:
                        self.close_leg(L, self.mark(day, L, MINUTES - 1), MINUTES - 1, d, "eod")
                self.finish(pos)
                pos = None
            if pos:
                # drop pending re-entries overnight; close legs whose expiry passed
                pos["pending"] = []
                for L in pos["legs"]:
                    if L.open and date.fromisoformat(L.key[0]) <= d:
                        self.close_leg(L, self.mark(day, L, MINUTES - 1), MINUTES - 1, d, "expired")
                if not any(L.open for L in pos["legs"]):
                    self.finish(pos)
                    pos = None
            self._last_exit_min = -1
        if pos:
            self.warnings.append("Position still open at end of data; marked at last price.")
            for L in pos["legs"]:
                if L.open:
                    L.reason = "open_end"
            self.finish(pos, mark_open=True)
        return self.report()

    _last_exit_min = -1

    def enter(self, legs_cfg, day, d, m, sp):
        legs = []
        for i, lc in enumerate(legs_cfg):
            L = self.open_leg(lc, i, day, d, m, sp)
            if L is None:
                self.skip("entry failed (leg unavailable)")
                return None
            legs.append(L)
        prem = sum(L.entry_px * L.qty for L in legs)
        return {"legs": legs, "day": d, "min": m, "spot": sp, "premium": prem, "mae": 0.0, "mfe": 0.0,
                "pending": [], "lock": None, "any_sl": False, "day_ref": day, "side": "long"}

    def after_leg_sl(self, pos, L, day, d, m, sp, exit_m):
        pos["any_sl"] = True
        n = L.reentries_left
        if n <= 0 or m >= exit_m - 1:
            return
        mode = L.cfg.get("reentryMode", "immediate")
        if mode == "cost":
            pos["pending"].append({"leg": L, "level": L.entry_px / (1 - self.slip if L.side == "SELL" else 1 + self.slip),
                                   "left": n})
        else:
            nm = min(m + 1, MINUTES - 1)
            key = L.key if mode == "same_strike" else None
            nl = self.open_leg(L.cfg, L.idx, day, d, nm, sp, parent=L.idx, key=key)
            if nl:
                nl.reentries_left = n - 1
                pos["legs"].append(nl)

    def overall_lock(self, pos, mtm, ov):
        # lock: once profit reaches A, lock B; then for every X further, raise lock by Y
        A, B = float(ov.get("lockAt") or 0), float(ov.get("lockProfit") or 0)
        X, Y = float(ov.get("trailEvery") or 0), float(ov.get("trailBy") or 0)
        if A > 0 and pos["mfe"] >= A:
            lock = B
            if X > 0 and Y > 0:
                lock += math.floor((pos["mfe"] - A) / X) * Y
            pos["lock"] = lock if pos["lock"] is None else max(pos["lock"], lock)
        elif A <= 0 and X > 0 and Y > 0 and pos["mfe"] >= X:
            # plain trailing of overall MTM: lock (steps-1)*Y after each X
            lock = (math.floor(pos["mfe"] / X) - 1) * Y
            pos["lock"] = lock if pos["lock"] is None else max(pos["lock"], lock)

    def mark(self, day, L, m):
        b = day.bars(L.key)
        if b is None:
            return L.entry_px
        v = b["mark"][m]
        if math.isnan(v):
            v = b["prev_close"][m]
        return L.entry_px if math.isnan(v) else float(v)

    def mtm(self, pos, day, m):
        tot = 0.0
        for L in pos["legs"]:
            if L.open:
                tot += L.pnl(self.mark(day, L, m))
            else:
                tot += L.pnl(L.exit_px)
        return tot

    def mins_in(self, pos, d, m):
        if pos["day"] == d:
            return m - pos["min"]
        n = sum(1 for x in self.exp_tab if pos["day"] < x < d)
        return (MINUTES - pos["min"]) + n * MINUTES + m

    def finish(self, pos, mark_open=False):
        legs = pos["legs"]
        if mark_open:
            for L in legs:
                if L.open:
                    L.exit_px = L.entry_px
                    L.exit_day = L.entry_day
        gross = sum(L.pnl(L.exit_px) for L in legs)
        fees = sum(L.fees for L in legs)
        last = max(legs, key=lambda L: (L.exit_day or date.min, L.exit_min))
        self._last_exit_min = last.exit_min if last.exit_day == pos["day"] else -1
        t = {
            "id": len(self.trades) + 1,
            "entryDate": str(pos["day"]), "entryTime": hhmm(pos["min"]),
            "exitDate": str(last.exit_day), "exitTime": hhmm(max(last.exit_min, 0)),
            "spotIn": round(pos["spot"], 2),
            "side": pos.get("side", "long"),
            "exitReason": last.reason,
            "gross": round(gross, 2), "charges": round(fees, 2), "net": round(gross - fees, 2),
            "mae": round(pos["mae"], 2), "mfe": round(pos["mfe"], 2),
            "premium": round(sum(L.sign * -1 * L.entry_px * L.qty for L in legs if L.parent < 0), 2),
            "legs": [{
                "leg": L.idx + 1, "reentry": L.parent >= 0, "side": L.side, "type": L.key[1],
                "expiry": L.key[0], "strike": L.key[2], "qty": L.qty,
                "entryTime": f"{L.entry_day} {hhmm(L.entry_min)}", "entry": round(L.entry_px, 2),
                "exitTime": f"{L.exit_day} {hhmm(max(L.exit_min, 0))}", "exit": round(L.exit_px, 2),
                "reason": L.reason, "pnl": round(L.pnl(L.exit_px), 2), "charges": round(L.fees, 2),
                "iv": None if math.isnan(L.iv_in) else round(L.iv_in * 100, 2),
                "delta": None if math.isnan(L.delta_in) else round(L.delta_in, 3),
                "sl": None if math.isnan(L.sl) else round(L.sl, 2),
            } for L in legs],
        }
        self.trades.append(t)

    # -- stats
    def report(self):
        cap = float(self.cfg.get("capital", 1_000_000))
        T = self.trades
        nets = np.array([t["net"] for t in T]) if T else np.array([])
        by_day: dict = {}
        for t in T:
            by_day[t["exitDate"]] = by_day.get(t["exitDate"], 0.0) + t["net"]
        start = date.fromisoformat(self.cfg["start"])
        end = date.fromisoformat(self.cfg["end"])
        cal = set(self.m.get("calendar") or [])
        sessions = [d for d in sorted(self.exp_tab) if start <= d <= end and (not cal or str(d) in cal)]
        daily = [{"date": str(d), "pnl": round(by_day.get(str(d), 0.0), 2)} for d in sessions]
        eq, peak, dd_series = [], cap, []
        run = cap
        max_dd, max_dd_pct, dd_start, dd_len, cur_len = 0.0, 0.0, None, 0, 0
        for r in daily:
            run += r["pnl"]
            peak = max(peak, run)
            dd = run - peak
            cur_len = cur_len + 1 if dd < 0 else 0
            dd_len = max(dd_len, cur_len)
            max_dd = min(max_dd, dd)
            max_dd_pct = min(max_dd_pct, dd / peak * 100)
            eq.append({"date": r["date"], "equity": round(run, 2), "dd": round(dd, 2)})
        dp = np.array([r["pnl"] for r in daily]) if daily else np.array([0.0])
        traded_days = np.array([v for v in by_day.values()])
        wins, losses = nets[nets > 0], nets[nets <= 0]
        gross_win, gross_loss = wins.sum() if len(wins) else 0.0, -losses.sum() if len(losses) else 0.0
        years = max((end - start).days, 1) / 365.25
        final = cap + nets.sum() if len(nets) else cap
        streak_w = streak_l = cw = cl = 0
        for x in nets:
            if x > 0:
                cw, cl = cw + 1, 0
            else:
                cl, cw = cl + 1, 0
            streak_w, streak_l = max(streak_w, cw), max(streak_l, cl)
        dret = dp / cap
        sharpe = float(dret.mean() / dret.std() * math.sqrt(252)) if dret.std() > 0 else 0.0
        neg = dret[dret < 0]
        sortino = float(dret.mean() / neg.std() * math.sqrt(252)) if len(neg) > 1 and neg.std() > 0 else 0.0
        cagr = ((final / cap) ** (1 / years) - 1) * 100 if final > 0 else -100.0
        stats = {
            "netPnl": round(float(nets.sum()) if len(nets) else 0.0, 2),
            "grossPnl": round(sum(t["gross"] for t in T), 2),
            "charges": round(sum(t["charges"] for t in T), 2),
            "returnPct": round(float(nets.sum()) / cap * 100 if len(nets) else 0.0, 2),
            "cagr": round(cagr, 2),
            "trades": len(T),
            "winRate": round(len(wins) / len(nets) * 100, 2) if len(nets) else 0.0,
            "avgWin": round(float(wins.mean()), 2) if len(wins) else 0.0,
            "avgLoss": round(float(losses.mean()), 2) if len(losses) else 0.0,
            "avgTrade": round(float(nets.mean()), 2) if len(nets) else 0.0,
            "bestTrade": round(float(nets.max()), 2) if len(nets) else 0.0,
            "worstTrade": round(float(nets.min()), 2) if len(nets) else 0.0,
            "profitFactor": round(gross_win / gross_loss, 2) if gross_loss > 0 else None,
            "expectancy": round(float(nets.mean()), 2) if len(nets) else 0.0,
            "payoffRatio": round(float(wins.mean() / -losses.mean()), 2) if len(wins) and len(losses) and losses.mean() < 0 else None,
            "maxDD": round(max_dd, 2), "maxDDPct": round(max_dd_pct, 2), "maxDDDays": dd_len,
            "calmar": round(cagr / abs(max_dd_pct), 2) if max_dd_pct < 0 else None,
            "sharpe": round(sharpe, 2), "sortino": round(sortino, 2),
            "maxWinStreak": streak_w, "maxLossStreak": streak_l,
            "tradedDays": int(len(traded_days)), "sessions": len(sessions),
            "winDays": int((traded_days > 0).sum()), "lossDays": int((traded_days <= 0).sum()),
            "finalEquity": round(final, 2),
        }
        monthly: dict = {}
        for t in T:
            k = t["exitDate"][:7]
            monthly[k] = round(monthly.get(k, 0.0) + t["net"], 2)
        wd: dict = {}
        for t in T:
            k = date.fromisoformat(t["entryDate"]).isoweekday()
            e = wd.setdefault(k, {"day": k, "pnl": 0.0, "trades": 0, "wins": 0})
            e["pnl"] = round(e["pnl"] + t["net"], 2)
            e["trades"] += 1
            e["wins"] += t["net"] > 0
        reasons: dict = {}
        for t in T:
            for L in t["legs"]:
                reasons[L["reason"]] = reasons.get(L["reason"], 0) + 1
        dte: dict = {}
        for t in T:
            e = min(date.fromisoformat(L["expiry"]) for L in t["legs"])
            k = (e - date.fromisoformat(t["entryDate"])).days
            x = dte.setdefault(k, {"dte": k, "pnl": 0.0, "trades": 0})
            x["pnl"] = round(x["pnl"] + t["net"], 2)
            x["trades"] += 1
        return {
            "stats": stats, "equity": eq, "daily": daily, "monthly": monthly,
            "weekday": sorted(wd.values(), key=lambda x: x["day"]),
            "byDte": sorted(dte.values(), key=lambda x: x["dte"]),
            "exitReasons": reasons, "trades": T,
            "skipped": self.skipped, "warnings": self.warnings,
            "spotSource": self.spot["src"],
        }


def run_backtest(cfg):
    return Backtest(cfg).run()


# ----------------------------------------------------------------------------- chain viewer

def option_chain(exch, und, d: str, t: str, expiry: str | None = None):
    dd = date.fromisoformat(d)
    tab = expiry_table(exch, und).get(dd)
    if not tab:
        raise ValueError("no data for that date")
    exps = tab["opt"]
    e = date.fromisoformat(expiry) if expiry else (exps[0] if exps else None)
    if e is None:
        raise ValueError("no options on that date")
    day = Day(exch, und, dd, [e])
    m = to_min(t)
    s = Backtest.__new__(Backtest)
    spot_arr = None
    sp = spot_series(exch, und)
    # spot at minute
    ts = np.datetime64(f"{d}T{hhmm(m)}", "m")
    i = np.searchsorted(sp["ts"], ts, side="right") - 1
    spot = float(sp["c"][i]) if i >= 0 else float("nan")
    T = years_to_expiry(dd, m, e)
    rows = []
    for k in sorted({x[2] for x in day.keys if x[1] in ("CE", "PE")}):
        row = {"strike": k}
        for typ in ("CE", "PE"):
            b = day.bars((str(e), typ, k))
            if b is None:
                continue
            p = float(b["mark"][m]) if not math.isnan(b["mark"][m]) else float("nan")
            if math.isnan(p):
                continue
            iv = implied_vol(p, spot, k, T, typ)
            row[typ] = {"ltp": p, "oi": None if np.isnan(b["oi"][: m + 1]).all() else float(b["oi"][: m + 1][~np.isnan(b["oi"][: m + 1])][-1]),
                        "vol": float(np.nansum(b["v"][: m + 1])),
                        "iv": None if math.isnan(iv) else round(iv * 100, 2),
                        "delta": None if math.isnan(iv) else round(bs_delta(spot, k, T, iv, typ), 3)}
        if "CE" in row or "PE" in row:
            rows.append(row)
    return {"spot": spot, "expiry": str(e), "expiries": [str(x) for x in exps], "time": hhmm(m),
            "lot": meta()["lots"].get(f"{exch}:{und}", {}).get(str(e)), "rows": rows}
