import json
import os
import re
import time
import traceback
import uuid
from typing import Optional

import numpy as np
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse, RedirectResponse, Response
from fastapi.staticfiles import StaticFiles

import engine
import jobs
from strategy import marketplace
from strategy.prompt import compile_prompt

app = FastAPI(title="QuantLab F&O Backtester")


@app.on_event("startup")
def warm_caches():
    """Load expiry tables + spot series of the main indices in the background so first runs are fast."""
    import threading

    def go():
        for exch, und in (("NFO", "NIFTY"), ("BFO", "SENSEX"), ("NFO", "BANKNIFTY"), ("NFO", "FINNIFTY"),
                          ("NFO", "MIDCPNIFTY")):
            try:
                engine.expiry_table(exch, und)
                engine.spot_series(exch, und)
            except Exception:
                traceback.print_exc()
    threading.Thread(target=go, daemon=True, name="warmup").start()
WEB = os.path.join(engine.ROOT, "web")
APP_DIR = os.path.join(WEB, "app")
SAVED = os.path.join(engine.DATA, "strategies")


def _np(o):
    if isinstance(o, np.generic):
        return o.item()
    return str(o)


def jsonr(obj, status=200):
    return Response(json.dumps(obj, default=_np), media_type="application/json", status_code=status)


# ----------------------------------------------------------------------------- pages

@app.get("/")
def index():
    if os.path.exists(os.path.join(APP_DIR, "index.html")):
        return RedirectResponse("/app/")
    return FileResponse(os.path.join(WEB, "index.html"))


@app.get("/classic")
def classic():
    return FileResponse(os.path.join(WEB, "index.html"))


if os.path.isdir(os.path.join(APP_DIR, "assets")):
    app.mount("/app/assets", StaticFiles(directory=os.path.join(APP_DIR, "assets")), name="assets")


@app.get("/app/{path:path}")
def spa(path: str = ""):
    f = os.path.join(APP_DIR, path)
    if path and os.path.isfile(f) and os.path.realpath(f).startswith(os.path.realpath(APP_DIR)):
        return FileResponse(f)
    idx = os.path.join(APP_DIR, "index.html")
    if not os.path.exists(idx):
        raise HTTPException(404, "UI not built — run `npm run build` in frontend/")
    return FileResponse(idx)


# ----------------------------------------------------------------------------- data

@app.get("/api/meta")
def meta():
    m = engine.meta()
    return {"underlyings": [u for u in m["underlyings"] if u["options"] or u["futures"]],
            "calendar": [m["calendar"][0], m["calendar"][-1]] if m["calendar"] else [],
            "index_map": m["index_map"]}


@app.get("/api/chain")
def chain(exch: str, und: str, date: str, time: str = "09:20", expiry: Optional[str] = None):
    try:
        return engine.option_chain(exch, und, date, time, expiry)
    except ValueError as e:
        raise HTTPException(400, str(e))


# ----------------------------------------------------------------------------- strategy creation

@app.post("/api/strategy/compile")
def compile_strategy(body: dict):
    src = body.get("source")
    code = body.get("code") or ""
    defaults = body.get("defaults") or {}
    try:
        if src == "prompt":
            unds = [u["und"] for u in engine.meta()["underlyings"]]
            res = compile_prompt(code, defaults, unds)
        elif src == "pine":
            from strategy.pine import compile_pine
            res = compile_pine(code, defaults)
        elif src == "python":
            from strategy.pydsl import compile_python
            res = compile_python(code, defaults)
        else:
            raise ValueError("source must be prompt, pine or python")
        # fail fast on bad rules: the constructor compiles every condition
        engine.Backtest(res["config"])
    except (ValueError, KeyError, SyntaxError) as e:
        raise HTTPException(400, str(e))
    return jsonr(res)


@app.get("/api/strategy/python-reference")
def python_reference():
    from strategy import pydsl
    return {"reference": getattr(pydsl, "DSL_REFERENCE", ""), "example": getattr(pydsl, "EXAMPLE", "")}


@app.get("/api/marketplace")
def market():
    return jsonr(marketplace.listing())


# ----------------------------------------------------------------------------- runs

@app.post("/api/backtest")
def backtest(cfg: dict):
    try:
        res = jobs.run_single(cfg)
    except ValueError as e:
        raise HTTPException(400, str(e))
    except Exception as e:
        traceback.print_exc()
        raise HTTPException(500, f"{type(e).__name__}: {e}")
    return jsonr(res)


@app.post("/api/jobs")
def new_job(body: dict):
    cfg = body.get("config") or body
    if not cfg.get("und") or not cfg.get("legs"):
        raise HTTPException(400, "config needs an underlying and at least one leg")
    return {"id": jobs.submit("backtest", {"config": cfg})}


@app.post("/api/jobs/optimize")
def new_opt(body: dict):
    if not body.get("config") or not body.get("params"):
        raise HTTPException(400, "config and params are required")
    return {"id": jobs.submit("optimize", body)}


@app.get("/api/jobs/{jid}")
def job(jid: str):
    j = jobs.get(jid)
    if not j:
        raise HTTPException(404, "job not found")
    if j["status"] == "done" and j["kind"] == "backtest" and not j.get("_stats_saved"):
        mid = ((j["result"].get("config") or {}).get("meta") or {}).get("marketplaceId")
        if mid:
            marketplace.save_stats(mid, j["result"]["stats"])
        jobs._jobs[jid]["_stats_saved"] = True
    return jsonr(j)


@app.delete("/api/jobs/{jid}")
def job_cancel(jid: str):
    if not jobs.cancel(jid):
        raise HTTPException(404, "job not found")
    return {"ok": True}


# ----------------------------------------------------------------------------- saved strategies

def _saved_path(sid):
    if not re.fullmatch(r"[a-f0-9]{12}", sid):
        raise HTTPException(400, "bad id")
    return os.path.join(SAVED, sid + ".json")


@app.get("/api/strategies")
def list_saved():
    os.makedirs(SAVED, exist_ok=True)
    out = []
    for f in os.listdir(SAVED):
        if f.endswith(".json"):
            try:
                with open(os.path.join(SAVED, f)) as fh:
                    out.append(json.load(fh))
            except (OSError, ValueError):
                pass
    return sorted(out, key=lambda x: x.get("updated", 0), reverse=True)


@app.post("/api/strategies")
def save(body: dict):
    cfg = body.get("config")
    if not cfg:
        raise HTTPException(400, "config required")
    os.makedirs(SAVED, exist_ok=True)
    sid = body.get("id") or uuid.uuid4().hex[:12]
    rec = {"id": sid, "name": (body.get("name") or cfg.get("name") or "Untitled")[:120],
           "source": (cfg.get("meta") or {}).get("source", "custom"), "und": cfg.get("und"),
           "updated": time.time(), "config": cfg, "stats": body.get("stats")}
    with open(_saved_path(sid), "w") as fh:
        json.dump(rec, fh)
    return rec


@app.delete("/api/strategies/{sid}")
def delete(sid: str):
    p = _saved_path(sid)
    if os.path.exists(p):
        os.remove(p)
    return {"ok": True}
