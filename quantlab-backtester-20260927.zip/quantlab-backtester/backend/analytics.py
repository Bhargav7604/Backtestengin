"""Post-run analytics: Monte Carlo trade resampling and buy-and-hold benchmark."""
from __future__ import annotations

from datetime import date

import numpy as np

import engine


def monte_carlo(trades, capital, runs=1000, seed=7):
    """Bootstrap the trade P&L sequence -> distribution of max drawdown / final equity."""
    nets = np.array([t["net"] for t in trades], float)
    if len(nets) < 5:
        return None
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, len(nets), size=(runs, len(nets)))
    paths = capital + np.cumsum(nets[idx], axis=1)
    peaks = np.maximum.accumulate(np.concatenate([np.full((runs, 1), capital), paths], axis=1), axis=1)[:, 1:]
    dd = (paths - peaks).min(axis=1)
    final = paths[:, -1]
    pct = lambda a, q: round(float(np.percentile(a, q)), 2)
    step = max(1, len(nets) // 120)
    cols = list(range(0, len(nets), step)) + ([len(nets) - 1] if (len(nets) - 1) % step else [])
    bands = [{"i": int(i + 1), "p5": pct(paths[:, i], 5), "p50": pct(paths[:, i], 50), "p95": pct(paths[:, i], 95)}
             for i in cols]
    return {
        "runs": runs,
        "maxDD": {"p5": pct(dd, 5), "p50": pct(dd, 50), "p95": pct(dd, 95)},
        "finalEquity": {"p5": pct(final, 5), "p50": pct(final, 50), "p95": pct(final, 95)},
        "probLoss": round(float((final < capital).mean() * 100), 2),
        "bands": bands,
    }


def benchmark(cfg, equity):
    """Buy-and-hold the underlying with the same starting capital, on the result's session dates."""
    try:
        s = engine.spot_series(cfg.get("exch", "NFO"), cfg["und"])
    except Exception:
        return []
    if not equity:
        return []
    days = s["ts"].astype("datetime64[D]")
    last = np.flatnonzero(np.append(days[1:] != days[:-1], True))
    close_by_day = {str(days[i]): float(s["c"][i]) for i in last}
    cap = float(cfg.get("capital", 1_000_000))
    base = None
    out = []
    px = None
    for e in equity:
        px = close_by_day.get(e["date"], px)
        if px is None:
            continue
        base = base or px
        out.append({"date": e["date"], "equity": round(cap * px / base, 2)})
    return out


def enrich(result, cfg):
    cap = float(cfg.get("capital", 1_000_000))
    result["montecarlo"] = monte_carlo(result.get("trades", []), cap)
    result["benchmark"] = benchmark(cfg, result.get("equity", []))
    if result["benchmark"]:
        b = result["benchmark"]
        result["stats"]["benchmarkReturnPct"] = round((b[-1]["equity"] / cap - 1) * 100, 2)
    return result
